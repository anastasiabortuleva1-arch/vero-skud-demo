export type MonitoringRole = 'customer' | 'executor';
export type DeviceState = 'working' | 'noData';
export type DeviceFilter = 'all' | DeviceState;

const figmaFile = 'https://www.figma.com/design/WJfF10N99vjCLaWkcfClG1/workspace_vero_interfejs';
const source = (node: string, image: string) => ({ url: `${figmaFile}?node-id=${node}`, image: `analysis/browser/${image}.jpg` });

export const monitoringSources = {
  customerList: source('6357-555228', 'customer-monitor-list'),
  customerEmpty: source('6357-555023', 'customer-monitor-empty'),
  customerError: source('6357-555077', 'customer-monitor-object-2'),
  customerHealthy: source('6439-378235', 'customer-monitor-object-1'),
  customerAnalytics: source('6586-196595', 'customer-monitor-object-0'),
  executorList: source('6357-554234', 'executor-monitor-list'),
  executorEmpty: source('6357-554287', 'executor-monitor-empty'),
  executorError: source('6357-554342', 'executor-monitor-object-4'),
  executorWorkingDevices: source('6357-554738', 'executor-monitor-object-2'),
  executorNoDataDevices: source('6357-554604', 'executor-monitor-object-3'),
} as const;

export const monitoringCopy = {
  customer: {
    heading: 'Мониторинг',
    subtitle: 'Контроль за состоянием объектов и передачей данных в ДИТ',
    emptyHeading: 'Пока нет объектов для мониторинга',
    emptyLines: ['Установите и зарегистрируйте ТСОФ на платформе, чтобы', 'начать мониторинг'],
    analyticsTab: 'Аналитика (демо)',
  },
  executor: {
    heading: 'Объекты на ТО',
    subtitle: 'Техническое обслуживание, контроль за состоянием объектов и передачей данных в ДИТ',
    emptyHeading: 'Пока нет объектов для ТО',
    emptyLines: ['Откликнитесь на заявку с техническим обслуживанием,', 'чтобы добавить объект в раздел'],
    analyticsTab: 'Аналитика',
  },
} as const;

export interface MonitoringCount { state: DeviceState; count: number }
export interface MonitoringCard {
  /** Presentation key only: the list does not show an object ID. */
  id: string;
  name: string;
  states: readonly MonitoringCount[];
  updated: string;
}

const commonCards: readonly MonitoringCard[] = [
  { id: 'kolomenskoye', name: 'ЖК «Коломенское»', states: [{ state: 'noData', count: 6 }], updated: 'менее часа назад' },
  { id: 'severny-1', name: 'ЖК «Северный парк», 1 корпус', states: [{ state: 'working', count: 6 }], updated: '1 час назад' },
  { id: 'severny-2', name: 'ЖК «Северный парк», 2 корпус', states: [{ state: 'noData', count: 9 }], updated: 'менее часа назад' },
  { id: 'yuzhny', name: 'ЖК «Южный»', states: [{ state: 'noData', count: 6 }, { state: 'working', count: 4 }], updated: 'менее часа назад' },
];
export const monitoringCards: Record<MonitoringRole, readonly MonitoringCard[]> = {
  customer: [...commonCards, {
    id: 'temple', name: 'Храм святого Игнатия Богоносца',
    states: [{ state: 'working', count: 10 }], updated: '28.08.2026',
  }],
  executor: [...commonCards, {
    id: 'khoroshyovo', name: 'ЖК «Хорошёво»', states: [{ state: 'working', count: 10 }], updated: '28.08.2026',
  }],
};

export const deviceStateLabels: Record<DeviceState, string> = { working: 'Работает', noData: 'Нет данных' };
export interface MonitoringDevice { id: string; location: string; state: DeviceState }
export interface MonitoringObject {
  id: string;
  name: string;
  address: string;
  requestId: string;
  contractor: string;
  maintenance: string;
  updated: string;
  deviceCount: number;
  transmitting: string;
  status: string;
  statusState: DeviceState;
  devices: readonly MonitoringDevice[];
  alert?: { heading: string; description: string };
  initialTab: 'devices' | 'analytics';
}

// Separate screen examples, not a transformation of the six-device list card.
const objectBase = {
  name: 'ЖК «Коломенское»',
  address: 'г. Москва, внутригородская территория муниципальный округ Бутырский, Огородный проезд, земельный участок 6/1',
  requestId: 'СКУД-2026-0001', updated: 'менее часа назад', deviceCount: 3,
};
const errorObject: MonitoringObject = {
  ...objectBase, id: 'kolomenskoye', contractor: 'МонтажСервис-М', maintenance: '87 367,00 ₽/мес.',
  transmitting: '1 из 3', status: 'Нет данных: 2', statusState: 'noData', initialTab: 'devices',
  devices: [
    { id: 'SKUD-01180-01', location: 'КПП №1', state: 'noData' },
    { id: 'SKUD-01180-02', location: 'КПП №2', state: 'noData' },
    { id: 'SKUD-01180-03', location: 'КПП №3', state: 'working' },
  ],
  alert: {
    heading: '2 из 3 устройств не передают данные',
    description: 'Устраните нарушения до истечения срока, чтобы сохранить сертификат подключения',
  },
};
const healthyObject: MonitoringObject = {
  ...objectBase, id: 'kolomenskoye-healthy', contractor: 'МонтажСервис-М', maintenance: '87 367,00 ₽/мес.',
  transmitting: '3 из 3', status: 'Всё работает штатно', statusState: 'working', initialTab: 'devices',
  devices: errorObject.devices.map(device => ({ ...device, state: 'working' })),
};
export const monitoringObjects: Readonly<Record<string, MonitoringObject>> = {
  kolomenskoye: errorObject,
  'kolomenskoye-healthy': healthyObject,
  'kolomenskoye-analytics': { ...healthyObject, id: 'kolomenskoye-analytics', initialTab: 'analytics' },
};

export const monitoringUpdatedExamples = [
  { label: '23 часа назад', source: source('6623-200702', 'status-1') },
  { label: '2 часа назад', source: source('6586-197050', 'status-2') },
  { label: '1 час назад', source: source('6586-196972', 'status-3') },
  { label: 'менее часа назад', source: source('6586-196915', 'status-4') },
  { label: '3 окт', source: source('6586-197128', 'status-older-day') },
] as const;
export type MonitoringUpdatedLabel = typeof monitoringUpdatedExamples[number]['label'];

export const monitoringDemo = {
  heading: 'Мониторинг проходов на ОКС', period: 'Период 30.09.2026 – 07.10.2026', today: 'Обновлено 7 октября',
  statistics: [
    { label: 'Всего проходов', value: '1 828', change: '8%', direction: 'up' },
    { label: 'По Face ID', value: '1 796', change: '11%', direction: 'up' },
    { label: 'Несанкционированные', value: '32', change: '2%', direction: 'down' },
  ],
  chart: [
    { date: '30.09', face: 156, unauthorized: 3 }, { date: '01.10', face: 232, unauthorized: 5 },
    { date: '02.10', face: 189, unauthorized: 2 }, { date: '03.10', face: 310, unauthorized: 6 },
    { date: '04.10', face: 124, unauthorized: 1 }, { date: '05.10', face: 275, unauthorized: 7 },
    { date: '06.10', face: 218, unauthorized: 4 }, { date: '07.10', face: 292, unauthorized: 4 },
  ],
  axis: ['400', '350', '300', '250', '200', '150', '100', '50', '0'],
} as const;
