/** Request context shared by the executor response list and its detail screens. */
export interface ExecutorRequestIdentity {
  id: string;
  /** Service title, without the object name. */
  title: string;
  name: string;
  address: string;
  workFormat: string;
  uin?: string;
}
