export type InstallStage = 'empty-offers' | 'offers' | 'offer' | 'contract-sign' | 'preparation' | 'working' | 'acceptance' | 'accept-sign' | 'rework';
export const installStages: readonly InstallStage[] = ['empty-offers','offers','offer','contract-sign','preparation','working','acceptance','accept-sign','rework'];
export interface InstallObject {
  uin: string; name: string; address: string; financing: string; workFormat: string; schemePreparedBy: string;
}
export const installRequestEdit = {
  title: 'Изменение данных', heading: 'Инфраструктура объекта',
  uin: 'УИН объекта капитального строительства',
  name: 'Наименование объекта капитального строительства', address: 'Адрес ОКС',
  save: 'Сохранить', cancel: 'Отменить', loading: 'Обновляем данные',
} as const;
const figma = 'https://www.figma.com/design/WJfF10N99vjCLaWkcfClG1/workspace_vero_interfejs?node-id=';
export const installSources = {
  empty: `${figma}6300-175131`, offers: `${figma}6143-59274`, contractPrompt: `${figma}6439-333479`,
  contractSign: `${figma}6143-69137`, insufficientFunds: `${figma}6143-69270`,
  offer: `${figma}6143-69719`, preparation: `${figma}6143-59752`, working: `${figma}6143-59966`,
  acceptance: `${figma}6143-60064`, acceptancePrompt: `${figma}6143-60338`, acceptanceSign: `${figma}6143-61125`,
  reworkValidation: `${figma}6321-251290`, reworkLoading: `${figma}6321-252298`, reworkFilled: `${figma}6321-251787`,
  reworkEmpty: `${figma}6321-250818`, reworkSent: `${figma}6321-252795`, reworkRevisedResult: `${figma}6321-253282`,
  reworkInitialResult: `${figma}6321-250350`, reworkError: `${figma}6143-72824`,
  contractSignedNotice: `${figma}6143-69616`,
} as const;

export const installRequest = {
  id: 'СКУД-2026-0009', title: 'ЖК «Коломенское» — установка и регистрация СКУД',
  object: {
    uin: 'HH8212-08-0001-001', name: 'ЖК «Коломенское»',
    address: 'г. Москва, внутригородская территория муниципальный округ Бутырский, Огородный проезд, земельный участок 6/1',
    financing: 'Внебюджетные источники', workFormat: 'С дальнейшим ТО', schemePreparedBy: 'Подготовит исполнитель',
  } satisfies InstallObject,
  steps: ['Подбор исполнителя','Монтаж оборудования','Проверка в Правительстве','Тестирование оборудования','Завершение работ'],
  documents: {
    contract: 'Договор №2026-СВ-018/КУ.pdf', readiness: 'Акт готовности к монтажу.pdf',
    composition: 'Состав технических средств биометрической СКУД в табличной форме.xlsx', scheme: 'Схема размещения СКУД.pdf',
  },
  receivedDescription: 'Сравните поступившие предложения от исполнителей и выберите подходящий вариант',
  readinessDescription: 'Подтвердите готовность площадки. Дата подписания зафиксирует начало периода, с которого исполнитель может приступить к монтажу',
  resultEmpty: 'Здесь будет доступен результат работы, когда исполнитель направит его вам',
  additionalDescription: 'Если в ходе монтажа или проверки потребуются дополнительные работы, оформите их через дополнительное соглашение',
  resultVersion: 'Версия №1', resultSent: '20.03.2026, 18:26',
  acceptanceDescription: 'После приёмки вы подпишете акт. Заявка перейдёт к регистрации и подключению, а исполнитель продолжит сопровождение и получит оплату после завершения',
  chat: { date: '20 августа 2026 г.', message: 'Добрый день! Подготовили предложение с поставкой оборудования и обслуживанием. Готовы согласовать дату осмотра площадки.', time: '14:30' },
} as const;

/** Separate rework-flow reference: its wording/layout differ from the main installation example. */
export const installRework = {
  fixtureObject: {...installRequest.object,workFormat:'Монтаж и дальнейшее ТО'},
  title: 'Отправить на доработку',
  emptyDescription: 'Укажите замечания к работе, чтобы исполнитель мог внести необходимые изменения',
  description: 'Опишите замечания к работе, чтобы исполнитель мог внести необходимые изменения',
  placeholder: 'Введите комментарий', comment: 'Перенесите терминал у въезда ближе к посту охраны и укажите на схеме точки подключения к сети.',
  required: 'Укажите, что нужно исправить', loading: 'Отправляем на доработку', status: 'Отправлено на доработку',
  errorTitle: 'Не удалось отправить на доработку', errorDescription: 'Повторите попытку или вернитесь назад',
  // Version 2 is a separately supplied result fixture, never a generated response to sending a comment.
  revisedVersion: 'Версия №2.', revisedSent: '22.03.2026, 10:26', revisedScheme: 'Схема размещения СКУД2.pdf',
} as const;

/** Distinct demonstration offers; shared values power cards and detail views. */
const offerMoney = (value: number) => value.toLocaleString('ru-RU', {minimumFractionDigits: 2, maximumFractionDigits: 2});
export const installOfferCards = [
  {key:'offer-1',receivedAt:'2026-10-07T14:35:00',name:'Монтаж Сервис-М',inn:'7727563778',equipmentValue:622720,installationValue:130400,maintenanceValue:45840,end:'28.11.2026'},
  {key:'offer-2',receivedAt:'2026-10-07T13:20:00',name:'Контур Безопасности',inn:'7718452196',equipmentValue:598400,installationValue:145600,maintenanceValue:38500,end:'25.11.2026'},
  {key:'offer-3',receivedAt:'2026-10-07T11:10:00',name:'Биометрия Про',inn:'7709638142',equipmentValue:674800,installationValue:112000,maintenanceValue:42000,end:'20.11.2026'},
  {key:'offer-4',receivedAt:'2026-10-06T16:45:00',name:'Интегра Системы',inn:'7724389015',equipmentValue:561200,installationValue:168000,maintenanceValue:34900,end:'02.12.2026'},
  {key:'offer-5',receivedAt:'2026-10-06T12:00:00',name:'Точка Доступа',inn:'7736124508',equipmentValue:639600,installationValue:124800,maintenanceValue:39700,end:'23.11.2026'},
  {key:'offer-6',receivedAt:'2026-10-05T09:30:00',name:'Городские Системы Контроля',inn:'7715286394',equipmentValue:710000,installationValue:98600,maintenanceValue:51200,end:'18.11.2026'},
].map(offer=>({...offer,deadline:`до ${offer.end}`,equipment:`${offerMoney(offer.equipmentValue)} ₽`,installation:`${offerMoney(offer.installationValue)} ₽`,maintenance:`${offerMoney(offer.maintenanceValue)} ₽/мес`}));
export type InstallOfferCard = typeof installOfferCards[number];
export function getInstallOfferDetail(card: InstallOfferCard) {
  return {contractor:card.name,sent:new Date(card.receivedAt).toLocaleString('ru-RU',{day:'2-digit',month:'2-digit',year:'numeric',hour:'2-digit',minute:'2-digit'}),equipment:offerMoney(card.equipmentValue),installation:offerMoney(card.installationValue),maintenance:`${offerMoney(card.maintenanceValue)} /мес`,oneOff:offerMoney(card.equipmentValue+card.installationValue),recurring:`${offerMoney(card.maintenanceValue)} /мес`,vat:'Расчёт стоимости с НДС, 22%',start:'12.10.2026',end:card.end};
}
export const installOfferDetail = getInstallOfferDetail(installOfferCards[0]);
export const installContractCopy = {
  reservation: 'После подписания договора условия заявки будут зафиксированы, а средства в размере 753 120 ₽ будут зарезервированы на вашем балансе. Исполнитель сможет приступить к выполнению работ',
  insufficient: 'На вашем балансе не хватает 170 000 ₽',
} as const;
export function getInstallOfferTables(card: InstallOfferCard) {
  const equipmentParts=[Math.round(card.equipmentValue*.6),Math.round(card.equipmentValue*.3)];
  const rows=[['Терминал Face ID','2',offerMoney(equipmentParts[0]/2),offerMoney(equipmentParts[0])],['Турникет с контроллером','2',offerMoney(equipmentParts[1]/2),offerMoney(equipmentParts[1])],['Комплект подключения и питания','1',offerMoney(card.equipmentValue-equipmentParts[0]-equipmentParts[1]),offerMoney(card.equipmentValue-equipmentParts[0]-equipmentParts[1])]];
  return [
    {title:'Перечень оборудования (покупка)',firstColumn:'Наименование оборудования',totalColumn:'Общая стоимость, ₽',rows,total:offerMoney(card.equipmentValue),vat:offerMoney(card.equipmentValue*22/122)},
    {title:'Монтажные работы, ПНР',firstColumn:'Наименование',totalColumn:'Общая стоимость, ₽',rows:[['Монтаж, настройка и пусконаладка','1',offerMoney(card.installationValue),offerMoney(card.installationValue)]],total:offerMoney(card.installationValue),vat:offerMoney(card.installationValue*22/122)},
    {title:'Техническое обслуживание и программное сопровождение',firstColumn:'Наименование',totalColumn:'Общая стоимость, ₽/мес.',rows:[['Обслуживание оборудования и поддержка ПО','1',offerMoney(card.maintenanceValue),offerMoney(card.maintenanceValue)]],total:offerMoney(card.maintenanceValue),vat:offerMoney(card.maintenanceValue*22/122)},
  ];
}
export const installOfferTables = getInstallOfferTables(installOfferCards[0]);

/** Visible, unfilled reference template. No party, signature, price or date is inferred. */
export const installContractPreview = {
  source: 'analysis/states/customer-selection-3.jpg', title: 'ДОГОВОР №',
  subtitle: 'на оснащение строительной площадки города Москвы системой контроля управления доступом (СКУД) с функцией биометрической идентификации по лицу (Face ID) и её интеграции с государственными информационными системами города Москвы',
  headings: ['г. Москва','ТЕРМИНЫ И ОПРЕДЕЛЕНИЯ'],
  introduction: 'Настоящий Договор заключен по результатам рассмотрения Заявки Заказчика, размещенной на Платформе, и является рамочным (статья 429.1 ГК РФ).',
} as const;
export const installAcceptancePreview = {
  source: 'analysis/states/customer-install-2.jpg', appendix: 'Приложение № 2', title: 'АКТ №',
  subtitle: 'приёмки-сдачи выполненных работ (услуг)',
  sections: ['1. ОСНОВАНИЕ СОСТАВЛЕНИЯ АКТА','2. ПЕРЕЧЕНЬ ВЫПОЛНЕННЫХ РАБОТ (УСЛУГ)'],
  columns: ['№ п/п','Наименование работ (услуг)','Ед. изм.','Объём (количество)','Соответствие Спецификации (да/нет)','Примечание'],
  rows: [['1','Поставка оборудования (по позициям…)','компл.'],['2','Монтажные работы', '']],
} as const;
