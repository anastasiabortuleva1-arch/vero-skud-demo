export type EquipmentPurchaseMode = 'Покупка оборудования' | 'Аренда оборудования';

export interface OfferEquipmentLine {
  equipmentType: string;
  name: string;
  quantity: string;
  unitPrice: string;
}

export interface OfferServiceLine {
  name: string;
  quantity: string;
  unitPrice: string;
}

export interface ExecutorOfferData {
  vatRate: string;
  pricesIncludeVat: boolean;
  equipmentMode: EquipmentPurchaseMode;
  equipment: OfferEquipmentLine[];
  maintenance: OfferServiceLine;
  installation: OfferServiceLine;
  startDate: string;
  endDate: string;
}

export type ExecutorOfferStage = 'form' | 'filled' | 'validation' | 'contract' | 'signing' | 'sign-error' | 'signed' | 'pending';

export const emptyExecutorOfferData: ExecutorOfferData = {
  vatRate: '',
  pricesIncludeVat: true,
  equipmentMode: 'Покупка оборудования',
  equipment: [{ equipmentType: '', name: '', quantity: '0', unitPrice: '0,00' }],
  maintenance: { name: '', quantity: '0', unitPrice: '0,00' },
  installation: { name: '', quantity: '0', unitPrice: '0,00' },
  startDate: '',
  endDate: '',
};

/** Literal values from the readable filled-form reference; totals are provided separately. */
export const filledExecutorOfferData: ExecutorOfferData = {
  vatRate: '22%', pricesIncludeVat: true, equipmentMode: 'Покупка оборудования',
  equipment: [
    { equipmentType: 'Терминал Face ID', name: 'Teplo F8', quantity: '8', unitPrice: '156 289,00' },
    { equipmentType: 'Аккумуляторная батарея', name: '6-ЗА-105Д', quantity: '1', unitPrice: '10 470,00' },
    { equipmentType: 'Турникет трипод напольный', name: 'PERCo T-5:', quantity: '2', unitPrice: '80 289,00' },
  ],
  maintenance: { name: 'Техническое обслуживание', quantity: '3', unitPrice: '127 819,72' },
  installation: { name: 'Монтажные работы', quantity: '3', unitPrice: '20 000,00' },
  startDate: '10.09.2026', endDate: '20.11.2026',
};

export interface ExecutorOfferTotals { vat: string; total: string; }
/** Shown totals are copied literally and are not derived from the visible line values. */
export const filledExecutorOfferTotals: ExecutorOfferTotals = { vat: '88 193,00', total: '678 194,28 ₽' };
export const emptyExecutorOfferTotals: ExecutorOfferTotals = { vat: '0,00', total: '0,00 ₽' };

export const visibleVatRates = ['22%'] as const;
export const visibleEquipmentTypes = ['Терминал Face ID', 'Аккумуляторная батарея', 'Турникет трипод напольный'] as const;
export const visibleEquipmentModes: readonly EquipmentPurchaseMode[] = ['Покупка оборудования', 'Аренда оборудования'];

export const executorOfferCopy = {
  title: 'Ваше коммерческое предложение',
  subtitle: 'Заполните условия выполнения услуги и направьте коммерческое предложение заказчику на рассмотрение',
  sourceFile: { name: 'Схема генерального плана.pdf', size: 12 * 1024 },
  signingDescription: 'Подпишите договор электронной подписью для отправки предложения заказчику. До выбора исполнителя вы сможете отозвать его',
  signedTitle: 'Документ успешно подписан',
  signedDescription: 'Документ подписан электронной подписью',
  signErrorTitle: 'Не удалось подписать документ',
  signErrorDescription: 'Повторите попытку или вернитесь назад',
} as const;

/** Exact values shown in the separate “На рассмотрении” example. */
export const pendingOfferSummary = {
  status: 'На рассмотрении',
  contractor: 'Монтаж Сервис-М',
  sentAt: '07.10.2026 10:20',
  equipmentPurchase: '622 720,00',
  installation: '130 400,00',
  maintenanceMonthly: '45 840,00 /мес.',
  startDate: '12.10.2026',
  endDate: '28.11.2026',
  oneTimeTotal: '753 120,00',
  recurringTotal: '45 840,00 /мес.',
  vatCalculation: '22%',
} as const;
