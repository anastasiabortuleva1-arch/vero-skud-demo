export type IncomingWorkFormat = 'Только монтаж' | 'Монтаж и ТО';
export type EquipmentFilterValue = 'Оборудование в наличии' | 'Оборудование не закуплено';
export type IncomingSortOption = 'Сначала новые' | 'Сначала старые' | 'Сначала просмотренные' | 'Сначала непросмотренные';

export interface IncomingRequest {
  key: string;
  organization: string;
  inn: string;
  address: string;
  workFormat: IncomingWorkFormat;
  equipmentAvailable: boolean;
  dateLabel: string;
  dateOrder: number;
  badge?: '10 компаний уже откликнулось' | 'Откликнитесь первым' | 'Просмотрено' | 'Вы откликнулись';
  hasResponded: boolean;
  viewed?: boolean;
  responseButton: 'Откликнуться' | 'Откликнуться ещё';
}

export const incomingOrganizations = ['АО «Моспромпроект»', 'ООО «Строймонтаж»', 'ООО «Северный Квартал»', 'АО «Мосинжпроект»'] as const;

export const incomingWorkFormats: readonly IncomingWorkFormat[] = ['Только монтаж', 'Монтаж и ТО'];
export const incomingEquipmentOptions: readonly EquipmentFilterValue[] = ['Оборудование в наличии', 'Оборудование не закуплено'];
export const incomingSortOptions: readonly IncomingSortOption[] = [
  'Сначала новые', 'Сначала старые', 'Сначала просмотренные', 'Сначала непросмотренные',
];

/** Four separate examples copied from the incoming-request mockup. */
export const incomingRequestFixtures: readonly IncomingRequest[] = [
  {
    key: 'mospromproekt-new', organization: 'АО «Моспромпроект»', inn: '7727563778',
    address: 'г. Москва, ул. Северная, вл. 12', workFormat: 'Только монтаж', equipmentAvailable: true,
    dateLabel: 'сегодня', dateOrder: 4, badge: '10 компаний уже откликнулось', hasResponded: false,
    responseButton: 'Откликнуться',
  },
  {
    key: 'stroymontazh-yesterday', organization: 'ООО «Строймонтаж»', inn: '7714025837',
    address: 'г. Москва, ул. Рябиновая, вл. 37', workFormat: 'Только монтаж', equipmentAvailable: true,
    dateLabel: 'вчера', dateOrder: 3, badge: 'Откликнитесь первым', hasResponded: false,
    responseButton: 'Откликнуться',
  },
  {
    key: 'stroymontazh-reviewed', organization: 'ООО «Северный Квартал»', inn: '7735182469',
    address: 'г. Москва, Дмитровское шоссе, вл. 124', workFormat: 'Только монтаж', equipmentAvailable: false,
    dateLabel: '28.09.2026', dateOrder: 2, badge: 'Просмотрено', hasResponded: false, viewed: true,
    responseButton: 'Откликнуться',
  },
  {
    key: 'mosinzhproekt-responded', organization: 'АО «Мосинжпроект»', inn: '7707843912',
    address: 'г. Москва, ул. Нижние Мнёвники, вл. 14', workFormat: 'Монтаж и ТО', equipmentAvailable: true,
    dateLabel: '28.09.2026', dateOrder: 1, badge: 'Вы откликнулись', hasResponded: true,
    responseButton: 'Откликнуться ещё',
  },
];
