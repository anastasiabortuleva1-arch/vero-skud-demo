export type AdditionalAgreementState = 'idle' | 'form' | 'form-equipment' | 'pending' | 'proposal' | 'sign' | 'signing' | 'sign-error' | 'signed' | 'confirmed';
export const additionalAgreementStates: readonly AdditionalAgreementState[] = ['idle', 'form', 'form-equipment', 'pending', 'proposal', 'sign', 'signing', 'sign-error', 'signed', 'confirmed'];
export interface AdditionalAgreementDraft { installation: boolean; equipment: boolean; comment: string }
export const additionalAgreement = {
  title: 'Дополнительные работы',
  description: 'Если в ходе монтажа или проверки потребуются дополнительные работы, оформите их через дополнительное соглашение',
  action: 'Дополнительное соглашение',
  formTitle: 'Предложить дополнительные работы',
  formDescription: 'Укажите, какие работы нужно добавить. Исполнитель оценит их и подготовит предложение',
  installation: 'Дополнительный монтаж', equipment: 'Дополнительное оборудование',
  comment: 'Комментарий', optional: '(необязательно)', commentPlaceholder: 'Введите комментарий',
  pendingTitle: 'Запрос отправлен исполнителю',
  pendingDescription: 'Исполнитель оценит дополнительные работы и направит условия соглашения',
  proposalTitle: 'Исполнитель направил дополнительное соглашение',
  proposalDescription: 'Ознакомьтесь с изменениями и подпишите соглашение, если принимаете новые условия',
  changes: 'Изменения:',
  proposal: { installation: '35 000 ₽', equipment: '120 000 ₽', total: '155 000 ₽', deadline: '15.09.2026' },
  document: 'Дополнительное соглашение к Договору №2026-СВ-018/КУ.pdf',
  reservation: 'После подписания договора условия заявки будут зафиксированы, а средства в размере 200 120 ₽ будут зарезервированы на вашем балансе. Исполнитель сможет приступить к выполнению работ',
  signedTitle: 'Документ успешно подписан', signedDescription: 'Электронная подпись добавлена',
  errorTitle: 'Не удалось подписать документ', errorDescription: 'Повторите попытку или вернитесь назад',
} as const;
/** Values shown together in the reference. Keep the displayed total, without recalculating it. */
export const additionalAgreementSummary = {
  contractor: 'Монтаж Сервис-М', sent: '20.06.2026 10:20',
  equipment: '12 827,00', installation: '890,00', maintenance: '2 000,00 /мес',
  oneOff: '13 600,00', recurring: '2 000,00 /мес', vat: 'Расчёт стоимости с НДС, 22%',
  start: '15.06.2026', end: '15.09.2026',
} as const;
export const additionalAgreementSources = {
  overview: '6143:81234', form: '6392:69469', formEquipment: '6392:69848',
  pending: '6500:169627', proposal: '6505:170496', idle: '6392:69079', confirmed: '6571:263080',
  incomingOverview: '6143:79237', sign: '6392:70751', signing: '6392:71204',
  signError: '6392:72184', signed: '6392:71717', incomingProposal: '6392:70290', incomingConfirmed: '6392:72657',
} as const;
/** The visible, unfilled contract page in agreement-document-readable.jpg. */
export const sharedContractPreview = {
  title: 'ДОГОВОР № ___',
  subtitle: 'на оснащение строительной площадки города Москвы системой контроля управления доступом (СКУД) с функцией биометрической идентификации по лицу (Face ID) и её интеграции с государственными информационными системами города Москвы',
  introduction: 'Настоящий Договор заключён по результатам рассмотрения Заявки Заказчика, размещённой на Платформе, и является рамочным (статья 429.1 ГК РФ).',
  platformAgreement: 'Стороны подтверждают, что настоящий Договор заключается с использованием Платформы, оператором которой является Акционерное общество «ВЕРО» (ОГРН 1267700216893, ИНН 9705257499, адрес: 115054, г. Москва, ул. Валовая, д. 26) (далее — Оператор Платформы), и что Стороны акцептовали Пользовательское соглашение Платформы, размещённое в сети «Интернет» по адресу: https://______.ru/.',
  platform: 'интернет-ресурс, расположенный по сетевому адресу (доменному имени: https://______.ru/), представляющий собой совокупность программ для ЭВМ, баз данных, графических и текстовых материалов, дизайна и иных объектов интеллектуальной собственности, предоставляющий Пользователям доступ к электронным услугам (Сервисам).',
  operator: 'лицо, владеющее Платформой и обеспечивающее её функционирование. Оператором Платформы является Акционерное общество «ВЕРО» (ОГРН 1267700216893, ИНН 9705257499).',
} as const;
