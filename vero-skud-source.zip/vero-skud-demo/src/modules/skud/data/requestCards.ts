export type RequestTab = 'active' | 'drafts' | 'archive';

export interface RequestCardData {
  /** Distinct mockup cards can display the same request identifier. */
  key: string;
  id: string;
  tab: RequestTab;
  /** Present only when the mockup explicitly identifies the request stage. */
  stage?: string;
  name: string;
  service: string;
  address: string;
  status: string;
  statusColor: 'warning' | 'processing' | 'default' | 'success' | 'error';
  date: string;
  workFormat: string;
  messages?: number;
  offers?: number;
}

export interface CustomerRequestStatusCatalogEntry {
  stage: string;
  status: string;
  color?: RequestCardData['statusColor'];
}

/** Stage/status pairs explicitly shown in the customer status catalog image. */
export const customerRequestStatusCatalog: readonly CustomerRequestStatusCatalogEntry[] = [
  { stage: 'Подбор исполнителя', status: 'Получаем предложения', color: 'processing' },
  { stage: 'Монтаж оборудования', status: 'Подготовка к монтажу', color: 'warning' },
  { stage: 'Монтаж оборудования', status: 'В работе', color: 'processing' },
  { stage: 'Монтаж оборудования', status: 'Ожидает приёмки', color: 'warning' },
  { stage: 'Монтаж оборудования', status: 'Отправлено на доработку' },
  { stage: 'Монтаж оборудования', status: 'Договор расторгнут', color: 'error' },
  { stage: 'Монтаж оборудования', status: 'На расторжении', color: 'error' },
  { stage: 'Проверка в Правительстве', status: 'Ожидает отправки', color: 'warning' },
  { stage: 'Проверка в Правительстве', status: 'В Правительстве', color: 'processing' },
  { stage: 'Проверка в Правительстве', status: 'Требуется исправление', color: 'error' },
  { stage: 'Проверка в Правительстве', status: 'На расторжении', color: 'error' },
  { stage: 'Тестирование оборудования', status: 'Ожидает отправки', color: 'warning' },
  { stage: 'Тестирование оборудования', status: 'На тестировании', color: 'processing' },
  { stage: 'Тестирование оборудования', status: 'Требуется исправление', color: 'error' },
  { stage: 'Тестирование оборудования', status: 'На расторжении', color: 'error' },
  { stage: 'Завершение работ', status: 'Требуется подпись', color: 'warning' },
  { stage: 'Завершение работ', status: 'Услуга оказана', color: 'success' },
  { stage: 'Завершение работ', status: 'Договор расторгнут', color: 'error' },
  { stage: 'Неактивная заявка', status: 'Черновик', color: 'default' },
  { stage: 'Неактивная заявка', status: 'В архиве', color: 'default' },
] as const;

/** Independent examples as printed in My Requests.jpg; no detail record is inferred. */
export const requestCards: readonly RequestCardData[] = [
  {
    key: 'kolomenskoye-list-example', id: 'СКУД-2026-0009', tab: 'active',
    name: 'ЖК «Коломенское»', service: 'Установка и регистрация СКУД',
    address: 'г. Москва, Огородный проезд, земельный участок 6/1', status: 'Ожидает приёмки',
    statusColor: 'warning', date: 'сегодня', workFormat: 'Только монтаж', messages: 3,
  },
  {
    key: 'multifunctional-list-example', id: 'СКУД-2026-0012', tab: 'active',
    name: 'МФК «Речной квартал»',
    service: 'Установка и регистрация СКУД', address: 'г. Москва, Ленинградское шоссе, вл. 69',
    status: 'Получаем предложения', statusColor: 'processing', date: 'сегодня',
    workFormat: 'Монтаж и ТО', offers: 6,
  },
];

export const archivedRequestExample: RequestCardData = {
  ...requestCards[0], key:'kolomenskoye-archived-example', id:'СКУД-2026-0003', name:'БЦ «Сокол»', address:'г. Москва, Волоколамское шоссе, вл. 10', date:'21.09.2026', tab:'archive',
  status:'Заявка отозвана', statusColor:'default', messages:undefined,
};

export type RequestStatusFilter = 'total' | 'action' | 'work' | 'termination' | 'completed';

/** Explicit groups from the customer status catalog; color alone is not a status rule. */
const requestStatusGroups: Readonly<Record<Exclude<RequestStatusFilter, 'total'>, readonly string[]>> = {
  action: ['Подготовка к монтажу', 'Ожидает приёмки', 'Отправлено на доработку', 'Ожидает отправки', 'Требуется исправление', 'Требуется подпись'],
  work: ['Получаем предложения', 'В работе', 'В Правительстве', 'На тестировании'],
  termination: ['На расторжении', 'Договор расторгнут'],
  completed: ['Услуга оказана'],
};

export function requestMatchesStatusFilter(request: RequestCardData, filter: RequestStatusFilter): boolean {
  return filter === 'total' || requestStatusGroups[filter].includes(request.status);
}

/** Initial sample values; MyRequests calculates the current counts from its cards. */
export interface RequestSummaryItem { label: string; value: number; color?: string }

export const requestSummary: readonly RequestSummaryItem[] = [
  { label: 'Всего активных заявок', value: 2 },
  { label: 'Требует действия', value: 1, color: '#ffe58f' },
  { label: 'В работе', value: 1, color: '#91caff' },
  { label: 'Расторжение', value: 0, color: '#ffccc7' },
  { label: 'Завершено', value: 0, color: '#b7eb8f' },
] as const;

export const requestEmptyStateCopy: Readonly<Record<RequestTab, string>> = {
  active: 'Активных заявок нет',
  drafts: 'Сохранённых черновиков нет',
  archive: 'Архивных заявок нет',
};
