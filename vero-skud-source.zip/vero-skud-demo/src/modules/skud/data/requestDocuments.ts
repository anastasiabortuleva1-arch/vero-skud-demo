import type { LocalDocument } from '../components/DocumentUpload';

/** Preserve original uploads and prefer downloadable files over metadata-only fixtures. */
export function mergeRequestDocuments(...groups: ReadonlyArray<ReadonlyArray<LocalDocument | undefined>>) {
  const documents = new Map<string, LocalDocument>();
  for (const group of groups) for (const document of group) {
    if (!document) continue;
    const key = document.name.trim().toLocaleLowerCase('ru-RU');
    const previous = documents.get(key);
    if (!previous || (!previous.file && document.file)) documents.set(key, document);
  }
  return [...documents.values()];
}

/** A successful local demo records metadata only; it does not produce a signed PDF. */
export const signedRequestDocument = (name: string): LocalDocument => ({ name, size: 12288 });
export const requestContractName = 'Договор №2026-СВ-018/КУ.pdf';
export const requestReadinessName = 'Акт готовности к монтажу.pdf';
export const requestAcceptanceName = 'Акт выполненных работ.pdf';
