import type { LocalDocument } from '../components/DocumentUpload';

export type RegistrationFormState = 'empty' | 'filled' | 'not-found' | 'loading' | 'uploaded';

export interface RegistrationFormData {
  uin: string;
  objectName: string;
  address: string;
  fundingSource: string;
  placementPlan?: LocalDocument;
  technicalDevices?: LocalDocument;
}

export const registrationFormInitialData: RegistrationFormData = {
  uin: 'HH8212-08-0001-001',
  objectName: 'ЖК Коломенское',
  address: 'г. Москва, Огородный проезд, земельный участок 6/1',
  fundingSource: 'Внебюджетные источники',
};

export const registrationFundingOptions = ['Внебюджетные источники', 'Городской бюджет'] as const;

export const registrationUploadLabels = {
  placementPlan: { title: 'Схема размещения СКУД', description: 'Загрузите файл в формате PDF', accept: '.pdf,application/pdf' },
  technicalDevices: { title: 'Состав технических средств СКУД в табличной форме', description: 'Загрузите файл в формате XLSX', accept: '.xlsx,application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' },
} as const;

export const registrationFormErrors = {
  objectName: 'Не удалось найти объект. Введите данные вручную',
  address: 'Не удалось найти объект. Введите данные вручную',
  fundingSource: 'Не удалось найти объект. Выберите вручную',
} as const;
