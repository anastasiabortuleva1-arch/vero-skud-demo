/** Screen fixtures from analysis/executor/install-0…18, finish-0…5 and states/executor-rework-0…3. */
export type ExecutorWorkStage =
  | 'preparation' | 'readiness' | 'readiness-sign' | 'readiness-sign-error' | 'readiness-signed'
  | 'working' | 'missing-documents' | 'uploading' | 'checking' | 'validated'
  | 'npa-error' | 'npa-error-submit' | 'correction' | 'correction-uploading'
  | 'rework' | 'rework-missing-scheme' | 'rework-uploading' | 'rework-ready'
  | 'review' | 'acceptance' | 'acceptance-sign' | 'registration'
  | 'finishing' | 'finish-sign' | 'finish-signing' | 'finish-sign-error' | 'finish-signed' | 'finished';

export const executorWorkStages: readonly ExecutorWorkStage[] = [
  'preparation', 'readiness', 'readiness-sign', 'readiness-sign-error', 'readiness-signed',
  'working', 'missing-documents', 'uploading', 'checking', 'validated', 'npa-error',
  'npa-error-submit', 'correction', 'correction-uploading', 'review', 'acceptance',
  'rework', 'rework-missing-scheme', 'rework-uploading', 'rework-ready',
  'acceptance-sign', 'registration', 'finishing', 'finish-sign', 'finish-signing',
  'finish-sign-error', 'finish-signed', 'finished',
];
export const executorWork = {
  id: 'СКУД-2026-0009', title: 'ЖК «Коломенское» — установка и регистрация СКУД',
  object: {
    uin: 'HH8212-08-0001-001',
    address: 'г. Москва, внутригородская территория муниципальный округ Бутырский, Огородный проезд, земельный участок 6/1',
    financing: 'Внебюджетные источники', workFormat: 'С дальнейшим ТО', schemePreparedBy: 'Подготовит исполнитель',
  },
  steps: ['Коммерческое предложение', 'Монтаж оборудования', 'Регистрация и подключение', 'Завершение работ'],
  // The finish reference uses these different captions. Keep the visible wording per screen.
  finishSteps: ['Подбор исполнителя', 'Монтаж оборудования', 'Проверка в Правительстве', 'Завершение работ'],
  preparationTitle: 'Дождитесь подтверждения готовности к монтажу',
  preparationDescription: 'Заказчик сообщит, когда площадка будет готова. После этого можно приступить к монтажу',
  readinessTitle: 'Подпишите акт готовности к монтажу',
  readinessDescription: 'Подтвердите, что ознакомились с актом и готовы приступить к монтажу. Дата подписания зафиксирует начало работ',
  acceptanceTitle: 'Подпишите акт приёма-сдачи выполненных работ',
  acceptanceDescription: 'Подтвердите, что выполненные работы соответствуют заявке. Оплата будет перечислена после завершения всех этапов заявки',
  finishTitle: 'Подпишите акт ввода оборудования в эксплуатацию',
  finishDescription: 'После подписания заявка будет завершена, а средства перечислены исполнителю',
  monitoringTitle: 'Мониторинг активен',
  monitoringDescription: 'Тестирование успешно пройдено: СКУД подключены к городским системам, сертификат выдан. Объект доступен в разделе мониторинга',
  resultDescription: 'Добавьте готовые материалы и отправьте их заказчику',
  rework: {
    status: 'Требуется доработка', stepStatus: 'В работе', title: 'Возвращено на доработку',
    commentLabel: 'Комментарий заказчика', comment: 'Перенесите терминал у въезда ближе к посту охраны и укажите на схеме точки подключения к сети.',
    composition: 'Состав технических средств СКУД в табличной форме2.xlsx',
  },
  additionalDescription: 'Если в ходе монтажа или проверки потребуются дополнительные работы, оформите их через дополнительное соглашение',
  faceIdTitle: 'Недостаточно терминалов Face ID',
  faceIdDescription: 'Для объекта с указанными параметрами требуется не менее 4 терминалов. Сейчас указано 3. Скорректируйте состав и повторите проверку',
  checking: 'Проверяем состав СКУД на соответствие требованиям нормативного правового акта',
  valid: 'Состав СКУД соответствует требованиям нормативного правового акта',
  invalid: 'Не соответствует требованиям нормативного правового акта',
  documents: {
    readiness: 'Акт готовности к монтажу.pdf', acceptance: 'Акт приёма-сдачи выполненных работ.pdf',
    finish: 'Акт ввода оборудования в эксплуатацию.pdf',
    composition: 'Состав технических средств биометрической СКУД в табличной форме.xlsx',
    scheme: 'Схема размещения СКУД.pdf',
  },
  chat: { date: '20 августа 2026 г.', message: 'Добрый день! Площадка готова к монтажу. Согласуйте, пожалуйста, время приезда бригады с ответственным на объекте.', time: '14:30' },
  signedTitle: 'Документ успешно подписан', signedDescription: 'Электронная подпись добавлена',
  errorTitle: 'Не удалось подписать документ', errorDescription: 'Повторите попытку или вернитесь назад',
  credited: 'Сумма в размере 753 120,00 ₽ зачислена на ваш баланс',
} as const;

export const executorWorkSources = {
  preparation: '6410:330908', readiness: '6410:331003', readinessSign: '6410:331094',
  readinessError: '6410:331317', readinessSuccess: '6410:331512',
  missingDocuments: '6691:272366', uploading: '6410:331615', checking: '6410:331930',
  validated: '6410:332147', npaError: '6410:332583', npaErrorSubmit: '6455:158527',
  correction: '6455:156003', correctionUploading: '6455:156596', review: '6455:157960',
  acceptance: '6410:333263', acceptanceSign: '6439:334272',
  rework: '6410:335784', reworkMissingScheme: '6455:160519',
  reworkUploading: '6455:161102', reworkReady: '6410:336018', reworkOverview: '6410:335783',
  finishing: '6410:333516', finishSign: '6410:333761', finishSigning: '6410:334042',
  finishError: '6410:334770', finishSuccess: '6410:334297', finished: '6410:334536',
} as const;
