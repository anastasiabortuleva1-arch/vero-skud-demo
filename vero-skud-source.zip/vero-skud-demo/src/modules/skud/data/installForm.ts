import type { LocalDocument } from '../components/DocumentUpload';

export type InstallFormStep = 1 | 2;
export type YesNoValue = 'Да' | 'Нет' | '';
export type EquipmentAvailability = 'Да, оборудование в наличии' | 'Оборудования нет' | '';
export type SchemePreparation = 'Подготовим самостоятельно' | 'Подготовит исполнитель' | '';
export type EmployeeCount = 'Менее 1000' | 'Более 1000' | '';
export type WorkFormat = 'С дальнейшим ТО' | 'Без дальнейшего ТО' | '';
export type Audience = 'Все исполнители' | 'Выбранные исполнители' | '';
export type StorageType = 'SSD' | 'HDD' | '';

export interface InstallFormData {
  uin: string;
  objectName: string;
  address: string;
  fundingSource: string;
  equipmentAvailability: EquipmentAvailability;
  schemePreparation: SchemePreparation;
  checkpointCount: string;
  turnstilesAvailable: YesNoValue;
  turnstilesPerPoint: string;
  turnstileModel: string;
  requiresWorkstation: YesNoValue;
  internetAtCheckpoint: YesNoValue;
  externalStaticIp: YesNoValue;
  employeeCount: EmployeeCount;
  faceIdTerminals: string;
  accessController: string;
  serverModel: string;
  processorModel: string;
  ram: string;
  storageVolume: string;
  storageType: StorageType;
  usesCrypto: YesNoValue;
  cryptoModel?: string;
  cryptoLocation?: string;
  sitePlan?: LocalDocument;
  workFormat: WorkFormat;
  audience: Audience;
  selectedExecutors?: string[];
}

export const emptyInstallFormData: InstallFormData = {
  uin: '', objectName: '', address: '', fundingSource: '', equipmentAvailability: '', schemePreparation: '',
  checkpointCount: '', turnstilesAvailable: '', turnstilesPerPoint: '', turnstileModel: '',
  requiresWorkstation: '', internetAtCheckpoint: '', externalStaticIp: '', employeeCount: '',
  faceIdTerminals: '', accessController: '', serverModel: '', processorModel: '', ram: '', storageVolume: '',
  storageType: '', usesCrypto: '', workFormat: '', audience: '',
};

export const knownInstallObject = {
  uin: 'HH8212-08-0001-001',
  objectName: 'ЖК Коломенское',
  address: 'г. Москва, Огородный проезд, земельный участок 6/1',
  fundingSource: 'Внебюджетные источники',
} as const;

export const installFundingOptions = ['Внебюджетные источники', 'Городской бюджет'] as const;
export const installYesNoOptions: readonly YesNoValue[] = ['Да', 'Нет'];
export const installEquipmentOptions: readonly EquipmentAvailability[] = ['Да, оборудование в наличии', 'Оборудования нет'];
export const installSchemeOptions: readonly SchemePreparation[] = ['Подготовим самостоятельно', 'Подготовит исполнитель'];
export const installEmployeeOptions: readonly EmployeeCount[] = ['Менее 1000', 'Более 1000'];
export const installWorkFormatOptions: readonly WorkFormat[] = ['С дальнейшим ТО', 'Без дальнейшего ТО'];
export const installAudienceOptions: readonly Audience[] = ['Все исполнители', 'Выбранные исполнители'];
export const installExecutorOptions = ['Монтаж Сервис-М', 'Контур Безопасности', 'Биометрия Про', 'Интегра Системы', 'Точка Доступа', 'Городские Системы Контроля', 'Периметр Инжиниринг', 'Сигнал Интеграция', 'СКУД Технологии', 'Безопасный Объект', 'Доступ Сервис'] as const;
export const installStorageOptions: readonly StorageType[] = ['SSD', 'HDD'];

export const installFormErrors = {
  objectName: 'Не удалось найти объект. Введите данные вручную',
  address: 'Не удалось найти объект. Введите данные вручную',
  fundingSource: 'Не удалось найти объект. Выберите вручную',
} as const;

export const installPublicationError = {
  title: 'Не удалось разместить заявку',
  description: 'Повторите попытку или вернитесь назад',
} as const;
