import type { ExecutorRequestIdentity } from './executorRequestIdentity';
import type { ExecutorWorkStage } from './executorWork';
export interface ExecutorResponse extends ExecutorRequestIdentity {
  key:string; tab:'active'|'archive'; status:string; color:'warning'|'processing'|'success'|'default'|'error';
  group:'action'|'work'|'termination'|'completed'; deadline:string; messages?:number; stage?:ExecutorWorkStage;
}
export const executorResponseFixtures:ExecutorResponse[]=[
  {key:'kolomenskoye-work',id:'СКУД-2026-0009',title:'Установка и регистрация СКУД',name:'ЖК «Коломенское»',address:'г. Москва, Огородный проезд, земельный участок 6/1',workFormat:'Только монтаж',uin:'HH8212-08-0001-001',tab:'active',status:'В работе',color:'warning',group:'work',deadline:'28.11.2026',messages:10,stage:'working'},
  {key:'river-work',id:'СКУД-2026-0012',title:'Установка и регистрация СКУД',name:'МФК «Речной квартал»',address:'г. Москва, Ленинградское шоссе, вл. 69',workFormat:'Монтаж и ТО',tab:'active',status:'Подготовка к монтажу',color:'processing',group:'action',deadline:'01.02.2027',stage:'preparation'},
  {key:'sokol-archive',id:'СКУД-2026-0003',title:'Установка и регистрация СКУД',name:'БЦ «Сокол»',address:'г. Москва, Волоколамское шоссе, вл. 10',workFormat:'Только монтаж',tab:'archive',status:'Завершено',color:'success',group:'completed',deadline:'21.09.2026',stage:'finished'},
  {key:'severny-archive',id:'СКУД-2026-0005',title:'Установка и регистрация СКУД',name:'ЖК «Северный парк»',address:'г. Москва, Дмитровское шоссе, вл. 124',workFormat:'Монтаж и ТО',tab:'archive',status:'Заявка отозвана',color:'default',group:'termination',deadline:'25.09.2026'},
];
export function responseWorkStatus(stage:ExecutorWorkStage):Pick<ExecutorResponse,'status'|'color'|'group'|'tab'> {
 if(stage==='finished')return {status:'Завершено',color:'success',group:'completed',tab:'active'};
 if(stage==='preparation')return {status:'Подготовка к монтажу',color:'processing',group:'action',tab:'active'};
 if(stage.startsWith('rework')||stage.includes('error')||stage.includes('missing'))return {status:'Требуется доработка',color:'error',group:'action',tab:'active'};
 if(stage.includes('sign'))return {status:'Требуется подпись',color:'warning',group:'action',tab:'active'};
 if(stage==='review')return {status:'На приёмке у заказчика',color:'processing',group:'work',tab:'active'};
 if(stage==='registration'||stage==='finishing')return {status:'Регистрация и подключение',color:'processing',group:'work',tab:'active'};
 return {status:'В работе',color:'warning',group:'work',tab:'active'};
}
