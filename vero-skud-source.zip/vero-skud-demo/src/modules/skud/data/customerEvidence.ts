/**
 * Readable labels from the saved customer installation exports, 2026-10-06.
 * This is evidence for separate mockup variants, not a request record or state machine.
 * PDF extraction splits letters and overlays dialogs; only unambiguous words are restored.
 */
export type CustomerExport =
  | 'form' | 'selection' | 'install' | 'government' | 'test' | 'finish';

export interface CustomerEvidenceSource {
  /** Relative to skud-local. Coordinates locate text in the exported page, not a frame. */
  file: `analysis/customer-install/${CustomerExport}.txt`;
  coordinates: string;
}

export interface CustomerEvidenceText {
  text: string;
  sources: readonly CustomerEvidenceSource[];
  note?: string;
}

const source = (file: CustomerExport, coordinates: string): CustomerEvidenceSource => ({
  file: `analysis/customer-install/${file}.txt`, coordinates,
});

const evidence = (
  text: string,
  file: CustomerExport,
  coordinates: string,
  note?: string,
): CustomerEvidenceText => ({ text, sources: [source(file, coordinates)], ...(note ? { note } : {}) });

export const customerEvidenceContext = {
  branch: 'Новая заявка МОНТАЖ+РЕГИСТРАЦИЯ ТСОФ',
  branchUrl: 'https://www.figma.com/design/WJfF10N99vjCLaWkcfClG1/workspace_vero_interfejs?node-id=6143-57851',
  customerSectionUrl: 'https://www.figma.com/design/WJfF10N99vjCLaWkcfClG1/workspace_vero_interfejs?node-id=6143-51880',
  formVariantsUrl: 'https://www.figma.com/design/WJfF10N99vjCLaWkcfClG1/workspace_vero_interfejs?node-id=5366-215648',
  summary: 'analysis/customer-summary.md',
  scope: 'Названия и независимые примеры из сохранённых выгрузок; концы стрелок и отдельные фреймы не установлены.',
} as const;

/** Order is printed in the mockup; it does not encode allowed transitions. */
export const customerStages = [
  { number: 0, ...evidence('Формирование заявки', 'form', '398,3274', 'Внешняя подпись этапа.') },
  { number: 1, ...evidence('Подбор исполнителя', 'selection', '17129,3337; 21601,2923') },
  { number: 2, ...evidence('Монтаж оборудования', 'install', '28926,3337; 31882,1459') },
  { number: 3, ...evidence('Проверка в Правительстве', 'government', '48457,3337; 49629,2096') },
  { number: 4, ...evidence('Тестирование оборудования', 'test', '59924,3337; 60288,4440') },
  { number: 5, ...evidence('Завершение работ', 'finish', '65728,3337; 66900,4678') },
] as const;

export const customerFields = {
  object: [
    evidence('УИН объекта капитального строительства', 'form', '2502,4262'),
    evidence('УИН проекта строительства', 'form', '7530,6301', 'Отдельный вариант формы.'),
    evidence('Наименование объекта', 'form', '5856,4387'),
    evidence('Адрес объекта', 'form', '6374,4387'),
    evidence('Источник финансирования', 'form', '15478,4248'),
    evidence('Имеется ли оборудование для подключения?', 'form', '2502,4415'),
    evidence('Кто подготовит схему размещения СКУД на объекте?', 'form', '2502,4586'),
  ],
  technical: [
    evidence('Количество КПП на объекте', 'form', '9204,2038', 'В выгрузке последние слова продублированы.'),
    evidence('Турникеты в наличии?', 'form', '9549,2041'),
    evidence('Количество турникетов на одну точку', 'form', '11473,4348'),
    evidence('Модель турникета', 'form', '10782,4422'),
    evidence('Требуется ли АРМ?', 'form', '9204,2229'),
    evidence('Есть ли доступ в Интернет на КПП?', 'form', '9549,2229'),
    evidence('Есть ли внешний статический IP-адрес?', 'form', '9895,2226'),
    evidence('Численность сотрудников на объекте', 'form', '9204,4613'),
    evidence('Марка и модель терминалов Face ID', 'form', '9204,2415'),
    evidence('Марка и модель контроллера СКУД', 'form', '9549,2417'),
    evidence('Марка и модель сервера', 'form', '9204,2605'),
    evidence('Модель процессора', 'form', '9549,2602'),
    evidence('Оперативная память', 'form', '9895,2605', 'В поле показана единица ГБ.'),
    evidence('Объём накопителя', 'form', '9204,2675', 'В поле показана единица ТБ.'),
    evidence('Тип накопителя', 'form', '9549,2679'),
    evidence('Используется ли СКЗИ?', 'form', '9204,2864'),
  ],
  conditions: [
    evidence('Строительный генеральный план', 'form', '9204,2990; 9281,3003', 'Подпись загрузки требует PDF.'),
    evidence('Выберите формат работы', 'form', '9227,3210'),
    evidence('Кто увидит заявку?', 'form', '10782,5151'),
    evidence('УИН ОКС', 'form', '15133,4252'),
    evidence('Адрес ОКС', 'form', '15133,4312'),
    evidence('Формат работы', 'form', '15824,4248'),
    evidence('Схема расположения СКУД', 'form', '15824,4308'),
  ],
  work: [
    evidence('Комментарий (необязательно)', 'install', '29797,11697', 'Окно дополнительных работ.'),
    evidence('Укажите замечания к работе, чтобы исполнитель мог внести необходимые изменения', 'install', '41443,7421–7443'),
    evidence('Укажите, что нужно исправить', 'install', '41443,8797', 'Ошибка пустого комментария доработки.'),
    evidence('Введите комментарий', 'install', '34103,1537', 'Вариант «Иное основание».'),
    evidence('Введите сообщение', 'test', '62035,5843; 62026,5855'),
    evidence('Пакет данных для тестирования', 'test', '63680,4554', 'Основная подпись загрузки требует JSON о первом тестовом проходе.'),
  ],
} as const;

/** Options are visible labels only: no requiredness, defaults or selection rules. */
export const customerFieldOptions = {
  equipment: [
    evidence('Да, оборудование в наличии', 'form', '2526,4477'),
    evidence('Оборудования нет', 'form', '2526,4507'),
  ],
  boolean: [evidence('Да', 'form', '9624,2076'), evidence('Нет', 'form', '9787,2076')],
  scheme: [
    evidence('Подготовим самостоятельно', 'form', '2526,4651'),
    evidence('Подготовит исполнитель', 'form', '15824,4334', 'Значение в условиях страницы заявки.'),
  ],
  employees: [evidence('Менее 1000', 'form', '9246,4648'), evidence('Более 1000', 'form', '9416,4648')],
  storage: [evidence('SSD', 'form', '9620,2710'), evidence('HDD', 'form', '9784,2714')],
  maintenance: [
    evidence('С дальнейшим ТО', 'form', '9232,3293; 9285,3282'),
    evidence('Без дальнейшего ТО', 'form', '9772,3293; 9843,3280'),
    evidence('Монтаж и дальнейшее ТО', 'install', '31765,1235', 'Отдельное значение условий страницы.'),
  ],
  audience: [
    evidence('Все исполнители', 'form', '10815,5200'),
    evidence('Выбранные исполнители', 'form', '10825,5230; 10806,5242'),
  ],
  additionalWork: [
    evidence('Дополнительный монтаж', 'install', '29821,11632; 29933,11629'),
    evidence('Дополнительное оборудование', 'install', '29821,11666'),
  ],
  termination: [
    evidence('Основание предусмотрено договором', 'install', '34107,1400'),
    evidence('Основание предусмотрено законом', 'install', '35598,1484'),
    evidence('Нарушение договора контрагентом', 'install', '35598,1518'),
    evidence('Иное основание', 'install', '34107,1502; 34147,1502'),
  ],
} as const;

/** Grouping describes where text was observed; no success/error effect is inferred. */
export const customerStates = {
  requests: [
    evidence('Активных заявок нет', 'form', '1206,4847'),
    evidence('Получаем предложения', 'form', '15692,4128'),
    evidence('Пока никто не откликнулся', 'form', '15393,4638'),
    evidence('Заявка успешно опубликована', 'form', '15101,4185; 15178,4196; 15223,4209'),
    evidence('Не удалось разместить заявку', 'form', '12585,6551'),
    evidence('Заявка отозвана', 'selection', '22329,3012'),
  ],
  objectLookup: [
    evidence('Не удалось найти объект. Введите данные вручную', 'form', '7530,6464'),
    evidence('Не удалось найти объект. Выберите вручную', 'form', '7530,6562', 'Другой вариант текста.'),
    evidence('Обновляем данные', 'form', '8325,11599'),
    evidence('Проверка НПА', 'form', '7423,12935', 'Внешняя подпись состояния.'),
    evidence('Проверка НПА пройдена', 'form', '8974,12935', 'Внешняя подпись состояния.'),
  ],
  installation: [
    evidence('Подготовка к монтажу', 'install', '31633,1095'),
    evidence('В работе', 'install', '34799,4132'),
    evidence('Ожидает приёмки', 'install', '38099,4128'),
    evidence('Отправляем на доработку', 'install', '44811,7466'),
    evidence('Отправлено на доработку', 'install', '46754,7090'),
    evidence('Формируем акт выполненных работ', 'install', '41173,4504', 'Внешняя подпись; состав акта требует сверки.'),
  ],
  government: [
    evidence('Ожидает отправки', 'government', '49629,2122; 49639,2134'),
    evidence('На проверке', 'government', '57361,4132'),
    evidence('Требуется исправление', 'government', '57361,5730'),
    evidence('Проверка сведений об УИН ОКС', 'government', '56838,4599'),
    evidence('Проверка сведений о СКУД (тип, количество)', 'government', '56838,4647'),
    evidence('Оценка расположения СКУД', 'government', '56838,6433'),
    evidence('Необходимо скорректировать расположение СКУД', 'government', '56862,6210', 'Комментарий Правительства Москвы в примере.'),
  ],
  testing: [
    evidence('Ожидает отправки', 'test', '60847,4134'),
    evidence('На тестировании', 'test', '64219,4132'),
    evidence('Проводится тестирование', 'test', '63696,4686'),
    evidence('Не удалось провести тестирование. Попробуйте запустить повторно', 'test', '63696,8316; 63933,8328'),
    evidence('Требуется исправление', 'finish', '66129,7906'),
    evidence('Тестирование выявило замечания', 'finish', '67170,8328'),
  ],
  completion: [
    evidence('Требуется подпись', 'finish', '66651,4134'),
    evidence('Услуга оказана', 'finish', '71469,4128'),
    evidence('Подпишите акт, чтобы перейти к мониторингу', 'finish', '66212,6435'),
  ],
  signature: [
    evidence('Подписано исполнителем', 'selection', '21282,5558'),
    evidence('Документ успешно подписан', 'selection', '25934,4467'),
    evidence('Электронная подпись добавлена', 'selection', '25934,4494'),
    evidence('Не удалось подписать документ', 'finish', '71101,5817; 71127,5820; 71182,5820'),
  ],
  additionalWork: [
    evidence('Исполнитель направил дополнительное соглашение', 'install', '33862,11604'),
    evidence('Запрос отправлен исполнителю', 'install', '31469,11904'),
  ],
  termination: [
    evidence('Договор расторгнут', 'install', '40285,868', 'Итоговая внешняя подпись; соседние хлебные крошки относятся к «Мониторинг ОКС».'),
    evidence('Не удалось отправить заявку', 'install', '38589,2716–38902,2719'),
    evidence('Укажите причину расторжения договора', 'install', '34083,2866', 'Ошибка пустого комментария только в варианте «Иное».'),
  ],
  monitoring: [
    evidence('Всё работает штатно', 'finish', '74891,4275'),
    evidence('Работает', 'finish', '75217,4492'),
    evidence('Статус обновлён: 2 мин назад', 'finish', '75120,4125'),
  ],
} as const;

export const customerDocuments = [
  evidence('СГП.pdf', 'form', '10838,4850'),
  evidence('СГП.dwg', 'install', '47015,9226', 'Отдельный пример исходного файла; не расширяет PDF-загрузку формы.'),
  evidence('Договор № 2026-СВ-018/КУ.pdf', 'selection', '20845,5540–20968,5556'),
  evidence('Акт готовности к монтажу.pdf', 'install', '34134,2791'),
  evidence('Состав технических средств биометрической СКУД в табличной форме.xlsx', 'test', '62050,4873'),
  evidence('Схема размещения СКУД.pdf', 'test', '62050,5022'),
  evidence('Схема размещения СКУД 2.pdf', 'install', '47898,8332', 'Файл отдельной второй версии результата.'),
  evidence('Информационное сообщение.pdf', 'government', '56858,4526'),
  evidence('СКУД 1.json', 'test', '63736,4589'),
  evidence('Сертификат подключения.pdf', 'finish', '72731,4530'),
  evidence('Акт ввода оборудования в эксплуатацию.pdf', 'finish', '66160,6498', 'Сохраняется отдельно от актов выполненных работ.'),
  evidence('Акт выполненных работ.pdf', 'finish', '69372,5938', 'Другая подпись документа в соседнем варианте.'),
  evidence('Дополнительное соглашение к Договору № 2026-СВ-018/КУ.pdf', 'form', '16840,11676–16885,11692'),
] as const;

/** Independent mockup examples. Never join them by a matching object title. */
export const customerExamples = {
  formObjectFound: [
    evidence('ЖК Коломенское', 'form', '7541,4421'),
    evidence('ул. Южнопортовая, вл. 28-28А (ЮВАО, Печатники)', 'form', '8059,4419'),
  ],
  requestsListCard: [
    evidence('ЖК «Коломенское»', 'form', '762,6273'),
    evidence('ОКС-2026-0009', 'form', '762,6298'),
    evidence('г. Москва, ул. Северная, вл. 12', 'form', '762,6298'),
    evidence('Только монтаж', 'form', '786,6360'),
  ],
  requestDetail: [
    evidence('ЖК «Коломенское» — установка и регистрация СКУД', 'form', '15133,4118'),
    evidence('СКУД-2026-0009', 'form', '15133,4154'),
    evidence('г. Москва, внутригородская территория муниципальный округ Бутырский, Огородный проезд, земельный участок 6/1', 'form', '15133,4334–4356'),
    evidence('Внебюджетные источники', 'form', '15478,4274'),
  ],
  monitoring: {
    breadcrumbId: evidence('СКУД-2026-0009', 'finish', '74261,4056'),
    displayedRequestId: evidence('СКУД-2026-0001', 'finish', '74281,4212', 'Противоречит ID хлебных крошек; оба значения сохранены.'),
    contractor: evidence('МонтажСервис-М', 'finish', '74281,4242; 74410,4238'),
    devices: [
      { id: evidence('SKUD-01180-01', 'finish', '74310,4491'), location: evidence('КПП №1', 'finish', '74310,4513') },
      { id: evidence('SKUD-01180-02', 'finish', '74310,4571'), location: evidence('КПП №2', 'finish', '74310,4593') },
      { id: evidence('SKUD-01180-03', 'finish', '74310,4651'), location: evidence('КПП №3', 'finish', '74310,4673') },
    ],
  },
} as const;

export const customerEvidenceUncertainties = [
  evidence('УИН HН8212-08-0001-001: первый символ и смешение латиницы/кириллицы требуют проверки', 'form', '15133,4278'),
  evidence('Итоговые акты: ввод в эксплуатацию и выполненные работы показаны в разных вариантах; единый документ не установлен', 'finish', '66143,4442; 67749,4442; 69372,5938; 66160,6498'),
  evidence('АИТ: основная загрузка JSON против текста ошибки о фото/видео с геометкой', 'test', '60308,4594; 60308,6196; 60308,6230'),
  evidence('Отправка информационного сообщения: текст подписи обещает отправку, соседний экран содержит отдельную кнопку отправки', 'government', '51964,4752; 52160,4749; 55478,4589'),
  evidence('Суммы карточки КП и подробного КП не согласованы; формулы и общая сумма записи не установлены', 'selection', '19143,4662–19361,4766; 20793,5182–21155,5238'),
  evidence('Суммы дополнительного соглашения, резервирования и сводки различаются', 'selection', '18353,11784; 23651,12522–24013,12548'),
  evidence('Точный порядок расторжения, участия сотрудника платформы и подписания документов не установлен', 'install', '31194,1449–1471; 37317,1467; 40285,868'),
] as const;
