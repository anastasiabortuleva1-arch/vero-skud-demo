export const contractTerminationReasons = [
  'Основание предусмотрено договором',
  'Основание предусмотрено законом',
  'Нарушение договора контрагентом',
  'Иное основание',
] as const;

export type ContractTerminationReason = typeof contractTerminationReasons[number];
export type ContractTerminationStage = 'reason' | 'confirmation' | 'closed';

/** Controlled dialog state; `validationError` represents the visible empty-comment variant. */
export interface ContractTerminationData {
  stage: ContractTerminationStage;
  reason?: ContractTerminationReason;
  comment: string;
  validationError?: boolean;
}

export const contractTerminationCopy = {
  title: 'Расторгнуть договор',
  subtitle: 'Выберите основание для расторжения договора',
  reasonLabel: 'Основание для расторжения',
  commentPlaceholder: 'Введите комментарий',
  commentError: 'Укажите причину расторжения договора',
  confirmationTitle: 'Расторгнуть договор?',
  confirmationDescription: 'Заявка на расторжение будет направлена сотруднику платформы. Он свяжется с вами для уточнения деталей и дальнейших действий',
  cancel: 'Отменить',
  next: 'Далее',
  submit: 'Расторгнуть',
} as const;

export function createContractTerminationData(): ContractTerminationData {
  return { stage: 'reason', comment: '' };
}
