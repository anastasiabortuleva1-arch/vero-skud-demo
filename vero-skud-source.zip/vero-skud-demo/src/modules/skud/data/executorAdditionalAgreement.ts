import type { EquipmentPurchaseMode, OfferEquipmentLine } from './executorOffer';

export type ExecutorAdditionalAgreementState = 'idle' | 'incoming' | 'select' | 'estimate' | 'sign' | 'signing' | 'sign-error' | 'signed' | 'sent' | 'confirmed';
export type ExecutorAdditionalAgreementOrigin = 'executor' | 'customer';
export interface ExecutorAgreementService { quantity: string; unitPrice: string }
export interface ExecutorAdditionalAgreementData {
  installation: boolean;
  equipment: boolean;
  equipmentMode: EquipmentPurchaseMode;
  pricesIncludeVat: boolean;
  equipmentLines: OfferEquipmentLine[];
  maintenance: ExecutorAgreementService;
  mounting: ExecutorAgreementService;
  startDate: string;
  endDate: string;
  changeDeadline: boolean;
  newEndDate: string;
}
export interface ExecutorAdditionalAgreementTotals { vat: string; total: string }
export interface ExecutorAdditionalAgreementRequest { installation: boolean; equipment: boolean; comment?: string }

export const emptyExecutorAdditionalAgreementData: ExecutorAdditionalAgreementData = {
  installation: false, equipment: false, equipmentMode: 'Покупка оборудования', pricesIncludeVat: true,
  equipmentLines: [{equipmentType: '', name: '', quantity: '0', unitPrice: '0,00'}],
  maintenance: {quantity: '0', unitPrice: '0,00'}, mounting: {quantity: '0', unitPrice: '0,00'},
  startDate: '', endDate: '', changeDeadline: false, newEndDate: '',
};

/** These are separate visible examples. Their totals must not be derived from their line items. */
export const executorAdditionalAgreementFixtures = {
  empty: {data: emptyExecutorAdditionalAgreementData, totals: {vat: '0,00', total: '0,00'}},
  filledUnchanged: {
    data: {...emptyExecutorAdditionalAgreementData, installation: true, equipment: true,
      equipmentLines: [{equipmentType: 'Терминал Face ID', name: 'Teplo F8', quantity: '1', unitPrice: '12 827,00'}],
      maintenance: {quantity: '1', unitPrice: '2 000,00'}, mounting: {quantity: '1', unitPrice: '890,00'}},
    totals: {vat: '0,00', total: '0,00'},
  },
  filledDeadline: {
    data: {...emptyExecutorAdditionalAgreementData, installation: true, equipment: true,
      equipmentLines: [{equipmentType: 'Терминал Face ID', name: 'Teplo F8', quantity: '1', unitPrice: '12 827,00'}],
      maintenance: {quantity: '1', unitPrice: '2 000,00'}, mounting: {quantity: '1', unitPrice: '890,00'},
      changeDeadline: true, newEndDate: '12.09.2026'},
    totals: {vat: '2 194,00', total: '15 892,00'},
  },
} satisfies Record<string, {data: ExecutorAdditionalAgreementData; totals: ExecutorAdditionalAgreementTotals}>;

/** The incoming customer request, separate from the executor's editable estimate. */
export const executorAdditionalAgreementIncomingRequest: ExecutorAdditionalAgreementRequest = {
  equipment: true, installation: true,
  comment: 'Нужно установить ещё два считывателя на дополнительном входе и перенести одну точку доступа ближе к служебной зоне. Также потребуется дополнительное оборудование для подключения',
};

export const executorAdditionalAgreementCopy = {
  title: 'Дополнительные работы',
  description: 'Если в ходе монтажа или проверки потребуются дополнительные работы, оформите их через дополнительное соглашение',
  action: 'Дополнительное соглашение',
  selectTitle: 'Сформировать дополнительное соглашение',
  selectDescription: 'Укажите дополнительные работы, которые войдут в соглашение',
  installation: 'Дополнительный монтаж', equipment: 'Дополнительное оборудование',
  estimateTitle: 'Оцените работы', estimateDescription: 'Заполните данные, чтобы сформировать соглашение',
  incomingTitle: 'Получен запрос на дополнительные работы',
  incomingDescription: 'Ознакомьтесь с запросом, уточните состав работ и оборудования и рассчитайте стоимость',
  incomingAction: 'Оценить работы',
  signingDescription: 'Подпишите договор электронной подписью для отправки предложения заказчику. До выбора исполнителя вы сможете отозвать его',
  signedTitle: 'Документ успешно подписан', signedDescription: 'Документ подписан электронной подписью',
  errorTitle: 'Не удалось подписать документ', errorDescription: 'Повторите попытку или вернитесь назад',
} as const;

export const executorAdditionalAgreementSources = {
  overview: '6462:162273', idle: '6486:158762', selectEmpty: '6571:253040',
  selectInstallation: '6571:254208', selectEquipment: '6571:257143', selectBoth: '6571:253617',
  estimateCombined: '6550:195505', estimateEquipment: '6571:257715', estimateInstallation: '6571:255971',
  sign: '6571:260299', signing: '6571:260498', signError: '6571:260671', signed: '6571:260839', confirmed: '6571:260150',
  incoming: '6486:158246', incomingEmpty: '6493:143154', incomingFilled: '6493:144352',
  incomingUnchanged: '6493:145575', incomingDeadline: '6493:147526', incomingSign: '6493:163002',
  incomingSigning: '6493:164266', incomingError: '6493:165488', incomingSigned: '6493:164897', incomingConfirmed: '6493:166085',
} as const;

/**
 * Reference limits: creation's combined form is clipped after the maintenance heading/header;
 * its mounting fields/deadline controls are not reconstructed from the customer's incoming form.
 * The installation-only creation form shows two dates; incoming shows a deadline radio group.
 * No empty-selection continuation, input validation, rental-specific pricing or expanded summary is shown.
 * `sent` is a local callback boundary after the executor signs. Only external `confirmed` renders
 * the summary: the annotation explicitly requires both parties' signatures.
 * Signature outcome and displayed totals are controlled fixtures, not server/calculation results.
 */
export const executorAdditionalAgreementLimitations = [
  'Нижняя часть создания соглашения с монтажом и оборудованием скрыта в исходной модалке.',
  'Продолжение без выбранных работ и проверка полей не показаны.',
  'Подробная таблица сводки и условия аренды не показаны.',
] as const;
