import type { LocalDocument } from '../components/DocumentUpload';

export type RegistrationVariant = 'registration-only' | 'installation';
/** In-memory session snapshot. Files stay local; this type implies no server or durable storage. */
export interface RegistrationSnapshot {
  info:{uin:string;name:string;address:string;financing:string;workFormat?:string;schemePreparedBy?:string};
  scheme?:LocalDocument;
  composition?:LocalDocument;
  testFile?:LocalDocument;
}
export type RegistrationStage = 'initial' | 'ready' | 'review' | 'government-correction' | 'test-empty' | 'test-ready' | 'testing' | 'test-error' | 'test-correction' | 'test-correction-ready' | 'finish-ready' | 'finish-sign' | 'completed';
export const registrationStages: RegistrationStage[] = ['initial','ready','review','government-correction','test-empty','test-ready','testing','test-error','test-correction','test-correction-ready','finish-ready','finish-sign','completed'];
export const registrationRequest = {
  title: 'ЖК «Коломенское» — установка и регистрация СКУД',
  id: 'СКУД-2026-0009', uin: 'HH8212-08-0001-001', name: 'ЖК Коломенское',
  financing: 'Внебюджетные источники',
  address: 'г. Москва, внутригородская территория муниципальный округ Бутырский, Огородный проезд, земельный участок 6/1',
  composition: 'Состав технических средств биометрической СКУД в табличной форме.xlsx',
  scheme: 'Схема размещения СКУД.pdf', information: 'Информационное сообщение.pdf', certificate: 'Сертификат подключения.pdf',
  steps: ['Проверка в Правительстве', 'Тестирование оборудования', 'Завершение работ'],
  checks: ['Проверка сведений об УИН ОКС', 'Проверка сведений о СКУД (тип, количество)', 'Оценка расположения СКУД'],
  testingDescription: 'Платформа автоматически проверит готовность оборудования, подключит СКУД к ЕЦХД и сформирует сертификат. Обычно это занимает около 5 минут',
};

/** The five-step installation branch is separate from registration-only. */
export const registrationInstallation = {
  sources: {
    testing:'6312-458414', testReady:'6312-457908', testValidation:'6312-458964', testEmpty:'6143-64502',
    correction:'6310-457285', review:'6143-63990', send:'6143-63737', signing:'6404-120018',
    preview:'6404-119386', forming:'6310-432413', withdrawMenu:'6633-167344', withdrawAct:'6635-167882',
    initial:'6143-62704', signedNotice:'6689-270787', finishPreview:'6312-461694', finishMonitoring:'6439-335334', finishReady:'6143-65248',
  },
  steps:['Подбор исполнителя','Монтаж оборудования','Проверка в Правительстве','Тестирование оборудования','Завершение работ'],
  name:'ЖК «Коломенское»',
  workFormat:'С дальнейшим ТО', schemePreparedBy:'Подготовит исполнитель',
  additionalDescription:'Если в ходе монтажа или проверки потребуются дополнительные работы, оформите их через дополнительное соглашение',
  testValidationDescription:'Добавьте фото и/или видео с геометкой, датой и временем съёмки',
  actTitle:'Подпишите акт ввода оборудования в эксплуатацию',
  actDescription:'После подписания заявка будет завершена, а средства перечислены исполнителю',
  act:'Акт ввода оборудования в эксплуатацию.pdf',
  monitoringTitle:'Подпишите акт, чтобы перейти к мониторингу',
  monitoringDescription:'Подпишите акт выполненных работ, чтобы закрыть заявку перед переходом к мониторингу',
  withdrawalTitle:'Чтобы отозвать заявку, подпишите акт',
  withdrawalDescription:'Чтобы отозвать заявку на этом этапе, подпишите акт ввода оборудования в эксплуатацию',
  chat:{date:'20 августа 2026 г.',message:'Состав оборудования согласован. После проверки загрузите пакет JSON из клиента БД СКУД, чтобы начать тестирование.',time:'14:30'},
  // External annotation, not an accelerated local timer or a real signing/payment rule.
  automaticSignatureAnnotation:'Висит до тех пор, пока заказчик не подпишет (но максимум 15 дней, после чего подписывается автоматически)',
} as const;

/** Independent document example inside finish-0; it is not a contract or balance of this SKUD request.
 * Only confidently legible text is transcribed. Bank details and the small service descriptions are omitted.
 */
export const installationActPreview = {
  source:'analysis/states/customer-finish-0.jpg',
  title:'Акт приема-передачи оказанных услуг № 10 от 19 сентября 2025 г.',
  executor:'ООО «ЗЕМНОЕ ВРЕМЯ»', customer:'ООО «УСПЕХ»',
  columns:['№','Наименование работ, услуг','Кол-во','Ед.','Цена','Сумма'],
  total:'49 600,00', tax:'Без налога (НДС)',
  amount:'Всего оказано услуг 2, на сумму 49 600,00 руб.',
  words:'Сорок девять тысяч шестьсот рублей 00 копеек',
  conclusion:'Вышеперечисленные услуги выполнены полностью и в срок. Заказчик претензий по объёму, качеству и срокам оказания услуг не имеет.',
} as const;

/** Edit-2's loading underlay is a different TSOF example; only the shown loading caption is reused. */
export const registrationEdit = {
  sources:{initial:'6537-164170',updated:'6537-163991',loading:'6537-163685',changedModal:'6537-163484',modal:'6537-163283'},
  heading:'Инфраструктура объекта', uin:'УИН объекта капитального строительства',
  name:'Наименование объекта капитального строительства', address:'Адрес ОКС', loading:'Обновляем данные',
  updatedAddress:'Филевский бульвар (ул. Новозаводская)',
  objectDataCorrection:'Проверьте УИН ОКС и сведения о составе СКУД. Указанные данные не совпадают с приложенными материалами. Внесите исправления и сформируйте информационное сообщение повторно',
} as const;

/** Separate visible document example; its IDs and address do not identify the request behind the modal. */
export const registrationSignPreview = {
  source: 'analysis/states/registration-sign.jpg',
  title: 'Информационное сообщение',
  subtitle: ['о подключении технических средств объективной фиксации', 'на объекте капитального строительства'],
  note: 'Документ сформирован автоматически на основе данных заявки',
  sections: [
    { title: '1. Сведения о заявке', lines: [
      'Номер заявки: ОКС-2026-0009',
      'Дата формирования: 10.05.2026',
      'Услуга: Мониторинг ОКС (ТСОФ)',
      'Заявитель: ООО «СтройПроект»',
    ] },
    { title: '2. Сведения об объекте', lines: [
      'УИН ОКС: 1234567890',
      'Наименование объекта: Жилой комплекс «Северный парк»',
      'Адрес объекта: г. Москва, ул. Примерная, д. 10',
    ] },
    { title: '3. Сведения о подключаемых ТСОФ', lines: [
      'Камеры видеонаблюдения — 6 шт.',
      'Датчики шума — 2 шт.',
      'Датчики пыли — 2 шт.',
    ], after: 'Схема размещения ТСОФ: приложена' },
    // Only the heading is visible above the viewer footer; no attachment list is inferred.
    { title: '4. Приложенные материалы', lines: [] },
  ],
} as const;
