import { RequestDocuments } from './RequestDocuments';
import { mergeRequestDocuments, signedRequestDocument, requestContractName } from '../data/requestDocuments';
import { useEffect, useRef, useState } from 'react';
import { Button, Dropdown, Input, Modal, Select, Spin, Switch, Tag } from 'antd';
import { DeleteOutlined, DownloadOutlined, MinusOutlined, MoreOutlined, PlusOutlined } from '@ant-design/icons';
import type { LocalDocument } from './DocumentUpload';
import { SharedContractPreview } from './AdditionalAgreement';
import './ExecutorOffer.css';
import type { ExecutorRequestIdentity } from '../data/executorRequestIdentity';
import {
  emptyExecutorOfferData,
  emptyExecutorOfferTotals,
  executorOfferCopy,
  filledExecutorOfferData,
  filledExecutorOfferTotals,
  pendingOfferSummary,
  visibleEquipmentModes,
  visibleEquipmentTypes,
  visibleVatRates,
} from '../data/executorOffer';
import type { ExecutorOfferData, ExecutorOfferStage, ExecutorOfferTotals, OfferEquipmentLine, OfferServiceLine } from '../data/executorOffer';

export interface ExecutorOfferProps {
  identity?: ExecutorRequestIdentity;
  documents?: LocalDocument[];
  onDocumentSigned?: (document: LocalDocument) => void;
  demoFillToken?: number;
  onStageChange?: (stage: ExecutorOfferStage) => void;
  onBack: () => void;
  onSubmitted: (data: ExecutorOfferData) => void;
  onWithdraw?: () => void;
  initialStage?: ExecutorOfferStage;
  initialData?: ExecutorOfferData;
  /** Literal summary values from the calling state; no totals are calculated from inputs. */
  totals?: ExecutorOfferTotals;
}

const dateExampleFormat = '01.06.2026';

function moneyField(value: string, onChange: (value: string) => void) {
  return <Input value={value} addonAfter="₽" onChange={event => onChange(event.target.value)} />;
}

function OfferLineTable({
  title,
  nameColumn,
  quantityColumn = 'Кол-во',
  priceColumn,
  line,
  onChange,
}: {
  title: string;
  nameColumn: string;
  quantityColumn?: string;
  priceColumn: string;
  line: OfferServiceLine;
  onChange: (line: OfferServiceLine) => void;
}) {
  return <section className="skud-executor-offer__line-section">
    <h3>{title}</h3>
    <div className="skud-executor-offer__table-head"><span>{nameColumn}</span><span>{quantityColumn}</span><span>{priceColumn}</span></div>
    <div className="skud-executor-offer__line-row">
      <span className="skud-executor-offer__row-number">1</span>
      <Input value={line.name} placeholder={title === 'Стоимость технического обслуживания в месяц' ? 'Техническое обслуживание' : 'Монтажные работы'} disabled onChange={event => onChange({ ...line, name: event.target.value })} />
      <Input value={line.quantity} onChange={event => onChange({ ...line, quantity: event.target.value })} />
      {moneyField(line.unitPrice, value => onChange({ ...line, unitPrice: value }))}
    </div>
  </section>;
}

export function ExecutorOffer({ identity, documents, onDocumentSigned, demoFillToken = 0, onStageChange, onBack, onSubmitted, onWithdraw, initialStage = 'form', initialData, totals }: ExecutorOfferProps) {
  const [signedDocuments,setSignedDocuments] = useState<LocalDocument[]>(() => documents !== undefined ? [] : (['signed','pending'].includes(initialStage) ? [requestContractName] : []).map(signedRequestDocument));
  const [fixtureSourceDocuments] = useState<LocalDocument[]>(() => documents === undefined ? [executorOfferCopy.sourceFile] : []);
  const initialSignedDocuments = useRef([...fixtureSourceDocuments,...signedDocuments]);
  const reportedInitialDocuments = useRef(false);
  useEffect(() => {
    if (!onDocumentSigned || reportedInitialDocuments.current) return;
    reportedInitialDocuments.current = true;
    initialSignedDocuments.current.forEach(document => onDocumentSigned(document));
  }, [onDocumentSigned]);
  function recordSigned(name: string) {
    const document = signedRequestDocument(name);
    setSignedDocuments(current => mergeRequestDocuments(current,[document]));
    onDocumentSigned?.(document);
  }
  const [data, setData] = useState<ExecutorOfferData>(() => ({
    ...emptyExecutorOfferData,
    ...(initialStage === 'filled' ? filledExecutorOfferData : {}),
    ...initialData,
    equipment: (initialData?.equipment ?? (initialStage === 'filled' ? filledExecutorOfferData.equipment : emptyExecutorOfferData.equipment)).map(line => ({ ...line })),
    maintenance: { ...(initialStage === 'filled' ? filledExecutorOfferData.maintenance : emptyExecutorOfferData.maintenance), ...initialData?.maintenance },
    installation: { ...(initialStage === 'filled' ? filledExecutorOfferData.installation : emptyExecutorOfferData.installation), ...initialData?.installation },
  }));
  const [stage, setStage] = useState<ExecutorOfferStage>(initialStage);
  const stageCallback = useRef(onStageChange);
  stageCallback.current = onStageChange;
  useEffect(() => { stageCallback.current?.(stage); }, [stage]);
  const [validationErrors, setValidationErrors] = useState(initialStage === 'validation');
  const [withdrawOpen, setWithdrawOpen] = useState(false);
  const [contractScale, setContractScale] = useState(1);
  const signingTimer = useRef<number | undefined>(undefined);

  useEffect(() => {
    if (demoFillToken <= 0) return;
    setData({
      ...filledExecutorOfferData,
      equipment: filledExecutorOfferData.equipment.map(line => ({ ...line })),
      maintenance: { ...filledExecutorOfferData.maintenance },
      installation: { ...filledExecutorOfferData.installation },
    });
    setValidationErrors(false);
    setStage('filled');
  }, [demoFillToken]);

  useEffect(() => {
    if (stage !== 'signing') return;
    signingTimer.current = window.setTimeout(() => {
      signingTimer.current = undefined;
      recordSigned(requestContractName);
      setStage('signed');
    }, 900);
    return () => {
      if (signingTimer.current !== undefined) window.clearTimeout(signingTimer.current);
    };
  }, [stage, onDocumentSigned]);

  const update = (patch: Partial<ExecutorOfferData>) => setData(current => ({ ...current, ...patch }));
  const updateEquipment = (index: number, patch: Partial<OfferEquipmentLine>) => update({ equipment: data.equipment.map((line, lineIndex) => lineIndex === index ? { ...line, ...patch } : line) });
  const updateService = (key: 'maintenance' | 'installation', value: OfferServiceLine) => update({ [key]: value });

  function validForSubmission() {
    const equipmentComplete = data.equipment.every(line => line.equipmentType && line.name.trim() && Number(line.quantity.replace(',', '.')) > 0 && Number(line.unitPrice.replace(',', '.').replace(/\s/g, '')) > 0);
    const serviceComplete = (line: OfferServiceLine) => Number(line.quantity.replace(',', '.')) > 0 && Number(line.unitPrice.replace(',', '.').replace(/\s/g, '')) > 0;
    return Boolean(data.vatRate) && equipmentComplete && serviceComplete(data.maintenance) && serviceComplete(data.installation) && Boolean(data.startDate) && Boolean(data.endDate);
  }

  function openSigning() {
    if (!validForSubmission()) {
      setValidationErrors(true);
      setStage('validation');
      return;
    }
    setValidationErrors(false);
    setStage('contract');
  }

  function sign() { setStage('signing'); }

  function complete() {
    onSubmitted({ ...data, equipment: data.equipment.map(line => ({ ...line })) });
    setStage('pending');
  }

  const validation = validationErrors || stage === 'validation';
  const isPending = stage === 'pending' || stage === 'signed';
  const visibleTotals = totals ?? (initialStage === 'filled' || demoFillToken > 0 ? filledExecutorOfferTotals : emptyExecutorOfferTotals);

  return (
    <div className="skud-executor-offer">
      <section className="skud-executor-offer__request-summary">
        <div className="skud-executor-offer__request-title"><div><h1>{identity ? `${identity.name} — ${identity.title}` : 'ЖК «Коломенское» — установка и регистрация СКУД'}</h1><span>{identity?.id ?? 'СКУД-2026-0009'}&nbsp;&nbsp; Создана сегодня</span></div>{isPending && <div className="skud-executor-offer__request-actions"><Tag color="processing">{pendingOfferSummary.status}</Tag><Dropdown trigger={['click']} menu={{ items: [{ key: 'withdraw', label: 'Отозвать отклик', danger: true, onClick: () => setWithdrawOpen(true) }] }}><Button aria-label="Дополнительные действия" type="text" icon={<MoreOutlined />} /></Dropdown></div>}</div>
        <h2>Условия заявки</h2>
        <div className="skud-executor-offer__conditions">
          <div><span>УИН ОКС</span><strong>{identity ? identity.uin ?? '—' : 'HH8212-08-0001-001'}</strong></div>
          <div><span>Источник финансирования</span><strong>Внебюджетные источники</strong></div>
          <div><span>Формат работы</span><strong>{identity?.workFormat ?? 'С дальнейшим ТО'}</strong></div>
          <div><span>Адрес ОКС</span><strong>{identity?.address ?? 'г. Москва, внутригородская территория муниципальный округ Бутырский, Огородный проезд, земельный участок 6/1'}</strong></div>
          <div><span>Схема расположения СКУД</span><strong>Подготовит исполнитель</strong></div>
        </div>
      </section>

      {isPending ? <>
        <div className="skud-executor-offer__pending-detail">
          <section className="skud-executor-offer__chat">
            <h2>Чат с заказчиком</h2>
            <div className="skud-executor-offer__chat-content"><time>20 августа 2026 г.</time><div className="skud-executor-offer__chat-message"><small>14:30</small><span>Добрый день! Просим включить в предложение настройку двух проходных и обучение оператора.</span></div></div>
            <div className="skud-executor-offer__chat-input"><span>Введите сообщение</span><Button type="primary" shape="circle" aria-label="Отправить сообщение">↑</Button></div>
          </section>
          <aside className="skud-executor-offer__pending-side">
            <section className="skud-executor-offer__steps"><div className="is-current"><b>1</b><span>Коммерческое предложение<small>На рассмотрении</small></span></div><div><b>2</b><span>Монтаж оборудования</span></div><div><b>3</b><span>Регистрация и подключение</span></div><div><b>4</b><span>Завершение работ</span></div></section>
            <section className="skud-executor-offer__documents"><h3>Документы по заявке</h3><RequestDocuments documents={documents} localDocuments={fixtureSourceDocuments} signedDocuments={signedDocuments}/></section>
          </aside>
        </div>
        <section className="skud-executor-offer__pending-card">
          <div className="skud-executor-offer__pending-head"><h2>Коммерческое предложение</h2><span>Исполнитель: {pendingOfferSummary.contractor}</span><time>Отправлено {pendingOfferSummary.sentAt}</time></div>
          <div className="skud-executor-offer__pending-columns">
            <div><h3>Общая сводка</h3><p>Покупка оборудования <strong>{pendingOfferSummary.equipmentPurchase}</strong></p><p>Монтаж <strong>{pendingOfferSummary.installation}</strong></p><p>ТО <strong>{pendingOfferSummary.maintenanceMonthly}</strong></p><p>Начало работ <strong>{pendingOfferSummary.startDate}</strong></p><p>Окончание работ <strong>{pendingOfferSummary.endDate}</strong></p></div>
            <div><h3>Итого</h3><p>Разовые расходы <strong>{pendingOfferSummary.oneTimeTotal}</strong></p><p>Регулярные расходы <strong>{pendingOfferSummary.recurringTotal}</strong></p><p>Расчёт стоимости с НДС, {pendingOfferSummary.vatCalculation}</p></div>
          </div>
          <Button type="text">Показать подробную таблицу⌄</Button>
        </section>
        <footer className="skud-executor-offer__actions"><Button onClick={onBack}>Вернуться к списку заявок</Button><Button type="primary" disabled>Откликнуться ещё раз</Button></footer>
      </> : <div className="skud-executor-offer__layout">
        <main className="skud-executor-offer__form">
          <h2>{executorOfferCopy.title}</h2>
          <p className="skud-executor-offer__intro">{executorOfferCopy.subtitle}</p>
          <section className="skud-executor-offer__section">
            <h3>Система налогообложения</h3>
            <label>НДС</label>
            <Select className={validation && !data.vatRate ? 'is-invalid' : ''} placeholder="Выберите" value={data.vatRate || undefined} options={visibleVatRates.map(value => ({ value, label: value }))} onChange={value => update({ vatRate: value })} />
            <div className="skud-executor-offer__tax-switch"><span>Цены с учетом НДС</span><Switch checked={data.pricesIncludeVat} onChange={value => update({ pricesIncludeVat: value })} /></div>
          </section>

          <section className="skud-executor-offer__section">
            <h3>Перечень оборудования</h3>
            <div className="skud-executor-offer__mode-switch">{visibleEquipmentModes.map(mode => <button type="button" key={mode} className={data.equipmentMode === mode ? 'is-active' : ''} onClick={() => update({ equipmentMode: mode })}>{mode}</button>)}</div>
            <div className="skud-executor-offer__equipment-table">
              <div className="skud-executor-offer__equipment-head"><span>Тип оборудования</span><span>Кол-во</span><span>Цена за шт.</span><span /></div>
              {data.equipment.map((line, index) => <div className="skud-executor-offer__equipment-row" key={index}>
                <span className="skud-executor-offer__row-number">{index + 1}</span>
                <div className="skud-executor-offer__equipment-type">
                  <Select className={validation && !line.equipmentType ? 'is-invalid' : ''} placeholder="Выберите тип оборудования" value={line.equipmentType || undefined} options={visibleEquipmentTypes.map(value => ({ value, label: value }))} onChange={value => updateEquipment(index, { equipmentType: value })} />
                  <Input className={validation && !line.name ? 'is-invalid' : ''} placeholder="Укажите название" value={line.name} onChange={event => updateEquipment(index, { name: event.target.value })} />
                </div>
                <Input className={validation && Number(line.quantity.replace(',', '.')) <= 0 ? 'is-invalid' : ''} value={line.quantity} onChange={event => updateEquipment(index, { quantity: event.target.value })} />
                <div className={validation && Number(line.unitPrice.replace(',', '.').replace(/\s/g, '')) <= 0 ? 'is-invalid' : ''}>{moneyField(line.unitPrice, value => updateEquipment(index, { unitPrice: value }))}</div>
                <Button type="text" danger aria-label="Удалить оборудование" icon={<DeleteOutlined />} onClick={() => update({ equipment: data.equipment.filter((_, lineIndex) => lineIndex !== index) })} />
              </div>)}
            </div>
            <Button className="skud-executor-offer__add" type="link" icon={<PlusOutlined />} onClick={() => update({ equipment: [...data.equipment, { equipmentType: '', name: '', quantity: '0', unitPrice: '0,00' }] })}>Добавить</Button>
          </section>

          <OfferLineTable title="Стоимость технического обслуживания в месяц" nameColumn="Наименование услуги" priceColumn="Цена за шт./мес." line={data.maintenance} onChange={line => updateService('maintenance', line)} />
          <OfferLineTable title="Стоимость монтажа" nameColumn="Наименование услуги" priceColumn="Цена за шт." line={data.installation} onChange={line => updateService('installation', line)} />

          <section className="skud-executor-offer__section">
            <h3>Сроки выполнения монтажа</h3>
            <div className="skud-executor-offer__dates">
              <label>Дата начала<Input className={validation && !data.startDate ? 'is-invalid' : ''} placeholder={dateExampleFormat} value={data.startDate} onChange={event => update({ startDate: event.target.value })} /></label>
              <label>Дата окончания<Input className={validation && !data.endDate ? 'is-invalid' : ''} placeholder={dateExampleFormat} value={data.endDate} onChange={event => update({ endDate: event.target.value })} /></label>
            </div>
          </section>

          <section className="skud-executor-offer__section skud-executor-offer__total">
            <h3>Итоговая стоимость</h3>
            <div><span>НДС</span><strong>{visibleTotals.vat}</strong></div><div><span>Итог</span><strong>{visibleTotals.total}</strong></div>
          </section>
          <footer className="skud-executor-offer__actions"><Button onClick={onBack}>Вернуться к списку заявок</Button><Button type="primary" onClick={openSigning}>Откликнуться</Button></footer>
        </main>
        <aside className="skud-executor-offer__documents">
          <h3>Документы по заявке</h3>
          <RequestDocuments documents={documents} localDocuments={fixtureSourceDocuments} signedDocuments={signedDocuments}/>
        </aside>
      </div>}

      <Modal open={stage === 'contract'} title="Подписать договор" closable centered width={820} onCancel={() => setStage('form')} className="skud-executor-offer__contract-modal" footer={<><p className="skud-install__reservation">{executorOfferCopy.signingDescription}</p><Button onClick={() => setStage('form')}>Отменить</Button><Button type="primary" onClick={sign}>Подписать</Button></>}>
        <div className="skud-install__viewer"><div className="skud-install__paper" style={{zoom:contractScale}}><SharedContractPreview/></div><div className="skud-install__viewer-controls"><Button shape="circle" size="small" icon={<PlusOutlined/>} aria-label="Увеличить документ" onClick={()=>setContractScale(value=>Math.min(2,value+.1))}/><Button shape="circle" size="small" icon={<MinusOutlined/>} aria-label="Уменьшить документ" onClick={()=>setContractScale(value=>Math.max(.5,value-.1))}/><Button shape="circle" size="small" icon={<DownloadOutlined/>} aria-label="Скачать договор" disabled/></div></div>
      </Modal>
      <Modal open={stage === 'signing'} footer={null} closable={false} centered width={470} className="skud-executor-offer__progress-modal"><div><Spin /><strong>Подписание документов</strong></div></Modal>
      <Modal open={stage === 'sign-error'} footer={null} closable={false} centered width={470} className="skud-executor-offer__message-modal">
        <div className="skud-executor-offer__message-heading is-error"><span>×</span><strong>{executorOfferCopy.signErrorTitle}</strong></div>
        <p>{executorOfferCopy.signErrorDescription}</p>
        <div className="skud-executor-offer__modal-actions"><Button onClick={() => setStage('form')}>Назад</Button><Button type="primary" onClick={sign}>Повторить</Button></div>
      </Modal>
      <Modal open={stage === 'signed'} footer={null} closable={false} centered width={470} className="skud-executor-offer__message-modal">
        <div className="skud-executor-offer__message-heading is-success"><span>✓</span><strong>{executorOfferCopy.signedTitle}</strong></div>
        <p>{executorOfferCopy.signedDescription}</p>
        <div className="skud-executor-offer__modal-actions"><Button type="primary" onClick={complete}>Хорошо</Button></div>
      </Modal>
      <Modal open={withdrawOpen} footer={null} centered width={480} onCancel={() => setWithdrawOpen(false)} className="skud-executor-offer__withdraw-modal">
        <h2>Отозвать отклик?</h2>
        <p>Вы сможете откликнуться повторно, пока открыт сбор предложений</p>
        <div className="skud-executor-offer__modal-actions"><Button onClick={() => setWithdrawOpen(false)}>Отменить</Button><Button danger type="primary" onClick={() => { setWithdrawOpen(false); if (onWithdraw) onWithdraw(); else onBack(); }}>Отозвать</Button></div>
      </Modal>
    </div>
  );
}

export default ExecutorOffer;
