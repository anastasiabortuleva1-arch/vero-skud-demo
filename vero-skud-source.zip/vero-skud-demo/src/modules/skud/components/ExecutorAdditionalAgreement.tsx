import { useEffect, useRef, useState, type ReactNode } from 'react';
import { Alert, Button, Checkbox, DatePicker, Input, Modal, Radio, Select, Spin, Switch } from 'antd';
import { CheckCircleFilled, CloseCircleFilled, DownloadOutlined, MinusOutlined, PlusOutlined } from '@ant-design/icons';
import dayjs from 'dayjs';
import { AdditionalAgreementSummary, SharedContractPreview } from './AdditionalAgreement';
import type { LocalDocument } from './DocumentUpload';
import { visibleEquipmentModes, visibleEquipmentTypes, type OfferEquipmentLine } from '../data/executorOffer';
import {
  emptyExecutorAdditionalAgreementData, executorAdditionalAgreementCopy as copy,
  executorAdditionalAgreementIncomingRequest,
  executorAdditionalAgreementFixtures as fixtures,
  type ExecutorAdditionalAgreementData, type ExecutorAdditionalAgreementOrigin,
  type ExecutorAdditionalAgreementRequest, type ExecutorAdditionalAgreementState,
  type ExecutorAdditionalAgreementTotals, type ExecutorAgreementService,
} from '../data/executorAdditionalAgreement';
import './ExecutorAdditionalAgreement.css';

export interface ExecutorAdditionalAgreementProps {
  initialState?: ExecutorAdditionalAgreementState;
  state?: ExecutorAdditionalAgreementState;
  onStateChange?: (state: ExecutorAdditionalAgreementState) => void;
  origin?: ExecutorAdditionalAgreementOrigin;
  initialData?: ExecutorAdditionalAgreementData;
  data?: ExecutorAdditionalAgreementData;
  onDataChange?: (data: ExecutorAdditionalAgreementData) => void;
  request?: ExecutorAdditionalAgreementRequest;
  /** Literal displayed values of a local scenario; no arithmetic or pricing rule is inferred. */
  totals?: ExecutorAdditionalAgreementTotals;
  signatureOutcome?: 'success' | 'error';
  onSubmitted?: (data: ExecutorAdditionalAgreementData) => void;
  showNotice?: boolean;
  details?: ReactNode;
  document?: LocalDocument;
}
const incomingStates: ExecutorAdditionalAgreementState[] = ['incoming', 'estimate', 'sign', 'signing', 'sign-error'];
function cloneData(data: ExecutorAdditionalAgreementData): ExecutorAdditionalAgreementData {
  return {...data, equipmentLines: data.equipmentLines.map(line => ({...line})), maintenance: {...data.maintenance}, mounting: {...data.mounting}};
}
function dateValue(value: string) {
  const parts = value.match(/^(\d{2})\.(\d{2})\.(\d{4})$/);
  const date = parts ? dayjs(`${parts[3]}-${parts[2]}-${parts[1]}`) : null;
  return date?.isValid() ? date : null;
}

export function ExecutorAdditionalAgreement({
  initialState, state: controlledState, onStateChange, origin = 'executor', initialData,
  data: controlledData, onDataChange, request, totals = fixtures.empty.totals,
  signatureOutcome = 'success', onSubmitted, showNotice = true, details, document,
}: ExecutorAdditionalAgreementProps) {
  const [localState, setLocalState] = useState<ExecutorAdditionalAgreementState>(initialState ?? (origin === 'customer' ? 'incoming' : 'idle'));
  const state = controlledState ?? localState;
  const [localData, setLocalData] = useState(() => cloneData(initialData ?? {...emptyExecutorAdditionalAgreementData,
    installation: origin === 'customer' && (request?.installation ?? true), equipment: origin === 'customer' && (request?.equipment ?? true)}));
  const data = controlledData ?? localData;
  const incomingRequest = request ?? executorAdditionalAgreementIncomingRequest;
  const [scale, setScale] = useState(1);
  const timer = useRef<ReturnType<typeof setTimeout> | undefined>(undefined);
  const submitted = useRef(false);
  useEffect(() => {if (state !== 'signing') clearTimeout(timer.current);}, [state]);
  useEffect(() => () => clearTimeout(timer.current), []);
  function changeState(next: ExecutorAdditionalAgreementState) {setLocalState(next); onStateChange?.(next);}
  function changeData(next: ExecutorAdditionalAgreementData) {const snapshot = cloneData(next); setLocalData(snapshot); onDataChange?.(snapshot);}
  function updateEquipment(index: number, patch: Partial<OfferEquipmentLine>) {
    changeData({...data, equipmentLines: data.equipmentLines.map((line, i) => i === index ? {...line, ...patch} : line)});
  }
  function updateService(key: 'maintenance' | 'mounting', patch: Partial<ExecutorAgreementService>) {changeData({...data, [key]: {...data[key], ...patch}});}
  function openSelect() {submitted.current = false; changeState('select');}
  function openEstimate() {submitted.current = false; changeState('estimate');}
  function sign() {
    clearTimeout(timer.current); changeState('signing');
    // Deterministic local fixture. Retrying keeps the same supplied outcome.
    timer.current = setTimeout(() => changeState(signatureOutcome === 'success' ? 'signed' : 'sign-error'), 700);
  }
  function completeSigning() {
    if (!submitted.current) {submitted.current = true; onSubmitted?.(cloneData(data));}
    // The reference requires both signatures for the summary. Executor signing cannot confirm it.
    changeState('sent');
  }
  function download() {
    if (!document?.file) return;
    const url = URL.createObjectURL(document.file); const link = window.document.createElement('a');
    link.href = url; link.download = document.name; link.click(); setTimeout(() => URL.revokeObjectURL(url), 1000);
  }
  const combinedCreation = origin === 'executor' && data.installation && data.equipment;
  function serviceTable(key: 'maintenance' | 'mounting', heading: string, monthly = false) {
    const service = data[key];
    return <section className="skud-executor-agreement__section"><h3>{heading}</h3>
      <div className="skud-executor-agreement__table"><div className="skud-executor-agreement__table-head"><span/><span>Наименование услуги</span><span>Кол-во</span><span>{monthly ? 'Цена за шт./мес.' : 'Цена за шт.'}</span></div>
        <div className="skud-executor-agreement__table-row"><span className="skud-executor-agreement__number">1</span><Input disabled placeholder={monthly ? 'Техническое обслуживание' : 'Монтажные работы'} aria-label="Наименование услуги"/>
          <Input aria-label={`${heading}: количество`} value={service.quantity} onChange={event => updateService(key, {quantity: event.target.value})}/>
          <Input aria-label={`${heading}: цена`} value={service.unitPrice} suffix="₽" onChange={event => updateService(key, {unitPrice: event.target.value})}/></div>
      </div>
    </section>;
  }
  return <>
    {showNotice && origin === 'customer' && <ExecutorAdditionalAgreementNotice state={state} request={incomingRequest} onEstimate={openEstimate}/>}
    <section className="skud-request__panel skud-executor-agreement"><h2>{copy.title}</h2><p>{copy.description}</p>
      <div className="skud-executor-agreement__actions"><Button onClick={openSelect}>{copy.action}</Button></div>
    </section>
    {state === 'confirmed' && <AdditionalAgreementSummary details={details} document={document}/>}
    <Modal className="skud-executor-agreement__modal skud-executor-agreement__select" open={state === 'select'} title={copy.selectTitle} centered width={720}
      onCancel={() => changeState(origin === 'customer' ? 'incoming' : 'idle')}
      footer={<><Button onClick={() => changeState(origin === 'customer' ? 'incoming' : 'idle')}>Отменить</Button><Button type="primary" onClick={() => {if (data.installation || data.equipment) openEstimate();}}>Далее</Button></>}>
      <p className="skud-executor-agreement__intro">{copy.selectDescription}</p>
      <div className="skud-executor-agreement__choices"><Checkbox checked={data.installation} onChange={event => changeData({...data, installation: event.target.checked})}>{copy.installation}</Checkbox><Checkbox checked={data.equipment} onChange={event => changeData({...data, equipment: event.target.checked})}>{copy.equipment}</Checkbox></div>
    </Modal>
    <Modal className={`skud-executor-agreement__modal skud-executor-agreement__estimate${combinedCreation ? ' is-combined-creation' : ''}`} open={state === 'estimate'} title={copy.estimateTitle} centered width={744}
      onCancel={() => changeState(origin === 'customer' ? 'incoming' : 'idle')}
      footer={<><Button onClick={() => changeState(origin === 'customer' ? 'incoming' : 'idle')}>Отменить</Button><Button type="primary" onClick={() => {setScale(1); changeState('sign');}}>Отправить предложение</Button></>}>
      <p className="skud-executor-agreement__intro">{copy.estimateDescription}</p>
      <div className="skud-executor-agreement__scroll">
        <section className="skud-executor-agreement__section skud-executor-agreement__tax"><h3>Система налогообложения</h3><label>НДС<Select aria-label="НДС" disabled value="22%" options={[{value: '22%', label: '22%'}]}/></label><label className="skud-executor-agreement__vat-switch">Цены с учётом НДС<Switch checked={data.pricesIncludeVat} onChange={checked => changeData({...data, pricesIncludeVat: checked})}/></label></section>
        {data.equipment && <section className="skud-executor-agreement__section"><h3>Перечень оборудования</h3>
          <div className="skud-executor-agreement__mode">{visibleEquipmentModes.map(mode => <Button key={mode} type={data.equipmentMode === mode ? 'primary' : 'default'} ghost={data.equipmentMode === mode} onClick={() => changeData({...data, equipmentMode: mode})}>{mode}</Button>)}</div>
          <div className="skud-executor-agreement__table"><div className="skud-executor-agreement__table-head"><span/><span>Тип оборудования</span><span>Кол-во</span><span>Цена за шт.</span></div>
            {data.equipmentLines.map((line, index) => <div className="skud-executor-agreement__table-row is-equipment" key={index}><span className="skud-executor-agreement__number">{index + 1}</span><div className="skud-executor-agreement__equipment-name"><Select aria-label={`Тип оборудования ${index + 1}`} placeholder="Выберите тип оборудования" value={line.equipmentType || undefined} options={visibleEquipmentTypes.map(value => ({value, label: value}))} onChange={value => updateEquipment(index, {equipmentType: value})}/><Input aria-label={`Модель устройства ${index + 1}`} placeholder="Модель устройства" value={line.name} onChange={event => updateEquipment(index, {name: event.target.value})}/></div><Input aria-label={`Количество оборудования ${index + 1}`} value={line.quantity} onChange={event => updateEquipment(index, {quantity: event.target.value})}/><Input aria-label={`Цена оборудования ${index + 1}`} value={line.unitPrice} suffix="₽" onChange={event => updateEquipment(index, {unitPrice: event.target.value})}/></div>)}
          </div><Button className="skud-executor-agreement__add" icon={<PlusOutlined/>} onClick={() => changeData({...data, equipmentLines: [...data.equipmentLines, {equipmentType: '', name: '', quantity: '0', unitPrice: '0,00'}]})}>Добавить</Button>
        </section>}
        {combinedCreation ? <section className="skud-executor-agreement__section"><h3>Стоимость технического обслуживания в месяц</h3><div className="skud-executor-agreement__table"><div className="skud-executor-agreement__table-head"><span/><span>Наименование услуги</span><span>Кол-во</span><span>Цена за шт./мес.</span></div></div></section> : <>
          {data.equipment && serviceTable('maintenance', 'Стоимость технического обслуживания в месяц', true)}
          {data.installation && <>{serviceTable('mounting', 'Стоимость монтажа')}<section className="skud-executor-agreement__section"><h3>Сроки выполнения монтажа</h3>
            {origin === 'customer' ? <div className="skud-executor-agreement__deadline"><Radio.Group value={data.changeDeadline} onChange={event => changeData({...data, changeDeadline: event.target.value})}><Radio value={false}>Без изменений</Radio><Radio value={true}>Изменить сроки</Radio></Radio.Group>{data.changeDeadline && <label>Новая дата окончания<DatePicker aria-label="Новая дата окончания" placeholder="" format="DD.MM.YYYY" value={dateValue(data.newEndDate)} onChange={date => changeData({...data, newEndDate: date?.format('DD.MM.YYYY') ?? ''})}/></label>}</div>
              : <div className="skud-executor-agreement__dates"><label>Дата начала<DatePicker aria-label="Дата начала" placeholder="" format="DD.MM.YYYY" value={dateValue(data.startDate)} onChange={date => changeData({...data, startDate: date?.format('DD.MM.YYYY') ?? ''})}/></label><label>Дата окончания<DatePicker aria-label="Дата окончания" placeholder="" format="DD.MM.YYYY" value={dateValue(data.endDate)} onChange={date => changeData({...data, endDate: date?.format('DD.MM.YYYY') ?? ''})}/></label></div>}
          </section></>}
          <section className="skud-executor-agreement__section skud-executor-agreement__totals"><h3>Итоговая стоимость</h3><dl><div><dt>НДС</dt><dd>{totals.vat}</dd></div><div><dt>Итог</dt><dd>{totals.total} ₽</dd></div></dl></section>
        </>}
      </div>
    </Modal>
    <Modal className="skud-executor-agreement__modal skud-executor-agreement__contract" open={state === 'sign'} title="Подписать договор" centered width={820} onCancel={() => changeState('estimate')}
      footer={<><p className="skud-executor-agreement__sign-copy">{copy.signingDescription}</p><Button onClick={() => changeState('estimate')}>Отменить</Button><Button type="primary" onClick={sign}>Подписать</Button></>}>
      <div className="skud-install__viewer skud-agreement__viewer"><div className="skud-install__paper" style={{zoom:scale}}><SharedContractPreview/></div><div className="skud-install__viewer-controls"><Button shape="circle" size="small" icon={<PlusOutlined/>} aria-label="Увеличить документ" onClick={() => setScale(value => Math.min(2, value + .1))}/><Button shape="circle" size="small" icon={<MinusOutlined/>} aria-label="Уменьшить документ" onClick={() => setScale(value => Math.max(.5, value - .1))}/><Button shape="circle" size="small" disabled={!document?.file} icon={<DownloadOutlined/>} aria-label="Скачать документ" onClick={download}/></div></div>
    </Modal>
    <Modal className="skud-executor-agreement__modal" open={state === 'signing'} centered width={520} footer={null} closable={false} mask={{closable:false}}><div className="skud-request__loading"><Spin/><strong>Подписание документов</strong></div></Modal>
    <Modal className="skud-executor-agreement__modal" open={state === 'sign-error'} centered width={448} onCancel={() => changeState('estimate')} footer={<><Button onClick={() => changeState('sign')}>Назад</Button><Button type="primary" onClick={sign}>Повторить</Button></>}><div className="skud-install__notice"><CloseCircleFilled className="is-error"/><div><strong>{copy.errorTitle}</strong><p>{copy.errorDescription}</p></div></div></Modal>
    <Modal className="skud-executor-agreement__modal" open={state === 'signed'} centered width={448} onCancel={completeSigning} footer={<Button type="primary" onClick={completeSigning}>Хорошо</Button>}><div className="skud-install__notice"><CheckCircleFilled className="is-success"/><div><strong>{copy.signedTitle}</strong><p>{copy.signedDescription}</p></div></div></Modal>
  </>;
}

export function ExecutorAdditionalAgreementNotice({state = 'incoming', request = executorAdditionalAgreementIncomingRequest, onEstimate}: {
  state?: ExecutorAdditionalAgreementState; request?: ExecutorAdditionalAgreementRequest; onEstimate: () => void;
}) {
  if (!incomingStates.includes(state)) return null;
  const changes = [request.equipment && copy.equipment, request.installation && copy.installation].filter(Boolean).join(' · ');
  return <Alert className="skud-executor-agreement__notice" type="warning" showIcon title={copy.incomingTitle}
    description={<><p>{copy.incomingDescription}</p><strong>Изменения:</strong><div>{changes}</div>{request.comment && <><strong>Комментарий:</strong><div>{request.comment}</div></>}</>}
    action={<Button type="primary" onClick={onEstimate}>{copy.incomingAction}</Button>}/>;
}
export default ExecutorAdditionalAgreement;
