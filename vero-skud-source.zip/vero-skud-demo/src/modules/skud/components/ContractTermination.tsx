import { Button, Input, Modal, Radio } from 'antd';
import { contractTerminationCopy, contractTerminationReasons } from '../data/contractTermination';
import type { ContractTerminationData } from '../data/contractTermination';
import './ContractTermination.css';

export interface ContractTerminationProps {
  value: ContractTerminationData;
  onStateChange: (next: ContractTerminationData) => void;
  onRequested?: (data: ContractTerminationData) => void;
}

export function ContractTermination({ value, onStateChange, onRequested }: ContractTerminationProps) {
  const open = value.stage !== 'closed';

  function close() {
    onStateChange({ ...value, stage: 'closed', validationError: false });
  }

  function next() {
    if (!value.reason) return;
    if (value.reason === 'Иное основание' && !value.comment.trim()) {
      onStateChange({ ...value, validationError: true });
      return;
    }
    onStateChange({ ...value, stage: 'confirmation', validationError: false });
  }

  function requestTermination() {
    const submitted = { ...value, stage: 'closed' as const, validationError: false };
    onStateChange(submitted);
    onRequested?.(submitted);
  }

  return <Modal
    open={open}
    footer={null}
    centered
    width={720}
    onCancel={close}
    className="skud-contract-termination"
  >
    {value.stage === 'reason' && <>
      <h2>{contractTerminationCopy.title}</h2>
      <p className="skud-contract-termination__subtitle">{contractTerminationCopy.subtitle}</p>
      {value.reason && value.reason !== 'Иное основание' && <div className="skud-contract-termination__reason-label">{contractTerminationCopy.reasonLabel}</div>}
      <Radio.Group
        className="skud-contract-termination__reasons"
        value={value.reason}
        onChange={event => onStateChange({ ...value, reason: event.target.value, validationError: false })}
      >
        {contractTerminationReasons.map(reason => <Radio key={reason} value={reason}>{reason}</Radio>)}
      </Radio.Group>
      {value.reason === 'Иное основание' && <div className="skud-contract-termination__comment">
        <Input.TextArea
          value={value.comment}
          placeholder={contractTerminationCopy.commentPlaceholder}
          autoSize={false}
          status={value.validationError ? 'error' : undefined}
          onChange={event => onStateChange({ ...value, comment: event.target.value, validationError: false })}
        />
        {value.validationError && <div className="skud-contract-termination__error">{contractTerminationCopy.commentError}</div>}
      </div>}
      <div className="skud-contract-termination__actions"><Button onClick={close}>{contractTerminationCopy.cancel}</Button><Button type="primary" onClick={next}>{contractTerminationCopy.next}</Button></div>
    </>}
    {value.stage === 'confirmation' && <>
      <h2>{contractTerminationCopy.confirmationTitle}</h2>
      <p className="skud-contract-termination__confirm-copy">{contractTerminationCopy.confirmationDescription}</p>
      <div className="skud-contract-termination__actions"><Button onClick={close}>{contractTerminationCopy.cancel}</Button><Button type="primary" onClick={requestTermination}>{contractTerminationCopy.submit}</Button></div>
    </>}
  </Modal>;
}

export default ContractTermination;
