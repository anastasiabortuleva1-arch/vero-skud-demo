import { useEffect, useRef, useState } from 'react';
import type { ReactNode } from 'react';
import { Button, Input, Modal, Radio, Skeleton, Spin, Tooltip } from 'antd';
import { CheckCircleFilled, CloseCircleFilled, ExclamationCircleFilled, QuestionCircleOutlined, CloseOutlined, SearchOutlined } from '@ant-design/icons';
import { DocumentUpload } from './DocumentUpload';
import type { LocalDocument } from './DocumentUpload';
import {
  emptyInstallFormData,
  installAudienceOptions,
  installEmployeeOptions,
  installExecutorOptions,
  installEquipmentOptions,
  installFormErrors,
  installFundingOptions,
  installPublicationError,
  installSchemeOptions,
  installStorageOptions,
  installWorkFormatOptions,
  installYesNoOptions,
  knownInstallObject,
} from '../data/installForm';
import type { InstallFormData, InstallFormStep } from '../data/installForm';
import { demoDocument } from '../data/demoDocuments';
import { filledExecutorOfferData } from '../data/executorOffer';
import './InstallForm.css';

export interface InstallFormProps {
  demoFillToken?: number;
  initialData?: InstallFormData;
  initialStep?: InstallFormStep;
  publicationOutcome?: 'error';
  draftOutcome?: 'error';
  onBack: () => void;
  onDraft: (data: InstallFormData) => void;
  onPublish: (data: InstallFormData) => void;
}

function YesNo({ value, onChange }: { value: string; onChange: (value: 'Да' | 'Нет') => void }) {
  return <Radio.Group className="skud-install-form__segmented" optionType="button" buttonStyle="solid" options={installYesNoOptions.filter(Boolean)} value={value || undefined} onChange={event => onChange(event.target.value)} />;
}

function ChoiceGroup<T extends string>({ value, options, onChange, className = '' }: { value: T | ''; options: readonly T[]; onChange: (value: T) => void; className?: string }) {
  return <Radio.Group className={className || "skud-install-form__segmented"} optionType={className.includes("radio-list") ? "default" : "button"} buttonStyle="solid" value={value || undefined} onChange={event => onChange(event.target.value)} options={options.filter(Boolean).map(option => ({ label: option, value: option }))} />;
}

function Field({ label, tip, children, className = '' }: { label: string; tip?: string; children: ReactNode; className?: string }) {
  return <div className={`skud-install-form__field ${className}`}><label>{label}{tip && <Tooltip title={tip} placement="top" trigger={['hover', 'focus']} color="rgba(0,0,0,.88)" styles={{ root: { maxWidth: 250 } }}><button type="button" className="skud-install-form__info" aria-label={`Подсказка: ${label}`}><QuestionCircleOutlined /></button></Tooltip>}</label>{children}</div>;
}

export function InstallForm({ demoFillToken = 0, initialData, initialStep = 1, publicationOutcome, draftOutcome, onBack, onDraft, onPublish }: InstallFormProps) {
  const [data, setData] = useState<InstallFormData>(() => ({ ...emptyInstallFormData, ...initialData }));
  const [step, setStep] = useState<InstallFormStep>(initialStep);
  const [lookupLoading, setLookupLoading] = useState(false);
  const [lookupFailed, setLookupFailed] = useState(false);
  const [publishing, setPublishing] = useState(false);
  const [publishError, setPublishError] = useState(false);
  const [executorError, setExecutorError] = useState(false);
  const [exitConfirm, setExitConfirm] = useState(false);
  const [draftStage, setDraftStage] = useState<'idle' | 'saving' | 'saved' | 'error'>('idle');
  const lookupTimer = useRef<number | undefined>(undefined);
  const publishTimer = useRef<number | undefined>(undefined);
  const draftTimer = useRef<number | undefined>(undefined);
  const initialSnapshot = useRef<string | undefined>(undefined);
  if (initialSnapshot.current === undefined) initialSnapshot.current = JSON.stringify(data);

  useEffect(() => {
    if (demoFillToken <= 0) return;
    if (lookupTimer.current !== undefined) window.clearTimeout(lookupTimer.current);
    lookupTimer.current = undefined;
    setLookupLoading(false);
    setLookupFailed(false);
    setData({
      ...knownInstallObject,
      equipmentAvailability: 'Да, оборудование в наличии',
      schemePreparation: 'Подготовим самостоятельно',
      checkpointCount: '2', turnstilesAvailable: 'Да', turnstilesPerPoint: '1',
      turnstileModel: filledExecutorOfferData.equipment[2].name,
      requiresWorkstation: 'Да', internetAtCheckpoint: 'Да', externalStaticIp: 'Да',
      employeeCount: 'Менее 1000', faceIdTerminals: filledExecutorOfferData.equipment[0].name,
      accessController: 'PERCo CT/L04', serverModel: 'Dell PowerEdge T150',
      processorModel: 'Intel Core i7-12700', ram: '32', storageVolume: '1',
      storageType: 'SSD', usesCrypto: 'Да', cryptoModel: 'ViPNet Coordinator HW100', cryptoLocation: 'Офис',
      sitePlan: demoDocument('Строительный генеральный план.pdf', 'pdf'),
      workFormat: 'С дальнейшим ТО', audience: 'Все исполнители',
    });
  }, [demoFillToken]);

  useEffect(() => () => {
    if (lookupTimer.current !== undefined) window.clearTimeout(lookupTimer.current);
    if (publishTimer.current !== undefined) window.clearTimeout(publishTimer.current);
    if (draftTimer.current !== undefined) window.clearTimeout(draftTimer.current);
  }, []);

  const update = (patch: Partial<InstallFormData>) => setData(current => ({ ...current, ...patch }));
  const setDocument = (document?: LocalDocument) => update({ sitePlan: document });

  function findObject() {
    setLookupFailed(false);
    setLookupLoading(true);
    lookupTimer.current = window.setTimeout(() => {
      lookupTimer.current = undefined;
      setLookupLoading(false);
      const found = data.uin.trim().toLocaleUpperCase('en-US') === knownInstallObject.uin;
      if (found) {
        setData(current => ({ ...current, ...knownInstallObject }));
      } else {
        setLookupFailed(true);
        setData(current => ({ ...current, objectName: '', address: '', fundingSource: '' }));
      }
    }, 650);
  }

  function publish() {
    if (data.audience === 'Выбранные исполнители' && !data.selectedExecutors?.length) {
      setExecutorError(true);
      return;
    }
    setExecutorError(false);
    setPublishError(false);
    setPublishing(true);
    publishTimer.current = window.setTimeout(() => {
      publishTimer.current = undefined;
      setPublishing(false);
      if (publicationOutcome === 'error') setPublishError(true);
      else onPublish({ ...data });
    }, 900);
  }

  function goBack() {
    if (step === 2) {
      setStep(1);
      return;
    }
    if (JSON.stringify(data) !== initialSnapshot.current) setExitConfirm(true);
    else onBack();
  }

  function saveDraft() {
    setDraftStage('saving');
    draftTimer.current = window.setTimeout(() => {
      draftTimer.current = undefined;
      if (draftOutcome === 'error') {
        setDraftStage('error');
        return;
      }
      onDraft({ ...data });
      initialSnapshot.current = JSON.stringify(data);
      setDraftStage('saved');
    }, 650);
  }

  const errors = lookupFailed ? installFormErrors : undefined;
  const updateField = (patch: Partial<InstallFormData>) => {
    update(patch);
    if (lookupFailed && ('objectName' in patch || 'address' in patch || 'fundingSource' in patch)) {
      const merged = { ...data, ...patch };
      if (merged.objectName.trim() && merged.address.trim() && merged.fundingSource) setLookupFailed(false);
    }
  };

  return (
    <div className="skud-install-form">
      <h1>Новая заявка на установку и регистрацию СКУД</h1>
      <p className="skud-install-form__subtitle">Заполните параметры заявки. После публикации заявки исполнители смогут отправить коммерческие предложения</p>

      {step === 1 ? <>
        <h2 className="skud-install-form__step-title">1. Данные об объекте</h2>
        <section className="skud-install-form__card skud-install-form__object">
          <Field label="УИН объекта капитального строительства">
            <div className="skud-install-form__lookup-row">
              <Input value={data.uin} placeholder="HH8212-08-0001-001" onChange={event => update({ uin: event.target.value })} />
              <Button icon={<SearchOutlined />} onClick={findObject}>Найти объект</Button>
            </div>
            <div className="skud-install-form__help">По УИН автоматически заполним название и адрес объекта</div>
          </Field>
          {lookupLoading ? <div className="skud-install-form__object-fields">
            <Field label="Наименование объекта"><Skeleton.Input active block /></Field>
            <Field label="Адрес объекта"><Skeleton.Input active block /></Field>
            <Field label="Источник финансирования" className="skud-install-form__field--wide"><Skeleton.Input active block /></Field>
          </div> : (data.objectName || data.address || data.fundingSource || lookupFailed) ? <div className="skud-install-form__object-fields">
            <Field label="Наименование объекта">
              <Input status={errors && !data.objectName ? 'error' : undefined} value={data.objectName} onChange={event => updateField({ objectName: event.target.value })} />
              {errors && !data.objectName && <span className="skud-install-form__error">{errors.objectName}</span>}
            </Field>
            <Field label="Адрес объекта">
              <Input status={errors && !data.address ? 'error' : undefined} value={data.address} onChange={event => updateField({ address: event.target.value })} />
              {errors && !data.address && <span className="skud-install-form__error">{errors.address}</span>}
            </Field>
            <Field label="Источник финансирования" className="skud-install-form__field--wide">
              <select className={`skud-install-form__native-select ${errors && !data.fundingSource ? 'is-error' : ''}`} value={data.fundingSource} onChange={event => updateField({ fundingSource: event.target.value })}>
                <option value="">Выберите</option>{installFundingOptions.map(option => <option key={option} value={option}>{option}</option>)}
              </select>
              {errors && !data.fundingSource && <span className="skud-install-form__error">{errors.fundingSource}</span>}
            </Field>
          </div> : null}
        </section>

        <section className="skud-install-form__card">
          <h3>Имеется ли оборудование для подключения?</h3>
          <p>Укажите, имеется ли на объекте необходимое оборудование для подключения СКУД или требуется покупка нового</p>
          <ChoiceGroup value={data.equipmentAvailability} options={installEquipmentOptions} onChange={value => update({ equipmentAvailability: value })} className="skud-install-form__radio-list" />
        </section>

        <section className="skud-install-form__card">
          <h3>Кто подготовит схему размещения СКУД на объекте?</h3>
          <p>Укажите, кто будет отвечать за подготовку схемы размещения оборудования СКУД на объекте: заявитель самостоятельно или исполнитель работ</p>
          <ChoiceGroup value={data.schemePreparation} options={installSchemeOptions} onChange={value => update({ schemePreparation: value })} className="skud-install-form__radio-list" />
        </section>
      </> : <>
        <h2 className="skud-install-form__step-title">2. Технические параметры объекта</h2>
        <section className="skud-install-form__card">
          <h3>Инфраструктура объекта</h3>
          <p>Укажите основные параметры инфраструктуры объекта и установленного пропускного оборудования</p>
          <div className="skud-install-form__grid skud-install-form__grid--three">
            <Field label="Количество КПП на объекте"><Input value={data.checkpointCount} placeholder="0" onChange={event => update({ checkpointCount: event.target.value })} /></Field>
            <Field label="Турникеты в наличии?" tip="Укажите, установлены ли на объекте турникеты на текущий момент"><YesNo value={data.turnstilesAvailable} onChange={value => update({ turnstilesAvailable: value })} /></Field>
            {data.turnstilesAvailable !== '' && <Field label="Количество турникетов на одну точку"><Input value={data.turnstilesPerPoint} placeholder="0" onChange={event => update({ turnstilesPerPoint: event.target.value })} /></Field>}
            {data.turnstilesAvailable === 'Да' && <Field label="Модель турникета" className="skud-install-form__field--wide"><Input value={data.turnstileModel} onChange={event => update({ turnstileModel: event.target.value })} /></Field>}
          </div>
        </section>

        <section className="skud-install-form__card">
          <h3>Условия подключения</h3>
          <p>Укажите дополнительное оборудование для удобства пользования СКУД на площадке</p>
          <div className="skud-install-form__grid skud-install-form__grid--three">
            <Field label="Требуется ли АРМ?" tip="Укажите, требуется ли отдельное автоматизированное рабочее место для отслеживания проходов сотрудников, просмотра событий СКУД и контроля доступа на объект"><YesNo value={data.requiresWorkstation} onChange={value => update({ requiresWorkstation: value })} /></Field>
            <Field label="Есть ли доступ в Интернет на КПП?" tip="Укажите, имеется ли на контрольно-пропускных пунктах стабильный доступ в Интернет для подключения оборудования"><YesNo value={data.internetAtCheckpoint} onChange={value => update({ internetAtCheckpoint: value })} /></Field>
            <Field label="Есть ли внешний статический IP-адрес?" tip="Укажите, предоставлен ли объекту постоянный внешний IP-адрес, доступный для сетевого взаимодействия"><YesNo value={data.externalStaticIp} onChange={value => update({ externalStaticIp: value })} /></Field>
            <Field label="Численность сотрудников на объекте" className="skud-install-form__field--wide"><ChoiceGroup value={data.employeeCount} options={installEmployeeOptions} onChange={value => update({ employeeCount: value })} /></Field>
          </div>
        </section>

        {data.equipmentAvailability === 'Да, оборудование в наличии' && <>
          <section className="skud-install-form__card">
            <h3>Оборудование СКУД</h3>
            <p>Укажите сведения об оборудовании системы контроля и управления доступом, установленном или планируемом к использованию на объекте</p>
            <div className="skud-install-form__grid skud-install-form__grid--two">
              <Field label="Марка и модель терминалов Face ID" tip="Укажите производителя и модель терминалов распознавания лиц, используемых в составе СКУД"><Input value={data.faceIdTerminals} onChange={event => update({ faceIdTerminals: event.target.value })} /></Field>
              <Field label="Марка и модель контроллера СКУД" tip="Укажите производителя и модель контроллера системы контроля и управления доступом"><Input value={data.accessController} onChange={event => update({ accessController: event.target.value })} /></Field>
            </div>
          </section>
          <section className="skud-install-form__card">
            <h3>Технические характеристики сервера</h3>
            <p>Укажите основные технические характеристики сервера, используемого или планируемого для работы СКУД</p>
            <div className="skud-install-form__grid skud-install-form__grid--three">
              <Field label="Марка и модель сервера"><Input value={data.serverModel} onChange={event => update({ serverModel: event.target.value })} /></Field>
              <Field label="Модель процессора"><Input value={data.processorModel} placeholder="Например, Intel Core i7-12700" onChange={event => update({ processorModel: event.target.value })} /></Field>
              <Field label="Оперативная память"><Input value={data.ram} placeholder="0" addonAfter="ГБ" onChange={event => update({ ram: event.target.value })} /></Field>
              <Field label="Объём накопителя"><Input value={data.storageVolume} placeholder="0" addonAfter="ТБ" onChange={event => update({ storageVolume: event.target.value })} /></Field>
              <Field label="Тип накопителя"><ChoiceGroup value={data.storageType} options={installStorageOptions} onChange={value => update({ storageType: value })} /></Field>
            </div>
          </section>
          <section className="skud-install-form__card">
            <h3>Средства криптографической защиты информации</h3>
            <p>Укажите сведения о средствах криптографической защиты информации, используемых для защищённого обмена данными</p>
            <div className="skud-install-form__grid">
            <Field label="Используется ли СКЗИ?" tip="СКЗИ — средство криптографической защиты информации, используемое для защищённой передачи и обработки данных со СКУД"><YesNo value={data.usesCrypto} onChange={value => update({ usesCrypto: value })} /></Field>
            {data.usesCrypto === 'Да' && <>
              <Field label="Наименование и модель СКЗИ"><Input aria-label="Наименование и модель СКЗИ" value={data.cryptoModel ?? ''} onChange={event => update({ cryptoModel: event.target.value })} /></Field>
              <Field label="Место установки СКЗИ"><ChoiceGroup value={data.cryptoLocation ?? ''} options={['Офис', 'ЦОД', 'ОКС']} onChange={value => update({ cryptoLocation: value })} /></Field>
            </>}
            </div>
          </section>
        </>}

        <section className="skud-install-form__card">
          <h3>Строительный генеральный план</h3>
          <p>Загрузите файл в формате PDF</p>
          <DocumentUpload value={data.sitePlan} accept=".pdf,application/pdf" onChange={setDocument} />
        </section>

        <h2 className="skud-install-form__step-title">3. Выберите формат работы</h2>
        <Radio.Group className="skud-install-form__work-options" value={data.workFormat || undefined} onChange={event => update({ workFormat: event.target.value })}>
          {installWorkFormatOptions.map((value, index) => <Radio key={value} value={value} className={`skud-install-form__work-option ${data.workFormat === value ? 'is-selected' : ''}`}>
            <strong>{value}</strong><small>{index === 0 ? 'Установка и настройка необходимого оборудования с дальнейшим обслуживанием' : 'Установка и настройка необходимого оборудования без дальнейшего обслуживания'}</small>
          </Radio>)}
        </Radio.Group>
        <section className="skud-install-form__card skud-install-form__audience">
          <h3>Кто увидит заявку?</h3>
          <p>Укажите, кто сможет посмотреть заявку и отправить коммерческое предложение</p>
          <ChoiceGroup value={data.audience} options={installAudienceOptions} onChange={value => { update({ audience: value }); setExecutorError(false); }} className="skud-install-form__radio-list" />
          {data.audience === 'Выбранные исполнители' && <div className="skud-install-form__executor-options" role="group" aria-label="Выбранные исполнители">
            {installExecutorOptions.map(executor => {
              const selected = data.selectedExecutors?.includes(executor) ?? false;
              return <button type="button" key={executor} aria-pressed={selected} className={`skud-install-form__executor-tag ${selected ? 'is-selected' : ''}`} onClick={() => {
                const current = data.selectedExecutors ?? [];
                update({ selectedExecutors: selected ? current.filter(value => value !== executor) : [...current, executor] });
                setExecutorError(false);
              }}>{executor}{selected && <CloseOutlined aria-hidden="true" />}</button>;
            })}
          </div>}
          {executorError && <div role="alert" className="skud-install-form__error">Выберите хотя бы одного исполнителя</div>}
        </section>
      </>}

      <footer className="skud-install-form__actions">
        <Button onClick={goBack}>Назад</Button>
        <div className="skud-install-form__actions-right">
          <Button onClick={saveDraft}>Сохранить черновик</Button>
          {step === 1 ? <Button type="primary" onClick={() => setStep(2)}>Далее</Button> : <Button type="primary" onClick={publish}>Разместить заявку</Button>}
        </div>
      </footer>

      <Modal open={publishing} footer={null} closable={false} centered width={470} className="skud-install-form__publishing"><div><Spin /><strong>Публикация заявки</strong></div></Modal>
      <Modal open={publishError} footer={null} closable={false} centered width={470} className="skud-install-form__error-modal">
        <div className="skud-install-form__error-heading"><span aria-hidden="true">×</span><strong>{installPublicationError.title}</strong></div>
        <p>{installPublicationError.description}</p>
        <div className="skud-install-form__error-actions"><Button onClick={() => { setPublishError(false); setStep(1); }}>Назад</Button><Button type="primary" onClick={publish}>Повторить</Button></div>
      </Modal>
      <Modal open={exitConfirm} footer={null} centered width={470} onCancel={() => setExitConfirm(false)} className="skud-install-form__confirm-modal">
        <div className="skud-install-form__confirm-heading"><ExclamationCircleFilled /><strong>Вы действительно хотите выйти?</strong></div><p>Все несохраненные данные будут потеряны</p><div className="skud-install-form__confirm-actions"><Button onClick={() => setExitConfirm(false)}>Отменить</Button><Button type="primary" onClick={() => { setExitConfirm(false); onBack(); }}>Выйти</Button></div>
      </Modal>
      <Modal open={draftStage === 'saving'} footer={null} closable={false} centered width={470} className="skud-install-form__publishing"><div><Spin /><strong>Сохранение черновика</strong></div></Modal>
      <Modal open={draftStage === 'saved'} footer={null} closable={false} centered width={470} className="skud-install-form__draft-modal">
        <div className="skud-install-form__draft-heading is-success"><CheckCircleFilled /><strong>Заявка сохранена в черновиках</strong></div><p>Вы сможете вернуться к заполнению позже</p><div className="skud-install-form__confirm-actions"><Button type="primary" onClick={() => { setDraftStage('idle'); }}>Хорошо</Button></div>
      </Modal>
      <Modal open={draftStage === 'error'} footer={null} closable={false} centered width={470} className="skud-install-form__draft-modal">
        <div className="skud-install-form__draft-heading is-error"><CloseCircleFilled /><strong>Не удалось сохранить черновик</strong></div><p>Повторите попытку или вернитесь назад</p><div className="skud-install-form__confirm-actions"><Button onClick={() => setDraftStage('idle')}>Назад</Button><Button type="primary" onClick={saveDraft}>Повторить</Button></div>
      </Modal>
    </div>
  );
}

export default InstallForm;
