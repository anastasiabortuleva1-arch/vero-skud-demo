import { useEffect, useMemo, useRef, useState } from 'react';
import { Button, Input, Modal, Spin, Tabs, Tag } from 'antd';
import { DeleteOutlined, EditOutlined, InboxOutlined, ToolOutlined, UserOutlined } from '@ant-design/icons';
import { requestCards, requestEmptyStateCopy, requestMatchesStatusFilter, requestSummary } from '../data/requestCards';
import type { RequestCardData, RequestStatusFilter, RequestSummaryItem, RequestTab } from '../data/requestCards';
import './MyRequests.css';

export interface MyRequestsProps {
  onCreate: (kind: 'install' | 'registration') => void;
  onOpenRequest: (key: string) => void;
  onRepublish?: (key: string) => void;
  onDelete?: (key: string) => void;
  initialTab?: RequestTab;
  requests?: readonly RequestCardData[];
  summary?: readonly RequestSummaryItem[];
}

const statusFilters: readonly RequestStatusFilter[] = ['total', 'action', 'work', 'termination', 'completed'];

export function MyRequests({ onCreate, onOpenRequest, onRepublish, onDelete, initialTab = 'active', requests = requestCards, summary }: MyRequestsProps) {
  const [tab, setTab] = useState<RequestTab>(initialTab);
  const [query, setQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState<RequestStatusFilter>('total');
  const [deletingKey, setDeletingKey] = useState<string>();
  const [republishingKey, setRepublishingKey] = useState<string>();
  const republishTimer = useRef<number | undefined>(undefined);
  useEffect(() => () => {
    if (republishTimer.current !== undefined) window.clearTimeout(republishTimer.current);
  }, []);
  const visibleRequests = useMemo(() => {
    const search = query.trim().toLocaleLowerCase('ru-RU');
    return requests.filter(request => request.tab === tab && request.name.toLocaleLowerCase('ru-RU').includes(search) && (tab !== 'active' || requestMatchesStatusFilter(request, statusFilter)));
  }, [requests, tab, query, statusFilter]);
  const count = (value: RequestTab) => requests.filter(request => request.tab === value).length;
  const visibleSummary = (summary ?? requestSummary).map((item, index) => ({ ...item, value: requests.filter(request => request.tab === 'active' && requestMatchesStatusFilter(request, statusFilters[index] ?? 'total')).length }));
  const deletingRequest = requests.find(request => request.key === deletingKey && request.tab !== 'active');
  const emptyCopy = query.trim() ? 'По вашему поиску заявки не найдены' : tab === 'active' && statusFilter !== 'total' ? 'Заявок с выбранным статусом нет' : requestEmptyStateCopy[tab];

  function republish(key: string) {
    if (!onRepublish) return;
    setRepublishingKey(key);
    republishTimer.current = window.setTimeout(() => {
      republishTimer.current = undefined;
      setRepublishingKey(undefined);
      onRepublish(key);
    }, 900);
  }

  return (
    <div className="skud-my-requests">
      <h1>Мои заявки</h1>
      <p className="skud-my-requests__subtitle">Размещайте заявки на монтаж и регистрацию СКУД на объектах строительства</p>
      <div className="skud-my-requests__services">
        <section className="skud-my-requests__service">
          <h2>Установка и регистрация СКУД под ключ</h2>
          <p>Подбор исполнителя, установка и подключение к системам<br />Правительства Москвы</p>
          <Button type="primary" onClick={() => onCreate('install')}>Заявка на установку</Button>
        </section>
        <section className="skud-my-requests__service">
          <h2>Регистрация СКУД в реестре</h2>
          <p>Подключение установленного оборудования к системам<br />Правительства Москвы</p>
          <Button type="primary" onClick={() => onCreate('registration')}>Заявка на регистрацию</Button>
        </section>
      </div>
      <Tabs className="skud-my-requests__tabs" activeKey={tab} onChange={value => setTab(value as RequestTab)} items={[
        { key: 'active', label: `Активные (${count('active')})` },
        { key: 'drafts', label: `Черновики (${count('drafts')})` },
        { key: 'archive', label: `Архив (${count('archive')})` },
      ]} />
      {tab === 'active' && <div className="skud-my-requests__summary">
        {visibleSummary.map((item, index) => (
          <button type="button" aria-pressed={statusFilter === statusFilters[index]} onClick={() => setStatusFilter(statusFilters[index] ?? 'total')} className={`skud-my-requests__stat ${index === 0 ? 'is-total' : ''} ${statusFilter === statusFilters[index] ? 'is-selected' : ''}`} key={item.label}>
            <div>{item.label}</div><strong>{item.value}</strong>
            {'color' in item && <div className="skud-my-requests__stat-bar" style={{ background: item.color }} />}
          </button>
        ))}
      </div>}
      <Input className="skud-my-requests__search" placeholder="Поиск по названию объекта" aria-label="Поиск по названию объекта" value={query} onChange={event => setQuery(event.target.value)} />
      <div className="skud-my-requests__cards" aria-live="polite">
        {visibleRequests.length === 0 ? <div className="skud-my-requests__empty"><InboxOutlined /><span>{emptyCopy}</span></div> : visibleRequests.map(request => (
          <article className="skud-my-requests__request" key={request.key}>
            <button type="button" className="skud-my-requests__request-body" onClick={() => onOpenRequest(request.key)} aria-label={`Открыть заявку ${request.name}`}>
              <div className="skud-my-requests__request-top">
                <Tag variant="outlined" className={`skud-my-requests__status-${request.statusColor}`} color={request.statusColor === 'default' ? undefined : request.statusColor}>{request.status}</Tag>
                {request.messages !== undefined && <span className="skud-my-requests__messages">{request.messages} сообщения</span>}
                <time>{request.date}</time>
              </div>
              <h3>{request.service}</h3>
              <div className="skud-my-requests__object" title={request.name}>{request.name}</div>
              <div className="skud-my-requests__address">{request.id}<span>{request.address}</span></div>
            </button>
            <div className="skud-my-requests__request-footer">
              {request.workFormat.trim() && <Tag icon={<ToolOutlined />}>{request.workFormat}</Tag>}
              {request.offers !== undefined && <Tag icon={<UserOutlined />}>{request.offers} предложений</Tag>}
              {tab === 'archive' && <Button size="small" onClick={() => republish(request.key)}>Опубликовать снова</Button>}
              {tab === 'drafts' && <Button className="skud-my-requests__edit-draft" size="small" aria-label={`Редактировать черновик ${request.name}`} icon={<EditOutlined />} onClick={() => onOpenRequest(request.key)} />}
              {request.tab !== 'active' && <Button danger size="small" icon={<DeleteOutlined />} aria-label={`Удалить заявку ${request.name}`} title="Удалить" onClick={() => setDeletingKey(request.key)} />}
            </div>
          </article>
        ))}
      </div>
      <Modal open={deletingRequest !== undefined} title="Вы действительно хотите удалить?" centered okText="Удалить" cancelText="Отменить" okButtonProps={{ danger: true }} onCancel={() => setDeletingKey(undefined)} onOk={() => {
        if (deletingRequest) onDelete?.(deletingRequest.key);
        setDeletingKey(undefined);
      }}>
        {deletingRequest && <p>{deletingRequest.name}</p>}
      </Modal>
      <Modal open={republishingKey !== undefined} footer={null} closable={false} centered width={470} className="skud-my-requests__republishing">
        <div><Spin /><strong>Публикация заявки</strong></div>
      </Modal>
    </div>
  );
}

export default MyRequests;
