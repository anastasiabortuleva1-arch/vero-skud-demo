import { TableTemplate } from './TableTemplate';
import { RequestDocuments } from './RequestDocuments';
import { mergeRequestDocuments, signedRequestDocument, requestContractName, requestReadinessName, requestAcceptanceName } from '../data/requestDocuments';
import { useEffect, useRef, useState } from 'react';
import type { ReactNode } from 'react';
import { Alert, Button, Collapse, Dropdown, Form, Input, Modal, Spin, Tag, Tooltip } from 'antd';
import { ArrowUpOutlined, CheckCircleFilled, CheckOutlined, CloseCircleFilled, EditOutlined, EllipsisOutlined, InfoCircleOutlined, LoadingOutlined, MinusOutlined, PaperClipOutlined, PlusOutlined } from '@ant-design/icons';
import { DocumentRow, DocumentUpload } from './DocumentUpload';
import type { LocalDocument } from './DocumentUpload';
import { installationActPreview, registrationEdit, registrationInstallation, registrationRequest as reference, registrationSignPreview } from '../data/registrationRequest';
import type { RegistrationSnapshot, RegistrationStage, RegistrationVariant } from '../data/registrationRequest';
import './RegistrationRequest.css';

type Overlay = 'form-message' | 'sign' | 'signing' | 'send' | 'edit' | 'updating-data' | 'withdraw' | 'withdraw-act' | 'finish-monitoring' | 'act-sign' | 'act-signing' | 'sign-success' | undefined;
export interface RegistrationRequestProps {
  documents?: LocalDocument[];
  onDocumentSigned?: (document: LocalDocument) => void;
  variant?:RegistrationVariant;
  initialStage?: RegistrationStage;
  object?: {uin:string; name:string; address:string; financing:string; workFormat?:string; schemePreparedBy?:string; scheme?:LocalDocument; composition?:LocalDocument};
  initialSnapshot?:RegistrationSnapshot;
  onDataChange?:(snapshot:RegistrationSnapshot)=>void;
  onMonitoring: () => void;
  onWithdraw: (stage: RegistrationStage) => void;
  onStageChange?: (stage: RegistrationStage) => void;
  /** Stage-3 withdrawal requires an act. This callback does not archive the request itself. */
  onWithdrawalActRequired?:(stage:RegistrationStage)=>void;
  onTerminate?:()=>void;
  additionalWorks?:ReactNode;
  additionalNotice?:ReactNode;
  /** Captured modal fixtures, including the signature notice on entering registration after installation. */
  initialOverlay?:'form-message'|'sign'|'signing'|'send'|'sign-success'|'finish-monitoring'|'withdraw-act'|'edit'|'updating-data';
  /** Different captured correction examples must not be silently merged. */
  governmentCorrection?:'placement'|'object-data';
  /** A deterministic local fixture, never a government or equipment response. */
  outcome?: 'success' | 'government-correction' | 'test-error' | 'test-correction';
}
const sample = (name:string):LocalDocument => ({name,size:12288});
export function RegistrationRequest({documents,onDocumentSigned,variant='registration-only',initialStage='initial',object,initialSnapshot,onDataChange,onMonitoring,onWithdraw,onStageChange,onWithdrawalActRequired,onTerminate,additionalWorks,additionalNotice,initialOverlay,governmentCorrection='placement',outcome='success'}:RegistrationRequestProps) {
  const installation=variant==='installation';
  const [signedDocuments,setSignedDocuments] = useState<LocalDocument[]>(() => documents !== undefined ? [] : ([...(variant==='installation' ? [requestContractName,requestReadinessName,requestAcceptanceName] : []), ...(initialStage!=='initial' ? [reference.information] : []), ...(variant==='installation'&&initialStage==='completed' ? [registrationInstallation.act] : [])]).map(signedRequestDocument));
  const initialSignedDocuments = useRef(signedDocuments);
  const reportedInitialDocuments = useRef(false);
  useEffect(() => {
    if (!onDocumentSigned || reportedInitialDocuments.current) return;
    reportedInitialDocuments.current = true;
    initialSignedDocuments.current.forEach(document => onDocumentSigned(document));
  }, [onDocumentSigned]);
  function recordSigned(name: string) {
    const document = signedRequestDocument(name);
    setSignedDocuments(current => mergeRequestDocuments(current,[document]));
    onDocumentSigned?.(document);
  }
  const [stage,setStage] = useState(initialStage);
  const [overlay,setOverlay] = useState<Overlay>(initialOverlay??(installation&&initialStage==='finish-sign'?'act-sign':undefined));
  const [info,setInfo] = useState<RegistrationSnapshot['info']>(initialSnapshot?.info??{uin:object?.uin ?? reference.uin,name:object?.name ?? (installation?registrationInstallation.name:reference.name),address:object?.address ?? reference.address,financing:object?.financing ?? reference.financing,...(installation?{workFormat:object?.workFormat??registrationInstallation.workFormat,schemePreparedBy:object?.schemePreparedBy??registrationInstallation.schemePreparedBy}:{})});
  const [scheme,setScheme] = useState<LocalDocument|undefined>(initialSnapshot?initialSnapshot.scheme:object?.scheme??(installation||!object?sample(reference.scheme):undefined));
  const [composition,setComposition] = useState<LocalDocument|undefined>(initialSnapshot?initialSnapshot.composition:object?.composition??(installation||!object?sample(reference.composition):undefined));
  const [testFile,setTestFile] = useState<LocalDocument|undefined>(initialSnapshot?initialSnapshot.testFile:['test-ready','testing','test-error','test-correction','test-correction-ready'].includes(initialStage)?sample('СКУД1.json'):undefined);
  const [testError,setTestError] = useState(false);
  const [previewScale,setPreviewScale] = useState(1);
  const [chatMessage,setChatMessage] = useState('');
  const [chatMessages,setChatMessages] = useState<string[]>([]);
  const monitoringAfterSignature=useRef(false);
  const [editForm] = Form.useForm<typeof info>();
  const timeout = useRef<ReturnType<typeof setTimeout>|undefined>(undefined);
  const stageCallback = useRef(onStageChange);
  stageCallback.current = onStageChange;
  const dataCallback=useRef(onDataChange);
  dataCallback.current=onDataChange;
  useEffect(()=>{stageCallback.current?.(stage);},[stage]);
  useEffect(()=>{dataCallback.current?.({info,scheme,composition,testFile});},[info,scheme,composition,testFile]);
  useEffect(()=>{if(overlay==='edit')editForm.setFieldsValue(info);},[overlay,editForm,info]);
  useEffect(()=>()=>clearTimeout(timeout.current),[]);
  function later(action:()=>void) {clearTimeout(timeout.current);timeout.current=setTimeout(action,1000);}
  const testing = stage.startsWith('test') || stage === 'testing';
  const complete = stage==='completed';
  const finishing=installation&&(stage==='finish-ready'||stage==='finish-sign');
  const steps=installation?registrationInstallation.steps:reference.steps;
  const currentStep = installation?complete||finishing?4:testing?3:2:complete?2:testing?1:0;
  const correction = stage==='government-correction'||stage==='test-correction'||stage==='test-correction-ready';
  const status = complete?'Услуга оказана':finishing?'Требуется подпись':stage==='review'?'На проверке':stage==='testing'?'На тестировании':correction?'Требуется исправление':'Ожидает отправки';
  const readonlySkudDocuments = installation?stage!=='government-correction':testing||complete;
  function formMessage() {setPreviewScale(1);setOverlay('form-message');later(()=>setOverlay('sign'));}
  function sign() {setOverlay('signing');later(()=>{recordSigned(reference.information);setStage('ready');setOverlay('send');});}
  function send() {setOverlay(undefined);setStage('review');later(()=>setStage(outcome==='government-correction'?'government-correction':'test-empty'));}
  function startTest() {if(!testFile){setTestError(true);return;}setStage('testing');later(()=>setStage(outcome==='test-error'?'test-error':outcome==='test-correction'?'test-correction':installation?'finish-ready':'completed'));}
  function openAct() {setPreviewScale(1);setStage('finish-sign');setOverlay('act-sign');}
  function cancelAct() {setStage('finish-ready');setOverlay(undefined);monitoringAfterSignature.current=false;}
  // Documented local successful-signature scenario; no payment, signature verification or 15-day timer.
  function signAct() {setOverlay('act-signing');later(()=>{recordSigned(registrationInstallation.act);setStage('completed');setOverlay('sign-success');});}
  function closeSignedNotice() {setOverlay(undefined);if(complete&&monitoringAfterSignature.current){monitoringAfterSignature.current=false;onMonitoring();}}
  function sendChatMessage() {const value=chatMessage.trim();if(value){setChatMessages(messages=>[...messages,value]);setChatMessage('');}}
  function saveInfo() {void editForm.validateFields().then(values=>{setOverlay('updating-data');later(()=>{setInfo(current=>({...current,...values}));setOverlay(undefined);});});}
  function changeTestFile(file?:LocalDocument) {
    setTestFile(file);
    setTestError(false);
    if(stage==='test-correction'||stage==='test-correction-ready') setStage(file?'test-correction-ready':'test-correction');
    else if(file) setStage('test-ready');
  }
  return <div className={`skud-request skud-registration${installation?' skud-registration--installation':''}`}>
    <section className="skud-request__summary">
      <div className="skud-request__heading"><div><div className="skud-request__title"><h1>{object||info.name!==reference.name?`${info.name} — установка и регистрация СКУД`:reference.title}</h1><Tag color={complete?'success':stage==='review'||stage==='testing'?'processing':correction?'error':'warning'} variant="outlined">{status}</Tag></div><p>{reference.id}<span>Создана сегодня</span></p></div><Dropdown disabled={complete||installation&&(testing||finishing)} menu={{items:installation?[{key:'withdraw',label:'Отозвать заявку'},{key:'terminate',label:'Расторгнуть договор',danger:true,disabled:!onTerminate}]:[{key:'withdraw',label:'Отозвать заявку'}],onClick:({key})=>{if(key==='withdraw')setOverlay(installation?'withdraw-act':'withdraw');if(key==='terminate')onTerminate?.();}}} trigger={['click']}><Button disabled={complete||installation&&(testing||finishing)} size="small" icon={<EllipsisOutlined/>} aria-label="Действия с заявкой"/></Dropdown></div>
      <div className="skud-request__conditions"><h2>Условия заявки {!complete&&<Button type="link" icon={<EditOutlined/>} onClick={()=>{editForm.setFieldsValue(info);setOverlay('edit');}}>Изменить условия</Button>}</h2><dl><div><dt>УИН ОКС</dt><dd>{info.uin}</dd></div><div><dt>Источник финансирования</dt><dd>{info.financing}</dd></div>{installation&&<div><dt>Формат работы</dt><dd>{info.workFormat??registrationInstallation.workFormat}</dd></div>}<div className={installation?'skud-registration__address':'is-wide'}><dt>Адрес ОКС</dt><dd>{info.address}</dd></div>{installation&&<div><dt>Схема размещения СКУД</dt><dd>{info.schemePreparedBy??registrationInstallation.schemePreparedBy}</dd></div>}</dl></div>
    </section>
    <div className="skud-request__columns"><div className="skud-request__body">
      {installation&&additionalNotice}
      {finishing&&<div className="skud-registration__finish-notice"><Alert type="warning" showIcon title={registrationInstallation.actTitle} description={<><p>{registrationInstallation.actDescription}</p><div className="skud-registration__act-document"><DocumentRow document={sample(registrationInstallation.act)}/><Button onClick={openAct}>Подписать</Button></div></>}/></div>}
      <section className="skud-request__panel"><h2>{steps[currentStep]}</h2>
        {complete||finishing?<><p>Тестирование успешно пройдено: СКУД подключены к городским системам, сертификат выдан.<br/>Объект доступен в разделе мониторинга</p><DocumentRow document={sample(reference.certificate)}/><div className="skud-request__actions"><Button type="primary" onClick={finishing?()=>{monitoringAfterSignature.current=true;setOverlay('finish-monitoring');}:onMonitoring}>Перейти к мониторингу</Button></div></>:testing?<>
          <p>{reference.testingDescription}</p>
          {stage==='test-error'&&<Alert type="error" showIcon title="Не удалось провести тестирование. Попробуйте запустить повторно"/>}
          {stage==='test-correction'&&<Alert type="error" showIcon title="Тестирование выявило замечания" description="В пакете данных не хватает параметров для части оборудования. Обновите файл и повторите тестирование"/>}
          <div className="skud-request__document-card"><h3>Пакет данных для тестирования <Tooltip title="Данный файл можно взять в клиенте вашего БД СКУД" trigger={['hover','focus']}><button type="button" className="skud-json-help" aria-label="Где взять файл JSON"><InfoCircleOutlined/></button></Tooltip></h3>{!testFile&&<p>{installation&&testError?registrationInstallation.testValidationDescription:'Добавьте пакет данных в формате JSON о первом тестовом проходе'}</p>}{installation&&testError&&<div className="skud-registration__test-validation" role="alert">Добавьте файлы</div>}{stage==='testing'&&testFile?<DocumentRow document={testFile}/>:<DocumentUpload value={testFile} accept=".json" error={testError?'Добавьте файлы':undefined} onChange={changeTestFile}/>}</div>
          {stage==='testing'&&<div className="skud-request__progress"><Spin size="small"/>Проводится тестирование</div>}
          <div className="skud-request__actions"><Button type="primary" disabled={stage==='testing'} onClick={startTest}>К тестированию</Button></div>
        </>:<>
          <p>{stage==='initial'?'Сформируйте информационное сообщение, чтобы передать в Правительство Москвы сведения об установленном и проверенном оборудовании':'После отправки Правительство Москвы проверит данные по СКУД и подтвердит возможность регистрации'}</p>
          {stage==='government-correction'&&<Alert className="skud-request__government-correction" type="error" showIcon title="Исправьте данные и повторно сформируйте информационное сообщение" description={governmentCorrection==='object-data'?registrationEdit.objectDataCorrection:<><strong>Комментарий Правительства Москвы</strong><p>Необходимо скорректировать расположение СКУД</p></>}/>}
          {(stage==='ready'||stage==='review'||stage==='government-correction')&&<DocumentRow document={sample(reference.information)}/>}
          {(stage==='review'||stage==='government-correction')&&<div className="skud-request__checks">{(installation&&stage==='review'?reference.checks.slice(0,2):reference.checks).map((label,i)=><div key={label}>{stage==='review'?<Spin size="small"/>:i===1||governmentCorrection==='object-data'&&i===0?<CloseCircleFilled style={{color:'#ff4d4f'}}/>:<CheckOutlined style={{color:'#52c41a'}}/>}{label}</div>)}</div>}
          <div className="skud-request__actions"><Button type="primary" disabled={stage==='review'} onClick={stage==='ready'?()=>setOverlay('send'):formMessage}>{stage==='initial'||stage==='government-correction'?'Сформировать сообщение':'Отправить на проверку'}</Button></div>
        </>}
      </section>
      <section className="skud-request__panel"><h2>Сведения о СКУД</h2><div className="skud-request__document-card"><h3>Состав технических средств СКУД в табличной форме</h3>{!readonlySkudDocuments&&<TableTemplate/>}{readonlySkudDocuments?(composition&&<DocumentRow document={composition}/>):<DocumentUpload value={composition} onChange={setComposition} accept=".xlsx"/>}</div><div className="skud-request__document-card"><h3>Схема размещения СКУД</h3>{readonlySkudDocuments?(scheme&&<DocumentRow document={scheme}/>):<DocumentUpload value={scheme} onChange={setScheme} accept=".pdf"/>}</div></section>
      {installation&&!complete&&!finishing&&(additionalWorks??(!testing&&<section className="skud-request__panel skud-registration__additional"><h2>Дополнительные работы</h2><p>{registrationInstallation.additionalDescription}</p><div className="skud-request__actions"><Button disabled>Дополнительное соглашение</Button></div></section>))}
      {/* The testing screenshots clip before any continuation; chat is confirmed in the government and finish frames. */}
      {installation&&!testing&&<section className="skud-request__panel skud-registration__chat"><h2>Чат с исполнителем</h2><div className="skud-registration__messages"><div className="skud-registration__chat-date">{registrationInstallation.chat.date}</div><div className="skud-registration__message"><span><CheckOutlined/> {registrationInstallation.chat.time}</span><div>{registrationInstallation.chat.message}</div></div>{chatMessages.map((message,index)=><div className="skud-registration__message" key={index}><div>{message}</div></div>)}</div><div className="skud-registration__chat-input"><PaperClipOutlined/><Input placeholder="Введите сообщение" aria-label="Введите сообщение" value={chatMessage} onChange={event=>setChatMessage(event.target.value)} onPressEnter={sendChatMessage} suffix={<Button type="primary" shape="circle" size="small" icon={<ArrowUpOutlined/>} aria-label="Отправить сообщение" disabled={!chatMessage.trim()} onClick={sendChatMessage}/>}/></div></section>}
    </div><aside className="skud-request__aside"><ol className="skud-request__steps">{steps.map((label,i)=><li key={label} className={i<currentStep||complete?'is-done':i===currentStep?'is-current':''}><span className="skud-request__step-number">{i<currentStep||complete?<CheckOutlined/>:i+1}</span><div>{label}{i===currentStep&&!complete&&<p>{status}</p>}</div></li>)}</ol><Collapse className="skud-request__documents" expandIconPlacement="end" items={[{key:'documents',label:'Документы по заявке',children:<RequestDocuments documents={documents} localDocuments={[object?.composition,object?.scheme,composition,scheme,testFile]} signedDocuments={signedDocuments}/>}]}/></aside></div>
    <Modal open={overlay==='form-message'||overlay==='signing'||overlay==='act-signing'||overlay==='updating-data'} centered footer={null} closable={false} width={520}><div className="skud-request__loading"><Spin indicator={<LoadingOutlined spin/>}/><strong>{overlay==='updating-data'?registrationEdit.loading:overlay==='signing'||overlay==='act-signing'?'Подписание документов':'Формирование информационного сообщения'}</strong></div></Modal>
    <Modal open={overlay==='sign'} title="Подписать документ" width={820} centered onCancel={()=>setOverlay(undefined)} footer={<><p className="skud-request__sign-description">После подписания информационное сообщение будет отправлено на проверку в Правительство Москвы</p><Button onClick={()=>setOverlay(undefined)}>Отменить</Button><Button type="primary" onClick={sign}>Подписать</Button></>}>
      <div className="skud-request__viewer">
        <div className="skud-request__paper" style={{zoom:previewScale}}>
          <h2>{registrationSignPreview.title}</h2>
          <p className="skud-request__paper-subtitle">{registrationSignPreview.subtitle[0]}<br/>{registrationSignPreview.subtitle[1]}</p>
          <p className="skud-request__paper-note">{registrationSignPreview.note}</p>
          {registrationSignPreview.sections.map(section=><section key={section.title}><h3>{section.title}</h3>{section.lines.map(line=><div key={line}>{line}</div>)}{'after' in section&&<p className="skud-request__paper-after">{section.after}</p>}</section>)}
        </div>
        <div className="skud-request__viewer-controls"><Button shape="circle" size="small" icon={<PlusOutlined/>} aria-label="Увеличить документ" onClick={()=>setPreviewScale(value=>Math.min(2,value+.1))}/><Button shape="circle" size="small" icon={<MinusOutlined/>} aria-label="Уменьшить документ" onClick={()=>setPreviewScale(value=>Math.max(.5,value-.1))}/><Button shape="circle" size="small" aria-label="Масштаб документа 1:1" onClick={()=>setPreviewScale(1)}>1:1</Button></div>
      </div>
    </Modal>
    <Modal open={overlay==='send'} title="Отправить информационное сообщение" centered width={520} onCancel={()=>setOverlay(undefined)} footer={<><Button onClick={()=>setOverlay(undefined)}>Закрыть</Button><Button type="primary" onClick={send}>Отправить на проверку</Button></>}><DocumentRow document={sample(reference.information)}/><p>Документ подписан и готов к отправке в Правительство Москвы</p></Modal>
    <Modal open={overlay==='edit'} className="skud-registration__edit-modal" title="Изменение данных" width={1064} centered onCancel={()=>setOverlay(undefined)} okText="Сохранить" cancelText="Отменить" onOk={saveInfo}><h3>{registrationEdit.heading}</h3><Form form={editForm} layout="vertical"><div className="skud-registration__edit-grid"><Form.Item name="uin" label={registrationEdit.uin}><Input/></Form.Item><Form.Item name="name" label={registrationEdit.name}><Input/></Form.Item><Form.Item className="skud-registration__edit-address" name="address" label={registrationEdit.address}><Input/></Form.Item></div><Form.Item name="financing" hidden><Input/></Form.Item></Form></Modal>
    <Modal open={installation&&overlay==='withdraw-act'} title={registrationInstallation.withdrawalTitle} centered width={520} onCancel={()=>setOverlay(undefined)} footer={<><Button onClick={()=>setOverlay(undefined)}>Отменить</Button><Button type="primary" onClick={()=>onWithdrawalActRequired?.(stage)}>Отозвать</Button></>}>{registrationInstallation.withdrawalDescription}</Modal>
    <Modal open={installation&&overlay==='finish-monitoring'} title={registrationInstallation.monitoringTitle} centered width={520} onCancel={()=>{setOverlay(undefined);monitoringAfterSignature.current=false;}} footer={<><Button onClick={()=>{setOverlay(undefined);monitoringAfterSignature.current=false;}}>Отменить</Button><Button type="primary" onClick={openAct}>Подписать</Button></>}>{registrationInstallation.monitoringDescription}</Modal>
    <Modal open={installation&&overlay==='act-sign'} title="Подписать документ" width={820} centered onCancel={cancelAct} footer={<><Button onClick={cancelAct}>Отменить</Button><Button type="primary" onClick={signAct}>Подписать</Button></>}><div className="skud-request__viewer"><div className="skud-registration__act-paper" style={{zoom:previewScale}}><InstallationActPaper/></div><div className="skud-request__viewer-controls"><Button shape="circle" size="small" icon={<PlusOutlined/>} aria-label="Увеличить документ" onClick={()=>setPreviewScale(value=>Math.min(2,value+.1))}/><Button shape="circle" size="small" icon={<MinusOutlined/>} aria-label="Уменьшить документ" onClick={()=>setPreviewScale(value=>Math.max(.5,value-.1))}/><Button shape="circle" size="small" aria-label="Масштаб документа 1:1" onClick={()=>setPreviewScale(1)}>1:1</Button></div></div></Modal>
    <Modal open={installation&&overlay==='sign-success'} centered width={448} onCancel={closeSignedNotice} footer={<Button type="primary" onClick={closeSignedNotice}>Хорошо</Button>}><div className="skud-registration__signed-notice"><CheckCircleFilled/><div><strong>Документ успешно подписан</strong><p>Электронная подпись добавлена</p></div></div></Modal>
    <Modal open={overlay==='withdraw'&&!complete} title="Отозвать заявку?" centered onCancel={()=>setOverlay(undefined)} okText="Отозвать" cancelText="Отменить" okButtonProps={{danger:true}} onOk={()=>{if(!complete)onWithdraw(stage);}}>Заявка будет перемещена в Архив</Modal>
  </div>;
}

function InstallationActPaper() {
  const preview=installationActPreview;
  return <><h2>{preview.title}</h2><div className="skud-registration__act-parties"><p>Исполнитель: <strong>{preview.executor}</strong></p><p>Заказчик: <strong>{preview.customer}</strong></p></div><table><thead><tr>{preview.columns.map(label=><th key={label}>{label}</th>)}</tr></thead></table><div className="skud-registration__act-unreadable"/><p className="skud-registration__act-total"><strong>Итого: {preview.total}</strong><br/>{preview.tax}</p><p>{preview.amount}<br/><strong>{preview.words}</strong></p><p>{preview.conclusion}</p><div className="skud-registration__act-signatures"><div><strong>ИСПОЛНИТЕЛЬ</strong><br/>{preview.executor}</div><div><strong>ЗАКАЗЧИК</strong><br/>{preview.customer}</div></div></>;
}
