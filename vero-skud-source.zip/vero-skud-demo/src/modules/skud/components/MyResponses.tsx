import {useState} from 'react';
import {Button,Empty,Input,Modal,Tabs,Tag} from 'antd';
import {CalendarOutlined,DeleteOutlined,ToolOutlined} from '@ant-design/icons';
import type {ExecutorResponse} from '../data/executorResponses';
import './MyRequests.css';
import './MyResponses.css';
const filters=[['all','Всего активных заявок'],['action','Требует действия'],['work','В работе'],['termination','Расторжение'],['completed','Завершено']] as const;
export function MyResponses({requests,onOpen,onDelete,initialTab='active'}:{requests:ExecutorResponse[];onOpen:(item:ExecutorResponse)=>void;onDelete:(key:string)=>void;initialTab?:'active'|'archive'}){
 const [tab,setTab]=useState(initialTab); const [filter,setFilter]=useState('all'); const [query,setQuery]=useState('');const [deleting,setDeleting]=useState<ExecutorResponse>(); const [archived,setArchived]=useState<ExecutorResponse>();
 const active=requests.filter(item=>item.tab==='active');
 const visible=requests.filter(item=>item.tab===tab&&(tab==='archive'||filter==='all'||item.group===filter)&&`${item.name} ${item.id} ${item.address}`.toLocaleLowerCase('ru-RU').includes(query.trim().toLocaleLowerCase('ru-RU')));
 return <div className="skud-my-requests skud-my-responses"><h1>Мои отклики</h1><p className="skud-my-requests__subtitle">Отслеживайте статус и просматривайте историю всех взятых в работу заявок</p>
 <Tabs activeKey={tab} onChange={value=>setTab(value as 'active'|'archive')} items={[{key:'active',label:`Активные (${active.length})`},{key:'archive',label:`Архив (${requests.length-active.length})`}]}/>
 {tab==='active'&&<div className="skud-my-responses__stats">{filters.map(([key,label])=><button key={key} type="button" className={`skud-my-responses__stat is-${key}`} aria-pressed={filter===key} onClick={()=>setFilter(key)}><span>{label}</span><strong>{active.filter(item=>key==='all'||item.group===key).length}</strong>{key!=='all'&&<i/>}</button>)}</div>}
 <Input aria-label="Поиск по названию объекта" placeholder="Поиск по названию объекта" value={query} allowClear onChange={event=>setQuery(event.target.value)}/>
 <div className="skud-my-requests__cards">{visible.map(item=><article className="skud-my-requests__request" key={item.key}><button className="skud-my-requests__request-body" onClick={()=>item.tab==='archive'&&!item.stage?setArchived(item):onOpen(item)} aria-label={`Открыть заявку ${item.name}`}><div className="skud-my-requests__request-top"><Tag color={item.color==='default'?undefined:item.color} variant="outlined">{item.status}</Tag>{item.messages&&<Tag color="error">{item.messages} сообщений</Tag>}</div><h3>{item.title}</h3><p>{item.name}</p><div className="skud-my-responses__address">{item.id} · {item.address}</div></button><div className="skud-my-responses__footer"><Tag icon={<ToolOutlined/>}>{item.workFormat}</Tag><Tag icon={<CalendarOutlined/>}>до {item.deadline}</Tag>{tab==='archive'&&<Button danger size="small" icon={<DeleteOutlined/>} aria-label={`Удалить заявку ${item.name}`} onClick={()=>setDeleting(item)}/>}</div></article>)}</div>
 {!visible.length&&<Empty description={query?'По вашему поиску отклики не найдены':tab==='archive'?'В архиве пока нет откликов':filter==='all'?'У вас пока нет активных откликов':'Заявок с выбранным статусом нет'}/>}
 <Modal open={!!archived} title={archived?.name} footer={<Button onClick={()=>setArchived(undefined)}>Закрыть</Button>} onCancel={()=>setArchived(undefined)}><Tag>{archived?.status}</Tag><p>{archived?.title}</p><p>{archived?.id} · {archived?.address}</p><p>{archived?.workFormat}</p><p>Заявка отозвана заказчиком и сохранена в истории откликов.</p></Modal>
 <Modal open={!!deleting} title="Вы действительно хотите удалить?" okText="Удалить" cancelText="Отменить" okButtonProps={{danger:true}} onCancel={()=>setDeleting(undefined)} onOk={()=>{if(deleting)onDelete(deleting.key);setDeleting(undefined);}}><p>Заявка {deleting?.name} будет удалена из архива откликов.</p></Modal>
 </div>;
}
