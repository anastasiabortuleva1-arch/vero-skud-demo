import { useState } from 'react';
import { Alert, Button, Input, Modal, Radio } from 'antd';
import type { MonitoringObject } from '../data/monitoring';
import './ContractTermination.css';

export interface MonitoringTerminationState {
  status: 'active' | 'pending' | 'terminated';
  reason?: string;
  comment?: string;
}
const reasons = ['Не устроил интегратор', 'Снимаются временные ограждения (в соответствии с 299-ПП)', 'Иное'];
export function MonitoringTermination({open,onClose,object,onSend,onRegistration}:{
  open:boolean;onClose:()=>void;object:MonitoringObject;
  onSend:(value:MonitoringTerminationState)=>void;onRegistration:()=>void;
}) {
  const [step,setStep]=useState<'reason'|'sign'>('reason');
  const [reason,setReason]=useState('');
  const [comment,setComment]=useState('');
  const [error,setError]=useState(false);
  const needsComment=reason===reasons[0]||reason===reasons[2];
  function next(){if(!reason||(needsComment&&!comment.trim())){setError(true);return;}setStep('sign');}
  return <Modal open={open} onCancel={onClose} footer={null} centered width={720} title={step==='reason'?'Расторгнуть договор с подрядчиком':'Подписание соглашения о расторжении'} className="skud-contract-termination">
    {step==='reason'?<>
      <p className="skud-contract-termination__subtitle">Укажите причину расторжения договора по объекту {object.name}. Мы подготовим дополнительное соглашение и после вашей подписи направим его подрядчику.</p>
      <Radio.Group className="skud-contract-termination__reasons" value={reason} onChange={event=>{setReason(event.target.value);setError(false);}}>{reasons.map(item=><Radio key={item} value={item}>{item}</Radio>)}</Radio.Group>
      {error&&!reason&&<div role="alert" className="skud-contract-termination__error">Выберите причину расторжения</div>}
      {reason===reasons[0]&&<Alert style={{marginTop:16}} type="info" showIcon title="Продолжите работу с новым подрядчиком" description={<><p>Создайте заявку в разделе «Подключение и регистрация СКУД», чтобы выбрать нового подрядчика и организовать дальнейшее обслуживание объекта.</p><Button type="link" style={{padding:0}} onClick={onRegistration}>Перейти к созданию заявки</Button></>}/>}
      {needsComment&&<div className="skud-contract-termination__comment"><label htmlFor="termination-comment">Комментарий</label><Input.TextArea id="termination-comment" value={comment} rows={4} placeholder={reason===reasons[0]?'Расскажите, что вас не устроило в работе интегратора':'Опишите причину расторжения договора'} status={error&&!comment.trim()?'error':undefined} aria-invalid={error&&!comment.trim()} aria-describedby={error?'termination-error':undefined} onChange={event=>{setComment(event.target.value);setError(false);}}/>{error&&!comment.trim()&&<div id="termination-error" role="alert" className="skud-contract-termination__error">Добавьте комментарий, чтобы продолжить</div>}</div>}
      <div className="skud-contract-termination__actions"><Button onClick={onClose}>Отмена</Button><Button type="primary" onClick={next}>К подписанию</Button></div>
    </>:<>
      <p className="skud-contract-termination__subtitle">Проверьте сведения. После подписания соглашение получит подрядчик {object.contractor}. Договор будет расторгнут после подписи второй стороны.</p>
      <section className="skud-monitor__termination-document"><h3>Дополнительное соглашение о расторжении договора</h3><p>Объект: {object.name}</p><p>Заявка: {object.requestId}</p><p>Подрядчик: {object.contractor}</p><p>Причина: {reason}</p>{needsComment&&<p>Комментарий: {comment.trim()}</p>}<Tagline/></section>
      <div className="skud-contract-termination__actions"><Button onClick={()=>setStep('reason')}>Назад</Button><Button type="primary" onClick={()=>onSend({status:'pending',reason,comment:needsComment?comment.trim():undefined})}>Подписать и отправить</Button></div>
    </>}
  </Modal>;
}
function Tagline(){return <p className="skud-monitor__termination-note">Демонстрационный документ. Подписание имитируется в демоверсии.</p>;}
