import { Button, Dropdown, Select, Tag } from 'antd';
import { ArrowRightOutlined, ExperimentOutlined, ReloadOutlined } from '@ant-design/icons';
import './DemoControls.css';

export type DemoFamily = 'install' | 'registration' | 'work' | 'offer' | 'form' | 'list' | 'monitoring';
const states = {
  install: [['empty-offers','Предложений пока нет'],['offers','Получены предложения'],['offer','Коммерческое предложение'],['contract-sign','Подписание договора'],['preparation','Подготовка площадки'],['working','Монтаж в работе'],['acceptance','Результат на приёмке'],['accept-sign','Подписание акта'],['rework','Отправлено на доработку']],
  registration: [['initial','Подготовка сообщения'],['ready','Готово к отправке'],['review','Проверка в Правительстве'],['government-correction','Замечания Правительства'],['test-empty','Ожидание пакета JSON'],['test-ready','Пакет JSON загружен'],['testing','Тестирование'],['test-error','Ошибка тестирования'],['test-correction','Нужны исправления'],['test-correction-ready','Исправления готовы'],['finish-ready','Завершение работ'],['finish-sign','Подписание итогового акта'],['completed','Услуга оказана']],
  work: [['preparation','Ожидание готовности площадки'],['readiness','Площадка готова'],['readiness-sign','Подписание акта готовности'],['readiness-sign-error','Ошибка подписи акта'],['readiness-signed','Акт готовности подписан'],['working','Монтаж в работе'],['missing-documents','Не хватает документов'],['uploading','Загрузка документов'],['checking','Проверка состава СКУД'],['validated','Проверка пройдена'],['npa-error','Ошибка соответствия НПА'],['npa-error-submit','Отправка с ошибкой НПА'],['correction','Исправление состава'],['correction-uploading','Загрузка исправлений'],['review','Результат у заказчика'],['rework','Заказчик вернул на доработку'],['rework-missing-scheme','Доработка: нет схемы'],['rework-uploading','Доработка: загрузка'],['rework-ready','Доработка готова'],['acceptance','Заказчик принял работу'],['acceptance-sign','Подписание акта приёмки'],['registration','Регистрация и подключение'],['finishing','Итоговый акт'],['finish-sign','Подписание итогового акта'],['finish-signing','Подпись выполняется'],['finish-sign-error','Ошибка итоговой подписи'],['finish-signed','Итоговый акт подписан'],['finished','Мониторинг активен']],
  offer: [['form','Пустая форма КП'],['filled','Заполненное КП'],['validation','Ошибки заполнения'],['contract','Договор'],['signing','Подписание'],['sign-error','Ошибка подписи'],['signed','Подписано'],['pending','Отклик на рассмотрении']],
} as const;
const nextStates: Record<string, [string,string]> = {
  'install:empty-offers':['offers','Сымитировать предложения'], 'install:offers':['offer','Открыть предложение'], 'install:offer':['contract-sign','К договору'],
  'install:contract-sign':['preparation','Договор подписан'], 'install:preparation':['working','Начать монтаж'], 'install:working':['acceptance','Получить результат работы'], 'install:acceptance':['accept-sign','К акту приёмки'], 'install:accept-sign':['@registration','Перейти к регистрации'], 'install:rework':['acceptance','Получить исправленный результат'],
  'registration:initial':['ready','Сообщение готово'], 'registration:ready':['review','Начать проверку'], 'registration:review':['test-empty','Проверка пройдена'], 'registration:government-correction':['ready','Исправления внесены'], 'registration:test-empty':['test-ready','Добавить демо JSON'], 'registration:test-ready':['testing','Начать тестирование'], 'registration:testing':['finish-ready','Тестирование пройдено'], 'registration:test-error':['test-ready','Повторить тестирование'], 'registration:test-correction':['test-correction-ready','Добавить исправления'], 'registration:test-correction-ready':['testing','Повторить тестирование'], 'registration:finish-ready':['finish-sign','К итоговому акту'], 'registration:finish-sign':['completed','Завершить заявку'], 'registration:completed':['@monitoring','Открыть мониторинг'],
  'work:preparation':['readiness','Площадка готова'], 'work:readiness':['readiness-sign','К акту готовности'], 'work:readiness-sign':['working','Начать монтаж'], 'work:readiness-signed':['working','Начать монтаж'], 'work:working':['validated','Добавить проверенные документы'], 'work:validated':['review','Результат отправлен'], 'work:review':['acceptance','Сымитировать приёмку заказчиком'], 'work:rework':['rework-ready','Добавить исправленный результат'], 'work:rework-ready':['review','Результат отправлен'], 'work:acceptance':['acceptance-sign','К акту приёмки'], 'work:acceptance-sign':['registration','Перейти к регистрации'], 'work:registration':['finishing','Регистрация завершена'], 'work:finishing':['finish-sign','К итоговому акту'], 'work:finish-sign':['finished','Завершить заявку'], 'work:finish-signed':['finished','Завершить заявку'], 'work:finished':['@monitoring','Открыть мониторинг'],
  'offer:form':['filled','Показать заполненное КП'], 'offer:filled':['contract','К договору'], 'offer:contract':['signed','Договор подписан'], 'offer:signed':['pending','Отклик отправлен'], 'offer:pending':['@work','Заказчик выбрал исполнителя'],
};
export function DemoControls({family,stage,role,onStage,onNavigate,onFill,onReset,onVariant,onTerminate,onCompleteTermination}: {
  onCompleteTermination?:()=>void;
  family: DemoFamily; stage: string; role: 'customer'|'executor'; onStage:(stage:string)=>void;
  onNavigate:(path:string)=>void; onFill?:()=>void; onReset:()=>void; onVariant:(values:Record<string,string>)=>void; onTerminate?:()=>void;
}) {
  const options = family in states ? states[family as keyof typeof states] : [];
  const next = nextStates[`${family}:${stage}`];
  const screens = role === 'customer' ? [
    ['Заявки','/skud/requests'],['Новая заявка на монтаж','/skud/new/install'],['Новая заявка на регистрацию','/skud/new/registration'],['Монтаж: нет предложений','/skud/requests/installation-example?stage=empty-offers'],['Регистрация','/skud/requests/registration-example'],['Регистрация после монтажа','/skud/requests/installation-registration-example'],['Мониторинг','/skud/monitoring'],
  ] : [['Входящие заявки','/skud/incoming'],['Новое КП','/skud/offer/example'],['Отклик на рассмотрении','/skud/responses/example'],['Монтаж','/skud/work/example?stage=preparation'],['Мониторинг','/skud/monitoring?role=executor']];
  const variants = family === 'install' || family === 'registration' ? [
    ['Предложение о допработах',()=>onVariant({agreement:'proposal'})],['Допсоглашение согласовано',()=>onVariant({agreement:'confirmed'})],['Ошибка подписи',()=>onVariant({sign:'error',stage:family==='install'?'contract-sign':'finish-sign'})],
    ...(family==='install' ? [['Недостаточно средств',()=>onVariant({stage:'contract-sign',funds:'insufficient'})],['Исправленный результат',()=>onVariant({stage:'acceptance',version:'2'})]] as const : [['Замечания при проверке',()=>onStage('government-correction')],['Ошибка тестирования',()=>onStage('test-error')]] as const),
    ...(onTerminate ? [['Запрос расторжения',onTerminate]] as const : []),
  ] : family === 'work' ? [
    ['Запрос допработ от заказчика',()=>onVariant({origin:'customer',agreement:'incoming'})],['Создать допсоглашение',()=>onVariant({origin:'executor',agreement:'select'})],['Заполненная оценка допработ',()=>onVariant({origin:'customer',agreement:'estimate',estimate:'filledDeadline'})],['Допсоглашение согласовано',()=>onVariant({agreement:'confirmed'})],['Ошибка проверки НПА',()=>onStage('npa-error')],['Возврат на доработку',()=>onStage('rework')],
  ] : family === 'monitoring' ? [
    ['Пустой список',()=>onNavigate(`/skud/monitoring?empty=1&role=${role}`)],['Сбои оборудования',()=>onNavigate(`/skud/monitoring/kolomenskoye?role=${role}`)],
    ...(role==='customer' ? [['Всё работает',()=>onNavigate('/skud/monitoring/kolomenskoye-healthy')],['Аналитика',()=>onNavigate('/skud/monitoring/kolomenskoye-analytics')]] as const : []),
  ] : [];
  return <footer className="skud-demo" aria-label="Управление демо">
    <div className="skud-demo__caption"><Tag icon={<ExperimentOutlined />} color="blue">Демо</Tag><span>Управляйте сценарием — действия здесь имитируют события платформы</span></div>
    <div className="skud-demo__actions">
      <Dropdown menu={{items:screens.map(([label,path])=>({key:path,label,onClick:()=>onNavigate(path)}))}} trigger={['click']}><Button>Сценарии</Button></Dropdown>
      {options.length>0 && <Select aria-label="Состояние демо" placeholder="Выберите состояние" value={options.some(([value])=>value===stage)?stage:undefined} options={options.map(([value,label])=>({value,label}))} onChange={onStage} popupMatchSelectWidth={340} className="skud-demo__state" />}
      {onCompleteTermination&&<Button type="primary" onClick={onCompleteTermination}>Сымитировать подпись подрядчика</Button>}
      {onFill && <Button onClick={onFill}>Заполнить все поля</Button>}
      {next && <Button type="primary" icon={<ArrowRightOutlined />} onClick={()=>onStage(next[0])}>{next[1]}</Button>}
      {variants.length>0 && <Dropdown menu={{items:variants.map(([label,action])=>({key:label as string,label:label as string,onClick:action as ()=>void}))}} trigger={['click']}><Button>Другие события</Button></Dropdown>}
      <Button icon={<ReloadOutlined />} onClick={onReset}>Начать заново</Button>
    </div>
  </footer>;
}
