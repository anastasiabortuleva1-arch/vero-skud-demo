import { Button } from 'antd';
import { DownloadOutlined, FileExcelFilled } from '@ant-design/icons';
import { demoDocument } from '../data/demoDocuments';
import './TableTemplate.css';

export function TableTemplate() {
  function download() {
    const document = demoDocument('Шаблон таблицы.xlsx', 'xlsx');
    const url = URL.createObjectURL(document.file!);
    const link = window.document.createElement('a');
    link.href = url; link.download = document.name; link.click();
    window.setTimeout(()=>URL.revokeObjectURL(url),1000);
  }
  return <div className="skud-table-template">
    <FileExcelFilled />
    <div><strong>Шаблон таблицы.xlsx</strong><span>Демонстрационный файл-заглушка</span></div>
    <Button type="link" icon={<DownloadOutlined />} onClick={download}>Скачать шаблон таблицы</Button>
  </div>;
}
