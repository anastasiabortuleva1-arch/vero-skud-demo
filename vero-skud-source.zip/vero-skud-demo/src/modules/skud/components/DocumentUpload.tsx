import { Button, Upload } from 'antd';
import { DeleteOutlined, DownloadOutlined, FileExcelFilled, FilePdfFilled, FileTextFilled, InboxOutlined } from '@ant-design/icons';
import './DocumentUpload.css';

export interface LocalDocument { name: string; size: number; file?: File }
export function DocumentRow({ document, onRemove }: { document: LocalDocument; onRemove?: () => void }) {
  const extension = document.name.split('.').pop()?.toLowerCase();
  function download() {
    if (!document.file) return;
    const url = URL.createObjectURL(document.file);
    const link = window.document.createElement('a'); link.href = url; link.download = document.name; link.click();
    window.setTimeout(() => URL.revokeObjectURL(url), 1000);
  }
  return <div className="skud-document">
    <span className={`skud-document__icon skud-document__icon--${extension}`}>
      {extension === 'pdf' ? <FilePdfFilled /> : extension === 'xlsx' ? <FileExcelFilled /> : <FileTextFilled />}
    </span>
    <div className="skud-document__name"><strong title={document.name}>{document.name}</strong><span>{Math.max(1, Math.round(document.size / 1024))} КБ</span></div>
    <Button aria-label={`Скачать ${document.name}`} icon={<DownloadOutlined />} disabled={!document.file} onClick={download}/>
    {onRemove && <Button danger aria-label={`Удалить ${document.name}`} icon={<DeleteOutlined />} onClick={onRemove}/>}
  </div>;
}
export function DocumentUpload({ value, onChange, accept, error }: { value?: LocalDocument; onChange: (file?: LocalDocument) => void; accept: string; error?: string }) {
  if (value) return <DocumentRow document={value} onRemove={() => onChange(undefined)}/>;
  return <div className={`skud-upload ${error ? 'skud-upload--error' : ''}`}>
    <Upload.Dragger accept={accept} multiple={false} showUploadList={false} beforeUpload={file => { onChange({name:file.name,size:file.size,file}); return false; }}>
      <InboxOutlined className="skud-upload__icon"/>
      <div>Выберите или перетащите файл для загрузки</div>
    </Upload.Dragger>
    {error && <div className="skud-upload__error">{error}</div>}
  </div>;
}
