import { useMemo, useState } from 'react';
import { Button, Input, Modal, Select, Tag } from 'antd';
import { CheckCircleFilled, CloseOutlined, SearchOutlined, ToolOutlined, UserOutlined } from '@ant-design/icons';
import {
  incomingEquipmentOptions,
  incomingOrganizations,
  incomingRequestFixtures,
  incomingSortOptions,
  incomingWorkFormats,
} from '../data/incomingRequests';
import type { EquipmentFilterValue, IncomingRequest, IncomingSortOption, IncomingWorkFormat } from '../data/incomingRequests';
import './IncomingRequests.css';

export interface IncomingRequestsProps {
  requests?: readonly IncomingRequest[];
  onRespond: (key: string, format: IncomingWorkFormat) => void;
}

export function IncomingRequests({ requests = incomingRequestFixtures, onRespond }: IncomingRequestsProps) {
  const [query, setQuery] = useState('');
  const [format, setFormat] = useState<IncomingWorkFormat>();
  const [customers, setCustomers] = useState<string[]>([]);
  const [equipment, setEquipment] = useState<EquipmentFilterValue>();
  const [sort, setSort] = useState<IncomingSortOption>('Сначала новые');
  const [confirmRequest, setConfirmRequest] = useState<IncomingRequest>();

  const visibleRequests = useMemo(() => {
    const needle = query.trim().toLocaleLowerCase('ru-RU');
    const filtered = requests.filter(request => {
      if (needle && !request.organization.toLocaleLowerCase('ru-RU').includes(needle)) return false;
      if (format && request.workFormat !== format) return false;
      if (customers.length && !customers.some(customer => request.organization.toLocaleLowerCase('ru-RU').includes(customer.toLocaleLowerCase('ru-RU')))) return false;
      if (equipment && request.equipmentAvailable !== (equipment === 'Оборудование в наличии')) return false;
      return true;
    });
    const ordered = [...filtered];
    if (sort === 'Сначала новые') ordered.sort((a, b) => b.dateOrder - a.dateOrder);
    else if (sort === 'Сначала старые') ordered.sort((a, b) => a.dateOrder - b.dateOrder);
    else if (sort === 'Сначала просмотренные') ordered.sort((a, b) => Number(Boolean(b.viewed)) - Number(Boolean(a.viewed)) || b.dateOrder - a.dateOrder);
    else ordered.sort((a, b) => Number(Boolean(a.viewed)) - Number(Boolean(b.viewed)) || b.dateOrder - a.dateOrder);
    return ordered;
  }, [requests, query, format, customers, equipment, sort]);

  function respond(request: IncomingRequest) {
    if (request.workFormat === 'Монтаж и ТО') setConfirmRequest(request);
    else onRespond(request.key, request.workFormat);
  }

  function confirmRespond() {
    if (!confirmRequest) return;
    onRespond(confirmRequest.key, confirmRequest.workFormat);
    setConfirmRequest(undefined);
  }

  const clearChip = (kind: 'format' | 'customer' | 'equipment', value?: string) => {
    if (kind === 'format') setFormat(undefined);
    if (kind === 'equipment') setEquipment(undefined);
    if (kind === 'customer' && value) setCustomers(current => current.filter(customer => customer !== value));
  };

  return (
    <div className="skud-incoming-requests">
      <h1>Входящие заявки</h1>
      <p className="skud-incoming-requests__subtitle">Выберите подходящую заявку и отправьте коммерческое предложение</p>

      <section className="skud-incoming-requests__filters" aria-label="Поиск и фильтры заявок">
        <Input className="skud-incoming-requests__search" placeholder="Поиск по названию организации" prefix={<SearchOutlined />} value={query} onChange={event => setQuery(event.target.value)} />
        <div className="skud-incoming-requests__filter-row">
          <Select allowClear placeholder="Формат работы" value={format} options={incomingWorkFormats.map(value => ({ label: value, value }))} onChange={value => setFormat(value)} />
          <Select mode="multiple" maxTagCount={1} placeholder="Заказчик" value={customers} options={incomingOrganizations.map(value => ({ label: value, value }))} onChange={value => setCustomers(value)} popupClassName="skud-incoming-requests__customers-dropdown" />
          <Select allowClear placeholder="Наличие оборудования" value={equipment} options={incomingEquipmentOptions.map(value => ({ label: value, value }))} onChange={value => setEquipment(value)} />
          <Select className="skud-incoming-requests__sort" value={sort} options={incomingSortOptions.map(value => ({ label: value, value }))} onChange={value => setSort(value)} />
        </div>
        {(format || equipment || customers.length > 0) && <div className="skud-incoming-requests__chips" aria-label="Выбранные фильтры">
          {format && <Tag closable closeIcon={<CloseOutlined />} onClose={() => clearChip('format')}>{format}</Tag>}
          {customers.map(customer => <Tag key={customer} closable closeIcon={<CloseOutlined />} onClose={() => clearChip('customer', customer)}>{customer}</Tag>)}
          {equipment && <Tag closable closeIcon={<CloseOutlined />} onClose={() => clearChip('equipment')}>{equipment}</Tag>}
        </div>}
      </section>

      <div className="skud-incoming-requests__cards" aria-live="polite">
        {visibleRequests.map(request => <article className="skud-incoming-requests__card" key={request.key}>
          <div className="skud-incoming-requests__card-main">
            <div className="skud-incoming-requests__card-top">
              {request.badge && <Tag className={`skud-incoming-requests__badge skud-incoming-requests__badge--${request.hasResponded ? 'responded' : request.viewed ? 'viewed' : request.badge === '10 компаний уже откликнулось' ? 'many' : request.badge === 'Откликнитесь первым' ? 'first' : 'neutral'}`}>{request.badge}</Tag>}
              <time>{request.dateLabel}</time>
            </div>
            <h2>Установка и регистрация СКУД</h2>
            <div className="skud-incoming-requests__organization">{request.organization}<CheckCircleFilled aria-label="Проверенная организация" /></div>
            <div className="skud-incoming-requests__details"><span>ИНН: {request.inn}</span><span>{request.address}</span></div>
          </div>
          <div className="skud-incoming-requests__card-footer">
            <div className="skud-incoming-requests__attributes">
              <Tag icon={<ToolOutlined />}>{request.workFormat}</Tag>
              <Tag icon={<UserOutlined />}>Оборудование: {request.equipmentAvailable ? 'есть' : 'нет'}</Tag>
            </div>
            <Button type="primary" onClick={() => respond(request)}>{request.responseButton}</Button>
          </div>
        </article>)}
      </div>

      <Modal open={Boolean(confirmRequest)} footer={null} closable centered width={480} onCancel={() => setConfirmRequest(undefined)} className="skud-incoming-requests__confirm">
        <div className="skud-incoming-requests__confirm-title"><span aria-hidden="true">i</span><strong>Вы откликаетесь на заявку с дальнейшим ТО</strong></div>
        <p>Заявка включает монтаж и дальнейшее обслуживание СКУД. Продолжите, если такой формат работы вам подходит</p>
        <div className="skud-incoming-requests__confirm-actions"><Button onClick={() => setConfirmRequest(undefined)}>Отменить</Button><Button type="primary" onClick={confirmRespond}>Откликнуться</Button></div>
      </Modal>
    </div>
  );
}

export default IncomingRequests;
