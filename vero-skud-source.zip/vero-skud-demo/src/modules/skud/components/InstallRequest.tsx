import { RequestDocuments } from './RequestDocuments';
import { mergeRequestDocuments, signedRequestDocument, requestContractName, requestReadinessName, requestAcceptanceName } from '../data/requestDocuments';
import { useEffect, useLayoutEffect, useRef, useState } from 'react';
import { Alert, Button, Collapse, Dropdown, Empty, Form, Input, Modal, Select, Spin, Tag } from 'antd';
import { ArrowUpOutlined, CheckCircleFilled, CheckOutlined, CloseCircleFilled, DownOutlined, DownloadOutlined, EditOutlined, EllipsisOutlined, InfoCircleOutlined, LoadingOutlined, MinusOutlined, PaperClipOutlined, PlusOutlined, PushpinFilled, PushpinOutlined, SafetyCertificateFilled, UpOutlined } from '@ant-design/icons';
import { DocumentRow } from './DocumentUpload';
import type { LocalDocument } from './DocumentUpload';
import { AdditionalAgreement, AdditionalAgreementNotice, SharedContractPreview } from './AdditionalAgreement';
import type { AdditionalAgreementState } from '../data/additionalAgreement';
import { installAcceptancePreview, installContractCopy, installOfferCards, getInstallOfferDetail, getInstallOfferTables, installRework, installRequest as reference, installRequestEdit } from '../data/installRequest';
import type { InstallObject, InstallStage, InstallOfferCard } from '../data/installRequest';
import './RegistrationRequest.css';
import './InstallRequest.css';

export interface InstallRequestProps {
  requestId?: string;
  selectedOfferKey?: string;
  onOfferChange?: (key: string) => void;
  documents?: LocalDocument[];
  onDocumentSigned?: (document: LocalDocument) => void;
  initialStage?: InstallStage;
  object?: Partial<InstallObject>;
  onObjectChange?: (object: InstallObject) => void;
  onRegistration: () => void;
  onWithdraw: (stage: InstallStage) => void;
  onStageChange?: (stage: InstallStage) => void;
  onWallet: () => void;
  /** Fixed local signing outcome. It does not verify a signature or change a real balance. */
  signOutcome?: 'success' | 'error';
  /** The shown insufficient-funds fixture; never calculated from other displayed amounts. */
  insufficientFunds?: boolean;
  /** Optional opening state for the already shown signing overlays. */
  initialSignatureState?: 'preview' | 'loading' | 'error';
  /** Fixed local outcome; sending a comment does not simulate an executor's response. */
  reworkOutcome?: 'success' | 'error';
  /** Independently supplied result fixture. Version 2 is never created by sending a comment. */
  resultVersion?: 1 | 2;
  /** Captured states for visual verification of the separate rework-flow reference. */
  initialReworkState?: 'empty' | 'filled' | 'validation' | 'loading' | 'error';
  additionalState?: AdditionalAgreementState;
  onAdditionalStateChange?: (state: AdditionalAgreementState) => void;
  onTerminate?: () => void;
}
type Overlay = 'contract-prompt' | 'sign' | 'signing' | 'sign-error' | 'sign-success' | 'accept-confirm' | 'forming-act' | 'withdraw' | 'rework-comment' | 'rework-loading' | 'rework-error' | 'edit-conditions' | 'updating-data' | undefined;
type SignKind = 'contract' | 'readiness' | 'acceptance';
const document = (name: string): LocalDocument => ({name,size:12288});

export function InstallRequest({requestId,selectedOfferKey,onOfferChange,documents,onDocumentSigned,initialStage='offers',object,onObjectChange,onRegistration,onWithdraw,onStageChange,onWallet,signOutcome='success',insufficientFunds=false,initialSignatureState='preview',reworkOutcome='success',resultVersion=1,initialReworkState,additionalState,onAdditionalStateChange,onTerminate}: InstallRequestProps) {
  const [signedDocuments,setSignedDocuments] = useState<LocalDocument[]>(() => documents !== undefined ? [] : (['preparation','working','acceptance','accept-sign','rework'].includes(initialStage) ? [requestContractName, ...(['working','acceptance','accept-sign','rework'].includes(initialStage) ? [requestReadinessName] : [])] : []).map(signedRequestDocument));
  const initialSignedDocuments = useRef(signedDocuments);
  const reportedInitialDocuments = useRef(false);
  useEffect(() => {
    if (!onDocumentSigned || reportedInitialDocuments.current) return;
    reportedInitialDocuments.current = true;
    initialSignedDocuments.current.forEach(document => onDocumentSigned(document));
  }, [onDocumentSigned]);
  function recordSigned(name: string) {
    const document = signedRequestDocument(name);
    setSignedDocuments(current => mergeRequestDocuments(current,[document]));
    onDocumentSigned?.(document);
  }
  const [stage,setStage] = useState<InstallStage>(initialStage);
  const [overlay,setOverlay] = useState<Overlay>(() => {
    if(initialReworkState) return initialReworkState==='loading'?'rework-loading':initialReworkState==='error'?'rework-error':'rework-comment';
    if(initialStage!=='contract-sign'&&initialStage!=='accept-sign') return undefined;
    return initialSignatureState==='error'?'sign-error':initialSignatureState==='loading'?'signing':'sign';
  });
  const [signKind,setSignKind] = useState<SignKind>(initialStage==='accept-sign'?'acceptance':'contract');
  const [query,setQuery] = useState('');
  const [selectedOffer,setSelectedOffer] = useState(()=>installOfferCards.find(card=>card.key===selectedOfferKey)??installOfferCards[0]);
  function chooseOffer(card:InstallOfferCard) {setSelectedOffer(card);onOfferChange?.(card.key);}
  const [message,setMessage] = useState('');
  const [localMessages,setLocalMessages] = useState<string[]>([]);
  const [scale,setScale] = useState(1);
  const [editForm] = Form.useForm<Pick<InstallObject,'uin'|'name'|'address'>>();
  const [info,setInfo] = useState<InstallObject>(()=>({...reference.object,...object}));
  const [reworkComment,setReworkComment] = useState(initialReworkState==='filled'||initialReworkState==='error'||initialReworkState==='loading'?installRework.comment:'');
  const [reworkValidation,setReworkValidation] = useState(initialReworkState==='validation');
  const [reworkFixture] = useState(initialStage==='rework'||resultVersion===2||initialReworkState!==undefined);
  const [localAdditionalState,setLocalAdditionalState] = useState<AdditionalAgreementState>('idle');
  const agreementState = additionalState ?? localAdditionalState;
  function changeAdditionalState(next:AdditionalAgreementState) {setLocalAdditionalState(next);onAdditionalStateChange?.(next);}
  const timeout = useRef<ReturnType<typeof setTimeout>|undefined>(undefined);
  useEffect(()=>()=>clearTimeout(timeout.current),[]);
  useEffect(()=>{setInfo({...reference.object,...(reworkFixture?installRework.fixtureObject:{}),...object});},[object?.uin,object?.name,object?.address,object?.financing,object?.workFormat,object?.schemePreparedBy,reworkFixture]);
  const mounting = ['preparation','working','acceptance','accept-sign','rework'].includes(stage);
  const awaitingAcceptance = stage==='acceptance'||stage==='accept-sign';
  const currentStep = mounting?1:0;
  const status = stage==='rework'?installRework.status:stage==='preparation'?'Подготовка к монтажу':stage==='working'?'В работе':awaitingAcceptance?'Ожидает приёмки':'Получаем предложения';
  const list = stage==='offers'||stage==='empty-offers';
  const [offerSort,setOfferSort]=useState<'new'|'old'>('new');
  const [pinnedOffers,setPinnedOffers] = useState<string[]>([]);
  const offerNodes = useRef(new Map<string,HTMLElement>());
  const previousPositions = useRef(new Map<string,DOMRect>());
  function togglePin(key:string) {
    previousPositions.current = new Map([...offerNodes.current].map(([id,node])=>[id,node.getBoundingClientRect()]));
    setPinnedOffers(current=>current.includes(key)?current.filter(id=>id!==key):[key,...current]);
  }
  useLayoutEffect(()=>{
    if (!window.matchMedia('(prefers-reduced-motion: reduce)').matches) {
      offerNodes.current.forEach((node,id)=>{
        const before=previousPositions.current.get(id); if(!before) return;
        const after=node.getBoundingClientRect();
        const x=before.left-after.left, y=before.top-after.top;
        if(x||y) node.animate([{transform:`translate(${x}px, ${y}px)`},{transform:'translate(0, 0)'}],{duration:360,easing:'cubic-bezier(.22,1,.36,1)'});
      });
    }
    previousPositions.current.clear();
  },[pinnedOffers]);
  const cards = stage==='empty-offers'?[]:installOfferCards.filter(card=>card.name.toLocaleLowerCase('ru-RU').includes(query.trim().toLocaleLowerCase('ru-RU'))).sort((a,b)=>{
    const aIndex=pinnedOffers.indexOf(a.key),bIndex=pinnedOffers.indexOf(b.key);
    if(aIndex>=0||bIndex>=0)return (aIndex<0?Infinity:aIndex)-(bIndex<0?Infinity:bIndex);
    return (new Date(a.receivedAt).getTime()-new Date(b.receivedAt).getTime())*(offerSort==='old'?1:-1);
  });
  function changeStage(next:InstallStage) {setStage(next);onStageChange?.(next);}
  function later(action:()=>void) {clearTimeout(timeout.current);timeout.current=setTimeout(action,1000);}
  function openSign(kind:SignKind) {setSignKind(kind);setScale(1);if(kind==='contract')changeStage('contract-sign');setOverlay('sign');}
  function sign() {
    setOverlay('signing');
    // A local demo sequence, independent of uploaded file contents or financial calculations.
    later(()=>{
      if(signOutcome==='error') {setOverlay('sign-error');return;}
      recordSigned(signKind==='contract'?requestContractName:signKind==='readiness'?requestReadinessName:requestAcceptanceName);
      if(signKind==='acceptance') {setOverlay(undefined);onRegistration();return;}
      changeStage(signKind==='contract'?'preparation':'working');
      setOverlay('sign-success');
    });
  }
  function formAct() {setSignKind('acceptance');setOverlay('forming-act');later(()=>{changeStage('accept-sign');setScale(1);setOverlay('sign');});}
  function openRework() {setReworkComment('');setReworkValidation(false);setOverlay('rework-comment');}
  function sendRework() {
    if(!reworkComment.trim()) {setReworkValidation(true);setOverlay('rework-comment');return;}
    setReworkValidation(false);setOverlay('rework-loading');
    // Explicit local fixture outcome. No new result version or registration stage is inferred.
    later(()=>{if(reworkOutcome==='error'){setOverlay('rework-error');return;}changeStage('rework');setOverlay(undefined);});
  }
  function sendLocalMessage() {const text=message.trim();if(text){setLocalMessages(values=>[...values,text]);setMessage('');}}
  function openEditConditions() {editForm.setFieldsValue({uin:info.uin,name:info.name,address:info.address});setOverlay('edit-conditions');}
  function saveConditions() {void editForm.validateFields().then(values=>{setOverlay('updating-data');later(()=>{const next={...info,...values};setInfo(next);onObjectChange?.(next);setOverlay(undefined);});});}
  const contractDocument = document(reference.documents.contract);

  return <div className="skud-install skud-request">
    <section className="skud-request__summary">
      <div className="skud-request__heading"><div><div className="skud-request__title"><h1>{object?`${info.name} — установка и регистрация СКУД`:reference.title}</h1><Tag color={status==='Получаем предложения'||status==='В работе'||stage==='rework'?'processing':'warning'} variant="outlined">{status}</Tag></div><p>{requestId??reference.id}<span>Создана сегодня</span></p></div>
        <Dropdown trigger={['click']} menu={{items:mounting?[{key:'terminate',label:'Расторгнуть договор',disabled:!onTerminate}]:[{key:'withdraw',label:'Отозвать заявку'}],onClick:({key})=>{if(key==='withdraw')setOverlay('withdraw');if(key==='terminate')onTerminate?.();}}}><Button size="small" icon={<EllipsisOutlined/>} aria-label="Действия с заявкой"/></Dropdown>
      </div>
      <div className="skud-request__conditions"><h2>Условия заявки <Button className="skud-install__edit" type="link" icon={<EditOutlined/>} onClick={openEditConditions}>Изменить условия</Button></h2>
        <dl className="skud-install__conditions"><div><dt>УИН ОКС</dt><dd>{info.uin}</dd></div><div><dt>Источник финансирования</dt><dd>{info.financing}</dd></div><div><dt>Формат работы</dt><dd>{info.workFormat}</dd></div><div className="skud-install__address"><dt>Адрес ОКС</dt><dd>{info.address}</dd></div>{!reworkFixture&&<div><dt>Схема размещения СКУД</dt><dd>{info.schemePreparedBy}</dd></div>}</dl>
      </div>
    </section>
    <div className="skud-request__columns"><div className="skud-request__body">
      {list?<>
        <section className="skud-request__panel skud-install__offers-heading"><h2>Поступившие предложения <span>{stage==='empty-offers'?0:installOfferCards.length}</span></h2><p>{reference.receivedDescription}</p><div className="skud-install__search"><Input placeholder="Поиск по названию организации" aria-label="Поиск по названию организации" value={query} onChange={event=>setQuery(event.target.value)}/><Select aria-label="Сортировка предложений" value={offerSort} onChange={setOfferSort} options={[{value:'new',label:'Сначала новые'},{value:'old',label:'Сначала старые'}]}/></div></section>
        {stage==='empty-offers'?<section className="skud-install__empty"><Empty image={Empty.PRESENTED_IMAGE_SIMPLE} description="Пока никто не откликнулся"/></section>:<div className="skud-install__offers" aria-live="polite">{cards.map(card=><article ref={node=>{if(node)offerNodes.current.set(card.key,node);else offerNodes.current.delete(card.key);}} data-offer-id={card.key} className={`skud-install__offer-card ${pinnedOffers.includes(card.key)?'is-pinned':''}`} key={card.key}><div className="skud-install__offer-title"><h3>{card.name}<SafetyCertificateFilled/></h3><Button className="skud-install__pin" aria-label={pinnedOffers.includes(card.key)?'Открепить КП':'Закрепить КП'} title={pinnedOffers.includes(card.key)?'Открепить КП':'Закрепить КП'} aria-pressed={pinnedOffers.includes(card.key)} icon={pinnedOffers.includes(card.key)?<PushpinFilled/>:<PushpinOutlined/>} onClick={()=>togglePin(card.key)}/></div><p className="skud-install__inn">ИНН: {card.inn}</p><dl><div><dt>Срок монтажа</dt><dd>{card.deadline}</dd></div><div><dt>Оборудование</dt><dd>{card.equipment}</dd></div><div><dt>Стоимость монтажа</dt><dd>{card.installation}</dd></div><div><dt>Техническое обслуживание</dt><dd>{card.maintenance}</dd></div></dl><div className="skud-install__offer-actions"><Button onClick={()=>{chooseOffer(card);changeStage('offer');}}>Изучить КП</Button><Button type="primary" onClick={()=>{chooseOffer(card);setOverlay('contract-prompt');}}>Выбрать исполнителя</Button></div></article>)}</div>}
      </>:<>
        {mounting&&!reworkFixture&&<AdditionalAgreementNotice state={agreementState} onSign={()=>changeAdditionalState('sign')}/>}
        {stage==='preparation'&&<section className="skud-install__readiness"><Alert type="warning" showIcon title="Подпишите акт готовности к монтажу" description={<><p>{reference.readinessDescription}</p><div className="skud-install__readiness-document"><DocumentRow document={document(reference.documents.readiness)}/><Button type="primary" onClick={()=>openSign('readiness')}>Подписать</Button></div></>}/></section>}
        <section className="skud-request__panel skud-install__chat"><h2>Чат с исполнителем</h2><div className="skud-install__messages"><div className="skud-install__chat-date">{reference.chat.date}</div><div className="skud-install__message"><span><CheckOutlined/> {reference.chat.time}</span><div>{reference.chat.message}</div></div>{localMessages.map((text,index)=><div className="skud-install__message" key={index}><div>{text}</div></div>)}</div><div className="skud-install__chat-input"><PaperClipOutlined/><Input placeholder="Введите сообщение" aria-label="Введите сообщение" value={message} onChange={event=>setMessage(event.target.value)} onPressEnter={sendLocalMessage} suffix={<Button type="primary" shape="circle" size="small" icon={<ArrowUpOutlined/>} aria-label="Отправить сообщение" disabled={!message.trim()} onClick={sendLocalMessage}/>}/></div></section>
        {mounting&&stage!=='rework'&&<><section className="skud-request__panel skud-install__result"><h2>Результат работы</h2><p>{awaitingAcceptance?'Примите результат работы исполнителя':reference.resultEmpty}</p>{awaitingAcceptance&&<><div className="skud-install__version"><strong>{reference.resultVersion}{reworkFixture?'.':''}</strong><span>Отправлено {reference.resultSent}</span></div><DocumentRow document={document(reference.documents.composition)}/><DocumentRow document={document(reference.documents.scheme)}/>{resultVersion===2&&<><div className="skud-install__version"><strong>{installRework.revisedVersion}</strong><span>Отправлено {installRework.revisedSent}</span></div><DocumentRow document={document(installRework.revisedScheme)}/></>}<div className="skud-install__result-actions"><Button onClick={openRework}>Отправить на доработку</Button><Button type="primary" onClick={()=>setOverlay('accept-confirm')}>Принять работу</Button></div></>}</section>{!reworkFixture&&<AdditionalAgreement state={agreementState} onStateChange={changeAdditionalState} showNotice={false} signatureOutcome={signOutcome}/>}</>}
        {/* The sent-rework source clips at the chat footer; no unseen continuation is inferred. */}
        {stage!=='rework'&&<OfferSummary selectedOffer={selectedOffer} key={mounting?'mounting':'selection'} initialExpanded={!mounting}/>}
        {!mounting&&<section className="skud-request__panel skud-install__contract"><h2>Подпишите договор</h2><p>Ознакомьтесь с условиями и подпишите договор, чтобы выбрать исполнителя и передать заявку в работу</p><ContractDocument document={contractDocument}/><div className="skud-request__actions"><Button onClick={()=>changeStage('offers')}>Вернуться к выбору исполнителя</Button><Button type="primary" onClick={()=>openSign('contract')}>Подписать договор</Button></div></section>}
      </>}
    </div><aside className="skud-request__aside"><ol className="skud-request__steps">{reference.steps.map((label,index)=><li key={label} className={index<currentStep?'is-done':index===currentStep?'is-current':''}><span className="skud-request__step-number">{index<currentStep?<CheckOutlined/>:index+1}</span><div>{label}{index===currentStep&&<p>{status}</p>}</div></li>)}</ol><Collapse className="skud-request__documents" expandIconPlacement="end" items={[{key:'documents',label:'Документы по заявке',children:<RequestDocuments documents={documents} signedDocuments={signedDocuments}/>}]} /></aside></div>

    <Modal open={overlay==='contract-prompt'} title="Подпишите договор" centered width={820} onCancel={()=>setOverlay(undefined)} footer={<Button type="primary" onClick={()=>openSign('contract')}>Подписать договор</Button>}><p>Ознакомьтесь с условиями и подпишите договор, чтобы выбрать исполнителя и передать заявку в работу</p><ContractDocument document={contractDocument}/></Modal>
    <Modal className="skud-install__edit-modal" open={overlay==='edit-conditions'} title={installRequestEdit.title} width={1064} centered onCancel={()=>setOverlay(undefined)} okText={installRequestEdit.save} cancelText={installRequestEdit.cancel} onOk={saveConditions}><h3>{installRequestEdit.heading}</h3><Form form={editForm} layout="vertical"><div className="skud-install__edit-grid"><Form.Item name="uin" label={installRequestEdit.uin}><Input/></Form.Item><Form.Item name="name" label={installRequestEdit.name}><Input/></Form.Item><Form.Item className="skud-install__edit-address" name="address" label={installRequestEdit.address}><Input/></Form.Item></div></Form></Modal>
    <Modal open={overlay==='updating-data'} centered width={520} footer={null} closable={false}><div className="skud-request__loading"><Spin indicator={<LoadingOutlined spin/>}/><strong>{installRequestEdit.loading}</strong></div></Modal>
    <Modal open={overlay==='sign'} title="Подписать документ" centered width={820} onCancel={()=>{setOverlay(undefined);if(stage==='accept-sign')changeStage('acceptance');}} footer={<>{signKind==='contract'&&<><p className="skud-install__reservation">{installContractCopy.reservation.replace('753 120',getInstallOfferDetail(selectedOffer).oneOff.replace(',00',''))}</p>{insufficientFunds&&<Alert className="skud-install__funds" type="error" showIcon title={installContractCopy.insufficient}/>}</>}<Button onClick={()=>{setOverlay(undefined);if(stage==='accept-sign')changeStage('acceptance');}}>Отменить</Button><Button type="primary" onClick={signKind==='contract'&&insufficientFunds?onWallet:sign}>{signKind==='contract'&&insufficientFunds?'Пополнить и подписать':'Подписать'}</Button></>}>
      <div className="skud-install__viewer"><div className="skud-install__paper" style={{zoom:scale}}><ReferencePaper kind={signKind}/></div><div className="skud-install__viewer-controls"><Button shape="circle" size="small" icon={<PlusOutlined/>} aria-label="Увеличить документ" onClick={()=>setScale(value=>Math.min(2,value+.1))}/><Button shape="circle" size="small" icon={<MinusOutlined/>} aria-label="Уменьшить документ" onClick={()=>setScale(value=>Math.max(.5,value-.1))}/><Button shape="circle" size="small" aria-label="Масштаб документа 1:1" onClick={()=>setScale(1)}>1:1</Button></div></div>
    </Modal>
    <Modal open={overlay==='signing'||overlay==='forming-act'||overlay==='rework-loading'} centered width={520} footer={null} closable={false}><div className="skud-request__loading"><Spin indicator={<LoadingOutlined spin/>}/><strong>{overlay==='rework-loading'?installRework.loading:overlay==='forming-act'?'Формируем акт выполненных работ':'Подписание документов'}</strong></div></Modal>
    <Modal open={overlay==='sign-error'} centered width={448} onCancel={()=>setOverlay(undefined)} footer={<><Button onClick={()=>setOverlay('sign')}>Назад</Button><Button type="primary" onClick={sign}>Повторить</Button></>}><div className="skud-install__notice"><CloseCircleFilled className="is-error"/><div><strong>Не удалось подписать документ</strong><p>Повторите попытку или вернитесь назад</p></div></div></Modal>
    <Modal open={overlay==='sign-success'} centered width={448} onCancel={()=>setOverlay(undefined)} footer={<Button type="primary" onClick={()=>setOverlay(undefined)}>Хорошо</Button>}><div className="skud-install__notice"><CheckCircleFilled className="is-success"/><div><strong>Документ успешно подписан</strong><p>Электронная подпись добавлена</p></div></div></Modal>
    <Modal open={overlay==='accept-confirm'} title="Принять работу" centered width={520} onCancel={()=>setOverlay(undefined)} footer={<><Button onClick={()=>setOverlay(undefined)}>Отменить</Button><Button type="primary" onClick={formAct}>Принять работу</Button></>}>{reference.acceptanceDescription}</Modal>
    <Modal className="skud-install__rework-modal" open={overlay==='rework-comment'} title={installRework.title} centered width={520} onCancel={()=>setOverlay(undefined)} footer={<><Button onClick={()=>setOverlay(undefined)}>Отменить</Button><Button type="primary" onClick={sendRework}>Отправить</Button></>}>
      <p>{reworkComment||reworkValidation?installRework.description:installRework.emptyDescription}</p>
      <Input.TextArea aria-label={installRework.placeholder} aria-required aria-invalid={reworkValidation} aria-describedby={reworkValidation?'skud-install-rework-error':undefined} placeholder={installRework.placeholder} value={reworkComment} status={reworkValidation?'error':undefined} onChange={event=>{setReworkComment(event.target.value);setReworkValidation(false);}} rows={2}/>
      {reworkValidation&&<div id="skud-install-rework-error" className="skud-install__rework-validation" role="alert">{installRework.required}</div>}
    </Modal>
    <Modal open={overlay==='rework-error'} centered width={448} onCancel={()=>setOverlay(undefined)} footer={<><Button onClick={()=>setOverlay('rework-comment')}>Назад</Button><Button type="primary" onClick={sendRework}>Повторить</Button></>}><div className="skud-install__notice"><CloseCircleFilled className="is-error"/><div><strong>{installRework.errorTitle}</strong><p>{installRework.errorDescription}</p></div></div></Modal>
    <Modal open={overlay==='withdraw'} title="Отозвать заявку?" centered width={448} onCancel={()=>setOverlay(undefined)} okText="Отозвать" cancelText="Отменить" okButtonProps={{danger:true}} onOk={()=>{if(!mounting)onWithdraw(stage);}}>Заявка будет перемещена в Архив</Modal>
  </div>;
}

function ContractDocument({document: file}: {document:LocalDocument}) {
  return <div className="skud-install__contract-document"><DocumentRow document={file}/><Tag color="success" variant="outlined">Подписано исполнителем</Tag><InfoCircleOutlined/></div>;
}
function OfferSummary({initialExpanded,selectedOffer}:{initialExpanded:boolean;selectedOffer:InstallOfferCard}) {
  const offer=getInstallOfferDetail(selectedOffer);
  const installOfferTables=getInstallOfferTables(selectedOffer);
  const [expanded,setExpanded]=useState(initialExpanded);
  return <section className="skud-request__panel skud-install__commercial"><h2>Коммерческое предложение</h2><div className="skud-install__commercial-meta"><span>Исполнитель: <b>{offer.contractor}</b></span><span>Отправлено {offer.sent}<Button size="small" disabled icon={<DownloadOutlined/>} aria-label="Скачать коммерческое предложение"/></span></div><div className="skud-install__commercial-summary"><div><h3>Общая сводка</h3><dl><div><dt>Покупка оборудования</dt><dd>{offer.equipment}</dd></div><div><dt>Монтаж</dt><dd>{offer.installation}</dd></div><div><dt>ТО</dt><dd>{offer.maintenance}</dd></div></dl><dl className="skud-install__dates"><div><dt>Начало работ</dt><dd>{offer.start}</dd></div><div><dt>Окончание работ</dt><dd>{offer.end}</dd></div></dl></div><div><h3>Итого</h3><dl><div><dt>Разовые расходы</dt><dd>{offer.oneOff}</dd></div><div><dt>Регулярные расходы</dt><dd>{offer.recurring}</dd></div></dl><p>{offer.vat}</p></div></div>{expanded&&<div className="skud-install__tables">{installOfferTables.map(table=><section className="skud-install__table-section" key={table.title}><h3>{table.title}</h3><table className="skud-install__table"><thead><tr><th>{table.firstColumn}</th><th>Кол-во</th><th>Цена за шт., ₽</th><th>{table.totalColumn}</th></tr></thead><tbody>{table.rows.map(row=><tr key={row[0]}>{row.map((value,index)=><td key={index}>{value}</td>)}</tr>)}</tbody><tfoot><tr className="skud-install__table-total"><td colSpan={3}>Итого</td><td>{table.total}</td></tr><tr><td colSpan={3}>В том числе НДС</td><td>{table.vat}</td></tr></tfoot></table></section>)}</div>}<div className="skud-install__details"><Button type="text" onClick={()=>setExpanded(value=>!value)}>{expanded?'Скрыть подробную таблицу':'Показать подробную таблицу'} {expanded?<UpOutlined/>:<DownOutlined/>}</Button></div></section>;
}
function ReferencePaper({kind}:{kind:SignKind}) {
  if(kind==='readiness') return <><h2>{reference.documents.readiness.replace('.pdf','')}</h2></>;
  if(kind==='acceptance') return <><div className="skud-install__appendix">{installAcceptancePreview.appendix}</div><p className="skud-install__form-label">ФОРМА</p><h2>{installAcceptancePreview.title}<span className="skud-install__blank is-short"/></h2><h3 className="skud-install__act-subtitle">{installAcceptancePreview.subtitle}</h3><div className="skud-install__paper-place">г. Москва<span>«__» __________ 20__ г.</span></div><p>Подрядчик: <span className="skud-install__blank"/></p><p>Заказчик: <span className="skud-install__blank"/></p><h3>{installAcceptancePreview.sections[0]}</h3><h3>{installAcceptancePreview.sections[1]}</h3><table><thead><tr>{installAcceptancePreview.columns.map(column=><th key={column}>{column}</th>)}</tr></thead><tbody>{installAcceptancePreview.rows.map(row=><tr key={row[0]}>{installAcceptancePreview.columns.map((_,index)=><td key={index}>{row[index]??''}</td>)}</tr>)}</tbody></table></>;
  return <SharedContractPreview/>;
}

export default InstallRequest;
