import { MonitoringTermination } from './MonitoringTermination';
import type { MonitoringTerminationState } from './MonitoringTermination';
import { useMemo, useState } from 'react';
import { Alert, Button, Empty, Tabs, Tag } from 'antd';
import { ArrowDownOutlined, ArrowUpOutlined, ClockCircleOutlined, CloseCircleFilled } from '@ant-design/icons';
import {
  deviceStateLabels, monitoringCards, monitoringCopy, monitoringDemo, monitoringObjects,
} from '../data/monitoring';
import type { DeviceFilter, DeviceState, MonitoringObject, MonitoringRole, MonitoringUpdatedLabel } from '../data/monitoring';
import './Monitoring.css';

export interface MonitoringProps {
  termination?: MonitoringTerminationState;
  onTerminationChange?: (value: MonitoringTerminationState) => void;
  onRegistration?: () => void;
  role: MonitoringRole;
  objectId?: string;
  empty?: boolean;
  onOpenObject: (id: string) => void;
  /** Back navigation belongs to the shell breadcrumb; the reference has no content back button. */
  onBack: () => void;
  onRequests: () => void;
  /** Controlled search for integration; the reference monitoring list has no search field. */
  searchQuery?: string;
  /** The executor reference shows these three device subsets, without visible filter controls. */
  deviceFilter?: DeviceFilter;
  updatedLabel?: MonitoringUpdatedLabel;
}

function StatusTag({ state, children }: { state: DeviceState; children: React.ReactNode }) {
  return <Tag variant="outlined" className={`skud-monitor__status is-${state}`}>{children}</Tag>;
}

function Updated({ label }: { label: string }) {
  return <span className="skud-monitor__updated"><ClockCircleOutlined /><span>Статус обновлён: {label}</span></span>;
}

export function Monitoring({ role, objectId, empty = false, onOpenObject, onRequests, searchQuery = '', deviceFilter = 'all', updatedLabel, termination, onTerminationChange, onRegistration }: MonitoringProps) {
  const copy = monitoringCopy[role];
  const cards = useMemo(() => {
    const query = searchQuery.trim().toLocaleLowerCase('ru-RU');
    return monitoringCards[role].filter(card => card.name.toLocaleLowerCase('ru-RU').includes(query));
  }, [role, searchQuery]);

  if (objectId) {
    const object = monitoringObjects[objectId];
    // No detail frame exists for the other list cards; do not substitute another object.
    if (!object || (role === 'executor' && objectId !== 'kolomenskoye')) return null;
    return <ObjectMonitoring key={`${role}:${objectId}`} role={role} object={object} deviceFilter={deviceFilter} updatedLabel={updatedLabel} termination={termination} onTerminationChange={onTerminationChange} onRegistration={onRegistration} />;
  }

  return (
    <div className="skud-monitor skud-monitor--list">
      <h1>{copy.heading}</h1>
      <p className="skud-monitor__subtitle">{copy.subtitle}</p>
      {empty ? (
        <section className="skud-monitor__empty">
          <Empty image={Empty.PRESENTED_IMAGE_SIMPLE} description={false} />
          <h2>{copy.emptyHeading}</h2>
          <p>{copy.emptyLines[0]}<br />{copy.emptyLines[1]}</p>
          <Button type="primary" onClick={onRequests}>К заявкам</Button>
        </section>
      ) : (
        <div className="skud-monitor__cards" aria-live="polite">
          {cards.map(card => (
            <button type="button" className="skud-monitor__card" key={card.id} onClick={() => onOpenObject(card.id)} aria-label={`Открыть объект ${card.name}`}>
              <div className="skud-monitor__card-body">
                <h2>{card.name}</h2>
                <div className="skud-monitor__card-states">{card.states.map(status => <StatusTag key={status.state} state={status.state}>{deviceStateLabels[status.state]}: {status.count}</StatusTag>)}</div>
              </div>
              <div className="skud-monitor__card-footer"><Updated label={card.updated} /></div>
            </button>
          ))}
        </div>
      )}
    </div>
  );
}

function ObjectMonitoring({ role, object, deviceFilter, updatedLabel, termination, onTerminationChange, onRegistration }: {
  termination?: MonitoringTerminationState;
  onTerminationChange?: (value: MonitoringTerminationState) => void;
  onRegistration?: () => void;
  role: MonitoringRole;
  object: MonitoringObject;
  deviceFilter: DeviceFilter;
  updatedLabel?: MonitoringUpdatedLabel;
}) {
  const [terminationOpen,setTerminationOpen]=useState(false);
  const terminated=termination?.status==='terminated';
  const pending=termination?.status==='pending';
  const [tab, setTab] = useState(object.initialTab);
  const devices = object.devices.filter(device => role !== 'executor' || deviceFilter === 'all' || device.state === deviceFilter);

  return (
    <div className="skud-monitor skud-monitor--object">
      <section className="skud-monitor__object-summary">
        <div className="skud-monitor__object-heading">
          <div className="skud-monitor__object-title-row"><h1>{object.name}</h1><Updated label={object.statusState === 'working' ? updatedLabel ?? object.updated : object.updated} /></div>
          <p>{object.address}</p>
        </div>
        <div className="skud-monitor__object-fields">
          <dl>
            <div><dt>ID заявки</dt><dd>{object.requestId}</dd></div>
            <div><dt>Подрядчик</dt><dd>{terminated?'—':object.contractor}</dd></div>
            <div><dt>ТО</dt><dd>{terminated?'—':object.maintenance}</dd></div>
          </dl>
          <dl>
            <div><dt>Устройства</dt><dd>{object.deviceCount}</dd></div>
            <div><dt>Передают данные</dt><dd>{object.transmitting}</dd></div>
            <div><dt>На объекте</dt><dd><StatusTag state={object.statusState}>{object.status}</StatusTag></dd></div>
          </dl>
        </div>
        {role==='customer'&&!pending&&!terminated&&object.contractor!=='—'&&<div className="skud-monitor__contract-actions"><Button danger onClick={()=>setTerminationOpen(true)}>Расторгнуть договор</Button></div>}
      </section>
      {pending&&<Alert className="skud-monitor__termination-status" type="info" showIcon title={role==='customer'?'Подрядчик получил уведомление о расторжении':'Получено соглашение о расторжении договора'} description={<><p>{role==='customer'?'Соглашение подписано с вашей стороны и направлено подрядчику. Ожидайте его подписи. До завершения расторжения сведения о подрядчике и ТО сохраняются.':'Заказчик подписал дополнительное соглашение. Проверьте причину и подпишите его, чтобы завершить расторжение.'}</p><p>Причина: {termination.reason}</p>{termination.comment&&<p>Комментарий: {termination.comment}</p>}{role==='executor'&&<Button onClick={()=>onTerminationChange?.({...termination,status:'terminated'})} type="primary">Подписать соглашение о расторжении</Button>}</>}/>}
      {terminated&&<Alert className="skud-monitor__termination-status" type="success" showIcon title="Договор расторгнут" description={<>Дополнительное соглашение подписано обеими сторонами. Подрядчик больше не закреплён за объектом, техническое обслуживание завершено.{role==='customer'&&termination.reason==='Не устроил интегратор'&&<div><Button type="link" onClick={onRegistration}>Создать заявку на подключение и регистрацию СКУД</Button></div>}</>}/>}
      {terminationOpen&&<MonitoringTermination open onClose={()=>setTerminationOpen(false)} object={object} onRegistration={()=>{setTerminationOpen(false);onRegistration?.();}} onSend={value=>{onTerminationChange?.(value);setTerminationOpen(false);}}/>}
      <section className="skud-monitor__object-content">
        <Tabs className="skud-monitor__tabs" activeKey={tab} onChange={key => setTab(key as 'devices' | 'analytics')} items={[
          { key: 'devices', label: 'Мониторинг устройств' },
          // The demo is shown only for the healthy customer example. Do not combine it
          // with the error summary or invent executor analytics.
          { key: 'analytics', label: monitoringCopy[role].analyticsTab, disabled: role === 'executor' || !!object.alert },
        ]} />
        {tab === 'analytics' && role === 'customer' ? <DemoAnalytics /> : (
          <>
            {object.alert && <Alert className="skud-monitor__alert" type="error" showIcon icon={<CloseCircleFilled />} title={object.alert.heading} description={object.alert.description} />}
            <section className="skud-monitor__devices">
              <h2>Состояния устройств</h2>
              {devices.map(device => (
                <div className="skud-monitor__device" key={device.id}>
                  <div><h3>{device.id}</h3><p>{device.location}</p></div>
                  <StatusTag state={device.state}>{deviceStateLabels[device.state]}</StatusTag>
                </div>
              ))}
            </section>
          </>
        )}
      </section>
    </div>
  );
}

function DemoAnalytics() {
  return (
    <div className="skud-monitor__analytics">
      <div className="skud-monitor__analytics-title"><h2>{monitoringDemo.heading}</h2><Tag>Демо-данные</Tag></div>
      <div className="skud-monitor__period"><strong>{monitoringDemo.period}</strong><span>{monitoringDemo.today}</span></div>
      <div className="skud-monitor__analytics-stats">
        {monitoringDemo.statistics.map(statistic => (
          <div className="skud-monitor__analytics-stat" key={statistic.label}>
            <p>{statistic.label}</p>
            <div><strong>{statistic.value}</strong><span className={`is-${statistic.direction}`}>{statistic.direction === 'up' ? <ArrowUpOutlined /> : <ArrowDownOutlined />}{statistic.change}</span></div>
          </div>
        ))}
      </div>
      <div className="skud-monitor__legend"><span><i className="is-face" />По Face ID</span><span><i className="is-unauthorized" />Несанкционированные</span></div>
      <svg className="skud-monitor__chart" viewBox="0 0 1016 504" role="img" aria-label="Демонстрационный график проходов за восемь дней: по Face ID и несанкционированные">
        {monitoringDemo.axis.map((label, index) => {
          const y = 16 + index * 58;
          return <g key={label}><line x1="48" y1={y} x2="1016" y2={y} stroke="#f0f0f0" /><text x="33" y={y + 4} textAnchor="end">{label}</text><line x1="42" y1={y} x2="46" y2={y} stroke="#bfbfbf" /></g>;
        })}
        {monitoringDemo.chart.map((bar, index) => {
          const x = 78 + index * 121;
          const tealHeight = bar.unauthorized / 400 * 464;
          const totalHeight = (bar.face + bar.unauthorized) / 400 * 464;
          return <g key={bar.date}><title>{bar.date}: по Face ID — {bar.face}, несанкционированные — {bar.unauthorized}</title><rect x={x} y={480-totalHeight} width="58" height={totalHeight} fill="#3b82f6" /><rect x={x} y={480 - tealHeight} width="58" height={tealHeight} fill="#56c4c6" /><text x={x + 29} y="503" textAnchor="middle">{bar.date}</text></g>;
        })}
      </svg>
    </div>
  );
}

export default Monitoring;
