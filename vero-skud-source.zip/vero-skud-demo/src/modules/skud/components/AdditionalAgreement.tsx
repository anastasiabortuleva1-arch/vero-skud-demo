import { useEffect, useRef, useState, type ReactNode } from 'react';
import { Alert, Button, Checkbox, Input, Modal, Spin } from 'antd';
import { CheckCircleFilled, CloseCircleFilled, DownloadOutlined, DownOutlined, MinusOutlined, PlusOutlined, UpOutlined } from '@ant-design/icons';
import { DocumentRow, type LocalDocument } from './DocumentUpload';
import { additionalAgreement as copy, additionalAgreementSummary as summary, sharedContractPreview as contract, type AdditionalAgreementDraft, type AdditionalAgreementState } from '../data/additionalAgreement';
import './RegistrationRequest.css';
import './InstallRequest.css';
import './AdditionalAgreement.css';

export interface AdditionalAgreementProps {
  initialState?: AdditionalAgreementState;
  state?: AdditionalAgreementState;
  onStateChange?: (state: AdditionalAgreementState) => void;
  onRequest?: (draft: AdditionalAgreementDraft) => void;
  onSign?: () => void;
  signatureOutcome?: 'success' | 'error';
  showNotice?: boolean;
  /** Slot for reference-backed details; the supplied screenshots show only the collapsed view. */
  details?: ReactNode;
  document?: LocalDocument;
}
const signatureStates: AdditionalAgreementState[] = ['sign', 'signing', 'sign-error', 'signed'];
const defaultDocument: LocalDocument = {name: copy.document, size: 12 * 1024};
const defaultDraft: AdditionalAgreementDraft = {installation: false, equipment: true, comment: ''};

export function AdditionalAgreement({ initialState = 'idle', state: controlledState, onStateChange, onRequest, onSign, signatureOutcome = 'success', showNotice = true, details, document = defaultDocument }: AdditionalAgreementProps) {
  const [localState, setLocalState] = useState(initialState);
  const state = controlledState ?? localState;
  const [draft, setDraft] = useState<AdditionalAgreementDraft>(() => ({...defaultDraft, equipment: (controlledState ?? initialState) === 'form-equipment' || (controlledState ?? initialState) === 'pending'}));
  const [pendingVisible, setPendingVisible] = useState(true);
  const [scale, setScale] = useState(1);
  const timeout = useRef<ReturnType<typeof setTimeout> | undefined>(undefined);
  useEffect(() => { setLocalState(initialState); }, [initialState]);
  useEffect(() => {
    if (state !== 'signing') clearTimeout(timeout.current);
    if (state === 'form-equipment') setDraft(values => ({...values, equipment: true}));
    if (state === 'form') setDraft(values => ({...values, installation: false, equipment: false}));
    setPendingVisible(true);
  }, [state]);
  useEffect(() => () => clearTimeout(timeout.current), []);
  function changeState(next: AdditionalAgreementState) { setLocalState(next); onStateChange?.(next); }
  function sign() {
    onSign?.(); changeState('signing'); clearTimeout(timeout.current);
    timeout.current = setTimeout(() => changeState(signatureOutcome === 'success' ? 'signed' : 'sign-error'), 700);
  }
  function complete() { changeState('confirmed'); }
  const proposalVisible = state === 'proposal' || signatureStates.includes(state);
  const formVisible = state === 'form' || state === 'form-equipment';
  return <>
    {showNotice && proposalVisible && <AdditionalAgreementNotice state={state} document={document} onSign={() => {setScale(1); changeState('sign');}}/>}
    <section className="skud-request__panel skud-agreement"><h2>{copy.title}</h2><p>{copy.description}</p>
      {state === 'pending' && pendingVisible && <Alert className="skud-agreement__pending" type="info" showIcon closable title={copy.pendingTitle} onClose={() => setPendingVisible(false)} description={<><p>{copy.pendingDescription}</p><strong>{copy.changes}</strong><div>{draft.installation && <div>{copy.installation}</div>}{draft.equipment && <div>{copy.equipment}</div>}</div></>}/>}
      <div className="skud-request__actions"><Button onClick={() => changeState('form')}>{copy.action}</Button></div>
    </section>
    {state === 'confirmed' && <AdditionalAgreementSummary details={details} document={document}/>}
    <Modal open={formVisible} title={copy.formTitle} centered width={720} onCancel={() => changeState('idle')} footer={<><Button onClick={() => changeState('idle')}>Отменить</Button><Button type="primary" onClick={() => {onRequest?.({...draft}); changeState('pending');}}>Далее</Button></>}>
      <div className="skud-agreement__form"><p>{copy.formDescription}</p><div className="skud-agreement__choices"><Checkbox checked={draft.installation} onChange={event => setDraft(values => ({...values, installation: event.target.checked}))}>{copy.installation}</Checkbox><Checkbox checked={draft.equipment} onChange={event => setDraft(values => ({...values, equipment: event.target.checked}))}>{copy.equipment}</Checkbox></div><label htmlFor="additional-agreement-comment">{copy.comment} <span>{copy.optional}</span></label><Input.TextArea id="additional-agreement-comment" rows={2} placeholder={copy.commentPlaceholder} value={draft.comment} onChange={event => setDraft(values => ({...values, comment: event.target.value}))}/></div>
    </Modal>
    <Modal open={state === 'sign'} title="Подписать документ" centered width={820} onCancel={() => changeState('proposal')} footer={<><p className="skud-install__reservation">{copy.reservation}</p><Button onClick={() => changeState('proposal')}>Отменить</Button><Button type="primary" onClick={sign}>Подписать</Button></>}>
      <div className="skud-install__viewer skud-agreement__viewer"><div className="skud-install__paper" style={{zoom:scale}}><SharedContractPreview/></div><div className="skud-install__viewer-controls"><Button shape="circle" size="small" icon={<PlusOutlined/>} aria-label="Увеличить документ" onClick={() => setScale(value => Math.min(2, value + .1))}/><Button shape="circle" size="small" icon={<MinusOutlined/>} aria-label="Уменьшить документ" onClick={() => setScale(value => Math.max(.5, value - .1))}/><Button shape="circle" size="small" icon={<DownloadOutlined/>} aria-label="Скачать документ" disabled={!document.file} onClick={() => {if (!document.file) return; const url = URL.createObjectURL(document.file); const link = window.document.createElement('a'); link.href = url; link.download = document.name; link.click(); setTimeout(() => URL.revokeObjectURL(url), 1000);}}/></div></div>
    </Modal>
    <Modal open={state === 'signing'} centered width={520} footer={null} closable={false} mask={{closable:false}}><div className="skud-request__loading"><Spin/><strong>Подписание документов</strong></div></Modal>
    <Modal open={state === 'sign-error'} centered width={448} onCancel={() => changeState('proposal')} footer={<><Button onClick={() => changeState('sign')}>Назад</Button><Button type="primary" onClick={sign}>Повторить</Button></>}><div className="skud-install__notice"><CloseCircleFilled className="is-error"/><div><strong>{copy.errorTitle}</strong><p>{copy.errorDescription}</p></div></div></Modal>
    <Modal open={state === 'signed'} centered width={448} onCancel={complete} footer={<Button type="primary" onClick={complete}>Хорошо</Button>}><div className="skud-install__notice"><CheckCircleFilled className="is-success"/><div><strong>{copy.signedTitle}</strong><p>{copy.signedDescription}</p></div></div></Modal>
  </>;
}
export function AdditionalAgreementNotice({state = 'proposal', onSign, document = defaultDocument}: {state?: AdditionalAgreementState; onSign: () => void; document?: LocalDocument}) {
  if (state !== 'proposal' && !signatureStates.includes(state)) return null;
  return <Alert className="skud-agreement__proposal" type="warning" showIcon title={copy.proposalTitle} description={<><p>{copy.proposalDescription}</p><div className="skud-agreement__changes"><strong>{copy.changes}</strong><div>Дополнительный монтаж — {copy.proposal.installation}</div><div>Оборудование — {copy.proposal.equipment}</div><div>Итого — {copy.proposal.total}</div><div>Новый срок исполнения: до {copy.proposal.deadline}</div></div><div className="skud-agreement__document"><DocumentRow document={document}/><Button onClick={onSign}>Подписать</Button></div></>}/>;
}
export function AdditionalAgreementSummary({details, document = defaultDocument}: {details?: ReactNode; document?: LocalDocument}) {
  const [expanded, setExpanded] = useState(false);
  function download() {if (!document.file) return; const url = URL.createObjectURL(document.file); const link = window.document.createElement('a'); link.href = url; link.download = document.name; link.click(); setTimeout(() => URL.revokeObjectURL(url), 1000);}
  return <section className="skud-request__panel skud-install__commercial skud-agreement-summary"><h2>{copy.title}</h2><div className="skud-install__commercial-meta"><span>Исполнитель: {summary.contractor}</span><span>Отправлено {summary.sent}<Button size="small" disabled={!document.file} onClick={download} icon={<DownloadOutlined/>} aria-label="Скачать дополнительное соглашение"/></span></div><div className="skud-install__commercial-summary"><div><h3>Общая сводка</h3><dl><div><dt>Покупка оборудования</dt><dd>{summary.equipment}</dd></div><div><dt>Монтаж</dt><dd>{summary.installation}</dd></div><div><dt>ТО</dt><dd>{summary.maintenance}</dd></div></dl><dl className="skud-install__dates"><div><dt>Начало работ</dt><dd>{summary.start}</dd></div><div><dt>Окончание работ</dt><dd>{summary.end}</dd></div></dl></div><div><h3>Итого</h3><dl><div><dt>Разовые расходы</dt><dd>{summary.oneOff}</dd></div><div><dt>Регулярные расходы</dt><dd>{summary.recurring}</dd></div></dl><p>{summary.vat}</p></div></div>{expanded && details}<div className="skud-install__details"><Button type="text" disabled={!details} onClick={() => setExpanded(value => !value)}>{expanded ? 'Скрыть подробную таблицу' : 'Показать подробную таблицу'} {expanded ? <UpOutlined/> : <DownOutlined/>}</Button></div></section>;
}
export function SharedContractPreview() {
  return <><h2>{contract.title}</h2><h3 className="skud-install__contract-subtitle">{contract.subtitle}</h3><div className="skud-install__paper-place">г. Москва<span>«__» __________ 20__ г.</span></div><p>________________________________________, именуемое в дальнейшем «Подрядчик», в лице ________________________________________, действующего на основании ________________________________________, с одной стороны, и ________________________________________, именуемое в дальнейшем «Заказчик», в лице ________________________________________, действующего на основании ________________________________________, с другой стороны, совместно именуемые «Стороны», заключили настоящий Договор о нижеследующем:</p><p>{contract.introduction}</p><p>{contract.platformAgreement}</p><h3 className="skud-agreement__paper-heading">ТЕРМИНЫ И ОПРЕДЕЛЕНИЯ</h3><p className="skud-agreement__paper-term"><b>Платформа</b> — {contract.platform}</p><p><b>Оператор Платформы</b> — {contract.operator}</p></>;
}
export default AdditionalAgreement;
