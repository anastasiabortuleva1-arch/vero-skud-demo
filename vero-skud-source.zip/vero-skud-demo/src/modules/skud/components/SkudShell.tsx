import type { ReactNode } from 'react';
import { Segmented } from 'antd';
import {
  BellOutlined, BuildFilled, DownOutlined, SolutionOutlined,
  HomeOutlined, RightOutlined, TruckOutlined, UpOutlined, UserOutlined,
} from '@ant-design/icons';
import './SkudShell.css';

export interface SkudShellProps {
  children: ReactNode;
  active: 'requests' | 'incoming' | 'responses' | 'monitoring';
  role: 'customer' | 'executor';
  breadcrumb: ReactNode;
  onNavigate: (path: string) => void;
  logoSrc?: string;
  onRoleChange: (role: 'customer' | 'executor') => void;
  footer?: ReactNode;
}

export function SkudShell({ children, active, role, breadcrumb, onNavigate, onRoleChange, footer, logoSrc = '/assets/vero-logo.svg' }: SkudShellProps) {
  const menuItems = role === 'executor'
    ? [
      { key: 'incoming', title: 'Входящие заявки', path: '/skud/incoming' },
      { key: 'responses', title: 'Мои отклики', path: '/skud/responses' },
      { key: 'monitoring', title: 'Мониторинг', path: '/skud/monitoring' },
    ] as const
    : [
      { key: 'requests', title: 'Мои заявки', path: '/skud/requests' },
      { key: 'monitoring', title: 'Мониторинг', path: '/skud/monitoring' },
    ] as const;
  const roleSuffix = role === 'executor' ? '?role=executor' : '';

  return (
    <div className="skud-shell" data-role={role}>
      <aside className="skud-shell__sidebar" aria-label="Основная навигация">
        <div className="skud-shell__brand">
          <img src={logoSrc} alt="ВЕРО" width={180} height={56} />
        </div>
        <nav className="skud-shell__nav">
          <div className="skud-shell__nav-row"><HomeOutlined /><span>Главная</span></div>
          <div className="skud-shell__nav-row"><BuildFilled /><span>3D модель АГР</span><UpOutlined className="skud-shell__chevron" /></div>
          <div className="skud-shell__other-requests">Мои заявки</div>
          <div className="skud-shell__nav-row skud-shell__section"><SolutionOutlined /><span>СКУД</span><UpOutlined className="skud-shell__chevron" /></div>
          {menuItems.map(item => <button
            key={item.key}
            type="button"
            className={`skud-shell__child ${active === item.key ? 'is-active' : ''}`}
            aria-current={active === item.key ? 'page' : undefined}
            onClick={() => onNavigate(`${item.path}${roleSuffix}`)}
          >{item.title}</button>)}
          <div className="skud-shell__nav-row skud-shell__materials"><TruckOutlined /><span title="Поставка нерудных материалов">Поставка нерудных материалов</span>{role === 'executor' ? <UpOutlined className="skud-shell__chevron" /> : <DownOutlined className="skud-shell__chevron" />}</div>
          {role === 'executor' && <div className="skud-shell__materials-children"><div>Мои заявки</div><div>Рейсы</div><div>Мои документы</div></div>}
        </nav>
        <div className="skud-shell__profile"><UserOutlined /><span>Профиль</span><RightOutlined className="skud-shell__chevron" /></div>
      </aside>
      <div className="skud-shell__main">
        <header className="skud-shell__header">
          <div className="skud-shell__breadcrumb">{breadcrumb}</div>
          <Segmented className="skud-shell__role" aria-label="Роль пользователя" value={role} options={[{label: 'Заказчик', value: 'customer'}, {label: 'Исполнитель', value: 'executor'}]} onChange={onRoleChange} />
          <BellOutlined className="skud-shell__bell" aria-label="Уведомления" />
        </header>
        <main className="skud-shell__content">{children}</main>
        {footer}
      </div>
    </div>
  );
}

export default SkudShell;
