import { Empty } from 'antd';
import { DocumentRow, type LocalDocument } from './DocumentUpload';
import { mergeRequestDocuments } from '../data/requestDocuments';

export function RequestDocuments({ documents = [], localDocuments = [], signedDocuments = [] }: {
  documents?: LocalDocument[];
  localDocuments?: Array<LocalDocument | undefined>;
  signedDocuments?: LocalDocument[];
}) {
  const allDocuments = mergeRequestDocuments(documents, localDocuments, signedDocuments);
  return allDocuments.length ? <>{allDocuments.map(document => <DocumentRow key={document.name.trim().toLocaleLowerCase('ru-RU')} document={document}/>)}</> : <Empty image={Empty.PRESENTED_IMAGE_SIMPLE} description="Документы пока не добавлены"/>;
}
