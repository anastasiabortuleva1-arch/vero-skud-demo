import { TableTemplate } from './TableTemplate';
import { useEffect, useMemo, useRef, useState } from 'react';
import { Button, Input, Modal, Select, Skeleton, Spin } from 'antd';
import { CheckCircleFilled, CloseCircleFilled, ExclamationCircleFilled, SearchOutlined } from '@ant-design/icons';
import { DocumentUpload } from './DocumentUpload';
import type { LocalDocument } from './DocumentUpload';
import {
  registrationFormErrors,
  registrationFormInitialData,
  registrationFundingOptions,
  registrationUploadLabels,
} from '../data/registrationForm';
import type { RegistrationFormData, RegistrationFormState } from '../data/registrationForm';
import { demoDocument } from '../data/demoDocuments';
import './RegistrationForm.css';

export interface RegistrationFormProps {
  demoFillToken?: number;
  initialState?: RegistrationFormState;
  initialData?: RegistrationFormData;
  draftOutcome?: 'error';
  onBack: () => void;
  onDraft: (data: RegistrationFormData) => void;
  onPublish: (data: RegistrationFormData) => void;
}

const uploadedExample: Pick<RegistrationFormData, 'placementPlan' | 'technicalDevices'> = {
  placementPlan: { name: 'Схема.pdf', size: 12 * 1024 },
  technicalDevices: { name: 'Схема.xlsx', size: 12 * 1024 },
};

function cloneInitialData(): RegistrationFormData {
  return { uin: '', objectName: '', address: '', fundingSource: '' };
}

export function RegistrationForm({ demoFillToken = 0, initialState = 'empty', initialData, draftOutcome, onBack, onDraft, onPublish }: RegistrationFormProps) {
  const effectiveInitialState: RegistrationFormState = initialData && initialState === 'empty' ? 'filled' : initialState;
  const seededData = effectiveInitialState === 'filled' || effectiveInitialState === 'uploaded' || effectiveInitialState === 'loading';
  const [data, setData] = useState<RegistrationFormData>(() => {
    if (initialData) return { ...initialData };
    if (effectiveInitialState === 'not-found') return { ...cloneInitialData(), uin: registrationFormInitialData.uin };
    if (seededData) return { ...registrationFormInitialData, ...(effectiveInitialState === 'uploaded' ? uploadedExample : {}) };
    return cloneInitialData();
  });
  const [formState, setFormState] = useState<RegistrationFormState>(effectiveInitialState);
  const [lookupFailed, setLookupFailed] = useState(effectiveInitialState === 'not-found');
  const [publishing, setPublishing] = useState(false);
  const [exitConfirm, setExitConfirm] = useState(false);
  const [draftStage, setDraftStage] = useState<'idle' | 'saving' | 'saved' | 'error'>('idle');
  const publishTimer = useRef<number | undefined>(undefined);
  const draftTimer = useRef<number | undefined>(undefined);
  const initialSnapshot = useRef<string | undefined>(undefined);
  if (initialSnapshot.current === undefined) initialSnapshot.current = JSON.stringify(data);

  useEffect(() => {
    if (demoFillToken <= 0) return;
    setData({
      ...registrationFormInitialData,
      placementPlan: demoDocument(uploadedExample.placementPlan!.name, 'pdf'),
      technicalDevices: demoDocument(uploadedExample.technicalDevices!.name, 'xlsx'),
    });
    setLookupFailed(false);
    setFormState('uploaded');
  }, [demoFillToken]);

  useEffect(() => () => {
    if (publishTimer.current !== undefined) window.clearTimeout(publishTimer.current);
    if (draftTimer.current !== undefined) window.clearTimeout(draftTimer.current);
  }, []);

  useEffect(() => {
    if (formState !== 'loading') return;
    const timer = window.setTimeout(() => {
      const found = data.uin.trim().toLocaleUpperCase('en-US') === registrationFormInitialData.uin;
      setFormState(found ? 'filled' : 'not-found');
      setLookupFailed(!found);
      if (found) setData(current => ({ ...current, ...registrationFormInitialData }));
    }, 650);
    return () => window.clearTimeout(timer);
  }, [formState, data.uin]);

  const errors = useMemo(() => lookupFailed ? registrationFormErrors : undefined, [lookupFailed]);
  const update = (patch: Partial<RegistrationFormData>) => {
    const updated = { ...data, ...patch };
    setData(updated);
    if (formState === 'not-found' && updated.objectName.trim() && updated.address.trim() && updated.fundingSource) setFormState('filled');
  };
  const setDocument = (key: 'placementPlan' | 'technicalDevices', document?: LocalDocument) => update({ [key]: document });

  function findObject() {
    setLookupFailed(false);
    setFormState('loading');
  }

  function publish() {
    setPublishing(true);
    publishTimer.current = window.setTimeout(() => {
      publishTimer.current = undefined;
      setPublishing(false);
      onPublish({ ...data });
    }, 900);
  }

  function back() {
    if (publishTimer.current !== undefined) {
      window.clearTimeout(publishTimer.current);
      publishTimer.current = undefined;
    }
    setPublishing(false);
    if (JSON.stringify(data) !== initialSnapshot.current) setExitConfirm(true);
    else onBack();
  }

  function saveDraft() {
    setDraftStage('saving');
    draftTimer.current = window.setTimeout(() => {
      draftTimer.current = undefined;
      if (draftOutcome === 'error') {
        setDraftStage('error');
        return;
      }
      onDraft({ ...data });
      initialSnapshot.current = JSON.stringify(data);
      setDraftStage('saved');
    }, 650);
  }

  const placementPlan = data.placementPlan;
  const technicalDevices = data.technicalDevices;
  const showObjectFields = formState === 'filled' || formState === 'not-found' || formState === 'uploaded';
  const showDraftButton = formState === 'filled' || formState === 'uploaded';

  return (
    <div className="skud-registration">
      <h1>Новая заявка на регистрацию СКУД в реестре</h1>
      <p className="skud-registration__subtitle">Заполните параметры заявки</p>

      <section className="skud-registration__card skud-registration__object" aria-label="Данные объекта">
        <div className="skud-registration__lookup">
          <label htmlFor="registration-uin">УИН объекта капитального строительства</label>
          <div className="skud-registration__lookup-row">
            <Input id="registration-uin" value={data.uin} placeholder="HH8212-08-0001-001" onChange={event => update({ uin: event.target.value })} />
            <Button icon={<SearchOutlined />} onClick={findObject}>Найти объект</Button>
          </div>
          <div className="skud-registration__help">По УИН автоматически заполним название и адрес объекта</div>
        </div>

        {formState === 'loading' ? (
          <div className="skud-registration__fields" aria-label="Загрузка данных объекта">
            <div className="skud-registration__field"><label>Наименование объекта</label><Skeleton.Input active block /></div>
            <div className="skud-registration__field"><label>Адрес объекта</label><Skeleton.Input active block /></div>
            <div className="skud-registration__field skud-registration__field--funding"><label>Источник финансирования</label><Skeleton.Input active block /></div>
          </div>
        ) : showObjectFields ? (
          <div className="skud-registration__fields">
            <div className="skud-registration__field">
              <label htmlFor="registration-object-name">Наименование объекта</label>
              <Input id="registration-object-name" status={errors && !data.objectName ? 'error' : undefined} value={data.objectName} onChange={event => update({ objectName: event.target.value })} />
              {errors && !data.objectName && <span className="skud-registration__error">{errors.objectName}</span>}
            </div>
            <div className="skud-registration__field">
              <label htmlFor="registration-address">Адрес объекта</label>
              <Input id="registration-address" status={errors && !data.address ? 'error' : undefined} value={data.address} onChange={event => update({ address: event.target.value })} />
              {errors && !data.address && <span className="skud-registration__error">{errors.address}</span>}
            </div>
            <div className="skud-registration__field skud-registration__field--funding">
              <label htmlFor="registration-funding">Источник финансирования</label>
              <Select id="registration-funding" status={errors && !data.fundingSource ? 'error' : undefined} value={data.fundingSource || undefined} placeholder="Выберите" options={registrationFundingOptions.map(value => ({ value, label: value }))} onChange={value => update({ fundingSource: value })} />
              {errors && !data.fundingSource && <span className="skud-registration__error">{errors.fundingSource}</span>}
            </div>
          </div>
        ) : null}
      </section>

      <section className="skud-registration__card">
        <h2>{registrationUploadLabels.placementPlan.title}</h2>
        <p>{registrationUploadLabels.placementPlan.description}</p>
        <DocumentUpload value={placementPlan} accept={registrationUploadLabels.placementPlan.accept} onChange={value => setDocument('placementPlan', value)} />
      </section>

      <section className="skud-registration__card">
        <h2>{registrationUploadLabels.technicalDevices.title}</h2>
        <p>{registrationUploadLabels.technicalDevices.description}</p><TableTemplate/>
        <DocumentUpload value={technicalDevices} accept={registrationUploadLabels.technicalDevices.accept} onChange={value => setDocument('technicalDevices', value)} />
      </section>

      <footer className="skud-registration__actions">
        <Button onClick={back}>Назад</Button>
        <div className="skud-registration__actions-right">
          {showDraftButton && <Button onClick={saveDraft}>Сохранить черновик</Button>}
          <Button type="primary" onClick={publish}>Разместить заявку</Button>
        </div>
      </footer>

      <Modal open={publishing} footer={null} closable={false} centered width={470} className="skud-registration__publishing">
        <div><Spin /><strong>Публикация заявки</strong></div>
      </Modal>
      <Modal open={exitConfirm} footer={null} centered width={470} onCancel={() => setExitConfirm(false)} className="skud-registration__confirm-modal">
        <div className="skud-registration__confirm-heading"><ExclamationCircleFilled /><strong>Вы действительно хотите выйти?</strong></div>
        <p>Все несохраненные данные будут потеряны</p>
        <div className="skud-registration__confirm-actions"><Button onClick={() => setExitConfirm(false)}>Отменить</Button><Button type="primary" onClick={() => { setExitConfirm(false); onBack(); }}>Выйти</Button></div>
      </Modal>
      <Modal open={draftStage === 'saving'} footer={null} closable={false} centered width={470} className="skud-registration__publishing"><div><Spin /><strong>Сохранение черновика</strong></div></Modal>
      <Modal open={draftStage === 'saved'} footer={null} closable={false} centered width={470} className="skud-registration__draft-modal">
        <div className="skud-registration__draft-heading is-success"><CheckCircleFilled /><strong>Заявка сохранена в черновиках</strong></div><p>Вы сможете вернуться к заполнению позже</p><div className="skud-registration__confirm-actions"><Button type="primary" onClick={() => { setDraftStage('idle'); }}>Хорошо</Button></div>
      </Modal>
      <Modal open={draftStage === 'error'} footer={null} closable={false} centered width={470} className="skud-registration__draft-modal">
        <div className="skud-registration__draft-heading is-error"><CloseCircleFilled /><strong>Не удалось сохранить черновик</strong></div><p>Повторите попытку или вернитесь назад</p><div className="skud-registration__confirm-actions"><Button onClick={() => setDraftStage('idle')}>Назад</Button><Button type="primary" onClick={saveDraft}>Повторить</Button></div>
      </Modal>
    </div>
  );
}

export default RegistrationForm;
