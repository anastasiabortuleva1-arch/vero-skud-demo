import { TableTemplate } from './TableTemplate';
import { RequestDocuments } from './RequestDocuments';
import { mergeRequestDocuments, signedRequestDocument, requestContractName, requestReadinessName, requestAcceptanceName } from '../data/requestDocuments';
import { useEffect, useRef, useState } from 'react';
import type { ReactNode } from 'react';
import { Alert, Button, Collapse, Input, Modal, Progress, Spin, Tag } from 'antd';
import { ArrowUpOutlined, CheckCircleFilled, CheckOutlined, CloseCircleFilled, DeleteOutlined, DownloadOutlined, DownOutlined, EllipsisOutlined, LoadingOutlined, MinusOutlined, PaperClipOutlined, PlusOutlined, UpOutlined } from '@ant-design/icons';
import { DocumentRow, DocumentUpload, type LocalDocument } from './DocumentUpload';
import { executorWork as copy, type ExecutorWorkStage } from '../data/executorWork';
import { pendingOfferSummary } from '../data/executorOffer';
import { installOfferTables } from '../data/installRequest';
import './RegistrationRequest.css';
import './InstallRequest.css';
import './ExecutorWork.css';
import type { ExecutorRequestIdentity } from '../data/executorRequestIdentity';

export interface ExecutorWorkProps {
  identity?: ExecutorRequestIdentity;
  documents?: LocalDocument[];
  onDocumentSigned?: (document: LocalDocument) => void;
  initialStage?: ExecutorWorkStage;
  onBack: () => void;
  onMonitoring: () => void;
  onStageChange?: (stage: ExecutorWorkStage) => void;
  signatureOutcome?: 'success' | 'error';
  validationOutcome?: 'success' | 'error';
  additionalWorks?: ReactNode;
  additionalNotice?: ReactNode;
}
type SignKind = 'readiness' | 'acceptance' | 'finish';
type Overlay = 'sign' | 'signing' | 'error' | 'success';
const fixtureDocument = (name: string): LocalDocument => ({ name, size: 12 * 1024 });
const reworkStages: readonly ExecutorWorkStage[] = ['rework', 'rework-missing-scheme', 'rework-uploading', 'rework-ready'];
const preparedStages: ExecutorWorkStage[] = ['uploading', 'checking', 'validated', 'npa-error', 'npa-error-submit', 'correction', 'correction-uploading', ...reworkStages, 'review', 'acceptance', 'acceptance-sign', 'registration', 'finishing', 'finish-sign', 'finish-signing', 'finish-sign-error', 'finish-signed', 'finished'];
function initialComposition(stage: ExecutorWorkStage) { return preparedStages.includes(stage) && !['correction', 'correction-uploading'].includes(stage) ? fixtureDocument(reworkStages.includes(stage) ? copy.rework.composition : copy.documents.composition) : undefined; }
function initialScheme(stage: ExecutorWorkStage) { return preparedStages.includes(stage) && stage !== 'rework-missing-scheme' ? fixtureDocument(copy.documents.scheme) : undefined; }
const finishStages: ExecutorWorkStage[] = ['finishing', 'finish-sign', 'finish-signing', 'finish-sign-error', 'finish-signed', 'finished'];
function stageSignKind(stage: ExecutorWorkStage): SignKind { return finishStages.includes(stage) ? 'finish' : stage === 'acceptance-sign' || stage === 'acceptance' || stage === 'registration' ? 'acceptance' : 'readiness'; }
function initialOverlay(stage: ExecutorWorkStage): Overlay | undefined {
  if (['readiness-sign', 'acceptance-sign', 'finish-sign'].includes(stage)) return 'sign';
  if (['readiness-sign-error', 'finish-sign-error'].includes(stage)) return 'error';
  if (['readiness-signed', 'finish-signed'].includes(stage)) return 'success';
  if (stage === 'finish-signing') return 'signing';
}

export function ExecutorWork({ identity, documents, onDocumentSigned, initialStage = 'preparation', onBack, onMonitoring, onStageChange, signatureOutcome = 'success', validationOutcome = 'success', additionalWorks, additionalNotice }: ExecutorWorkProps) {
  const [signedDocuments,setSignedDocuments] = useState<LocalDocument[]>(() => documents !== undefined ? [] : ([requestContractName, ...(!['preparation','readiness','readiness-sign','readiness-sign-error'].includes(initialStage) ? [requestReadinessName] : []), ...(['registration',...finishStages].includes(initialStage) ? [requestAcceptanceName] : []), ...(['finish-signed','finished'].includes(initialStage) ? [copy.documents.finish] : [])]).map(signedRequestDocument));
  const initialSignedDocuments = useRef(signedDocuments);
  const reportedInitialDocuments = useRef(false);
  useEffect(() => {
    if (!onDocumentSigned || reportedInitialDocuments.current) return;
    reportedInitialDocuments.current = true;
    initialSignedDocuments.current.forEach(document => onDocumentSigned(document));
  }, [onDocumentSigned]);
  function recordSigned(name: string) {
    const document = signedRequestDocument(name);
    setSignedDocuments(current => mergeRequestDocuments(current,[document]));
    onDocumentSigned?.(document);
  }
  const [stage, setStage] = useState(initialStage);
  const [overlay, setOverlay] = useState<Overlay | undefined>(() => initialOverlay(initialStage));
  const [signKind, setSignKind] = useState<SignKind>(() => stageSignKind(initialStage));
  const [composition, setComposition] = useState<LocalDocument | undefined>(() => initialComposition(initialStage));
  const [scheme, setScheme] = useState<LocalDocument | undefined>(() => initialScheme(initialStage));
  const [reworkNoticeVisible, setReworkNoticeVisible] = useState(reworkStages.includes(initialStage) && initialStage !== 'rework-ready');
  const [attempted, setAttempted] = useState(initialStage === 'missing-documents');
  const [check, setCheck] = useState<'checking' | 'success' | 'error' | undefined>(() => initialStage === 'checking' ? 'checking' : initialStage === 'validated' ? 'success' : ['npa-error', 'npa-error-submit', 'correction', 'correction-uploading'].includes(initialStage) ? 'error' : undefined);
  const [submittedError, setSubmittedError] = useState(initialStage === 'npa-error-submit');
  const [message, setMessage] = useState('');
  const [messages, setMessages] = useState([copy.chat.message as string]);
  const [expanded, setExpanded] = useState(false);
  const [scale, setScale] = useState(1);
  const timer = useRef<ReturnType<typeof setTimeout> | undefined>(undefined);
  const checkTimer = useRef<ReturnType<typeof setTimeout> | undefined>(undefined);
  const uploadTimer = useRef<ReturnType<typeof setTimeout> | undefined>(undefined);
  const stageCallback = useRef(onStageChange);
  useEffect(() => { stageCallback.current = onStageChange; }, [onStageChange]);
  useEffect(() => {
    clearTimeout(timer.current); clearTimeout(checkTimer.current); clearTimeout(uploadTimer.current);
    setStage(initialStage); setOverlay(initialOverlay(initialStage)); setSignKind(stageSignKind(initialStage));
    setComposition(initialComposition(initialStage)); setScheme(initialScheme(initialStage));
    setReworkNoticeVisible(reworkStages.includes(initialStage) && initialStage !== 'rework-ready');
    setAttempted(initialStage === 'missing-documents'); setSubmittedError(initialStage === 'npa-error-submit');
    setCheck(initialStage === 'checking' ? 'checking' : initialStage === 'validated' ? 'success' : ['npa-error', 'npa-error-submit', 'correction', 'correction-uploading'].includes(initialStage) ? 'error' : undefined);
    return () => { clearTimeout(timer.current); clearTimeout(checkTimer.current); clearTimeout(uploadTimer.current); };
  }, [initialStage]);
  function changeStage(next: ExecutorWorkStage) { setStage(next); stageCallback.current?.(next); }
  const isFinish = finishStages.includes(stage);
  const isFinished = stage === 'finished' || stage === 'finish-signed';
  const isReadiness = ['readiness', 'readiness-sign', 'readiness-sign-error'].includes(stage);
  const isPreparation = stage === 'preparation';
  const isAcceptance = stage === 'acceptance' || stage === 'acceptance-sign';
  const isRework = reworkStages.includes(stage);
  const readOnly = stage === 'review' || isAcceptance || stage === 'registration' || isFinish;
  const showResult = !isPreparation && !isReadiness && stage !== 'readiness-signed';
  const currentStep = isFinished ? 4 : isFinish ? 3 : isAcceptance || stage === 'registration' ? 2 : 1;
  const status = stage === 'finished' ? 'Услуга оказана' : isRework ? copy.rework.status : isPreparation ? 'Подготовка к монтажу' : isReadiness || isFinish ? 'Требуется подпись' : stage === 'review' ? 'На проверке' : isAcceptance || stage === 'registration' ? 'На подключении' : 'В работе';
  const stepStatus = isRework ? copy.rework.stepStatus : status;
  const error = check === 'error';
  const uploading = stage === 'uploading' || stage === 'correction-uploading' || stage === 'rework-uploading';
  const steps = isFinish ? copy.finishSteps : copy.steps;

  function openSign(kind: SignKind) { setSignKind(kind); setScale(1); setOverlay('sign'); }
  function sign() {
    setOverlay('signing'); clearTimeout(timer.current);
    timer.current = setTimeout(() => {
      if (signatureOutcome === 'error') { setOverlay('error'); return; }
      recordSigned(signKind === 'finish' ? copy.documents.finish : signKind === 'readiness' ? requestReadinessName : requestAcceptanceName);
      changeStage(signKind === 'finish' ? 'finish-signed' : signKind === 'readiness' ? 'readiness-signed' : 'registration');
      setOverlay('success');
    }, 700);
  }
  function closeSuccess() { setOverlay(undefined); if (stage === 'readiness-signed') changeStage('working'); if (stage === 'finish-signed') changeStage('finished'); }
  function updateComposition(value?: LocalDocument) {
    setComposition(value); setSubmittedError(false); clearTimeout(checkTimer.current);
    if (!value) { setCheck(undefined); if (!isRework) changeStage('working'); return; }
    setCheck('checking');
    checkTimer.current = setTimeout(() => { setCheck(validationOutcome); if (!isRework) changeStage(validationOutcome === 'success' ? 'validated' : 'npa-error'); }, 700);
  }
  function updateScheme(value?: LocalDocument) {
    clearTimeout(uploadTimer.current); setScheme(value);
    if (!isRework) return;
    if (!value) { changeStage('rework-missing-scheme'); return; }
    changeStage('rework-uploading');
    uploadTimer.current = setTimeout(() => { setReworkNoticeVisible(false); changeStage('rework-ready'); }, 700);
  }
  function submit() {
    if (uploading) return;
    setAttempted(true);
    if (!composition || !scheme) { if (!isRework) changeStage('missing-documents'); return; }
    if (check === 'error') { setSubmittedError(true); if (!isRework) changeStage('npa-error-submit'); return; }
    if (check === 'checking') return;
    changeStage('review');
  }
  function sendMessage() { if (!message.trim()) return; setMessages(values => [...values, message.trim()]); setMessage(''); }
  const signDocument = signKind === 'finish' ? copy.documents.finish : signKind === 'acceptance' ? copy.documents.acceptance : copy.documents.readiness;

  return <div className="skud-request skud-install skud-executor-work">
    <section className="skud-request__summary"><div className="skud-request__heading"><div><div className="skud-request__title"><h1>{identity ? `${identity.name} — ${identity.title}` : copy.title}</h1><Tag color={isFinished ? 'success' : isPreparation || stage === 'review' || isAcceptance || stage === 'registration' ? 'processing' : 'warning'} variant="outlined">{status}</Tag></div><p>{identity?.id ?? copy.id}<span>Создана сегодня</span></p></div><Button icon={<EllipsisOutlined />} aria-label="Действия по заявке" onClick={onBack}/></div>
      <div className="skud-request__conditions"><h2>Условия заявки</h2><dl className="skud-executor-work__conditions"><div><dt>УИН ОКС</dt><dd>{identity ? identity.uin ?? '—' : copy.object.uin}</dd></div><div><dt>Источник финансирования</dt><dd>{copy.object.financing}</dd></div><div><dt>Формат работы</dt><dd>{identity?.workFormat ?? copy.object.workFormat}</dd></div><div className="skud-executor-work__address"><dt>Адрес ОКС</dt><dd>{identity?.address ?? copy.object.address}</dd></div><div><dt>Схема расположения СКУД</dt><dd>{copy.object.schemePreparedBy}</dd></div></dl></div>
    </section>
    <div className="skud-request__columns"><div className="skud-request__body">
      {additionalNotice}
      {isPreparation && <Alert className="skud-executor-work__readiness" type="info" showIcon title={copy.preparationTitle} description={copy.preparationDescription}/>}
      {(isReadiness || isAcceptance || (isFinish && !isFinished)) && <Alert className="skud-executor-work__readiness" type="warning" showIcon title={isReadiness ? copy.readinessTitle : isAcceptance ? copy.acceptanceTitle : copy.finishTitle} description={<><p>{isReadiness ? copy.readinessDescription : isAcceptance ? copy.acceptanceDescription : copy.finishDescription}</p><div className="skud-executor-work__sign-document"><DocumentRow document={fixtureDocument(isReadiness ? copy.documents.readiness : isAcceptance ? copy.documents.acceptance : copy.documents.finish)}/><Button type={isReadiness ? 'primary' : 'default'} onClick={() => openSign(isReadiness ? 'readiness' : isAcceptance ? 'acceptance' : 'finish')}>Подписать</Button></div></>}/>}
      {isFinish && <section className="skud-request__panel skud-executor-work__monitoring"><h2>{copy.monitoringTitle}</h2><p>{copy.monitoringDescription}</p><div className="skud-request__actions"><Button type="primary" onClick={onMonitoring}>Перейти к мониторингу</Button></div></section>}
      <section className="skud-request__panel skud-install__chat"><h2>Чат с заказчиком</h2><div className="skud-install__messages"><div className="skud-install__chat-date">{copy.chat.date}</div>{messages.map((value, index) => <div className="skud-install__message" key={index}><span><CheckOutlined/> {copy.chat.time}</span><div>{value}</div></div>)}</div><div className="skud-install__chat-input"><PaperClipOutlined/><Input placeholder="Введите сообщение" value={message} onChange={event => setMessage(event.target.value)} onPressEnter={sendMessage} suffix={<Button type="primary" shape="circle" size="small" icon={<ArrowUpOutlined/>} aria-label="Отправить сообщение" disabled={!message.trim()} onClick={sendMessage}/>}/></div></section>
      {showResult && <><section className={`skud-request__panel skud-executor-work__result ${isRework ? 'is-rework' : ''}`}><h2>Сдача результата</h2><p>{copy.resultDescription}</p>
        {isRework && reworkNoticeVisible && <Alert type="error" showIcon closable title={copy.rework.title} description={<><strong>{copy.rework.commentLabel}</strong><p>{copy.rework.comment}</p></>} className="skud-executor-work__rework-notice" onClose={() => setReworkNoticeVisible(false)}/>}
        {error && !submittedError && <Alert type="error" showIcon title={copy.faceIdTitle} description={copy.faceIdDescription} className="skud-executor-work__face-error"/>}
        <div className="skud-executor-work__upload-card"><h3>Состав технических средств СКУД в табличной форме</h3><p>Загрузите файл в формате XLSX</p>{!readOnly&&<TableTemplate/>}{uploading && !isRework ? <UploadingDocument name="Общие сведения об объекте.xlsx" percent={68}/> : readOnly ? composition && <DocumentRow document={composition}/> : <DocumentUpload value={composition} onChange={updateComposition} accept=".xlsx" error={attempted && !composition ? 'Добавьте документ!' : undefined}/>}</div>
        <div className="skud-executor-work__upload-card"><h3>Схема размещения СКУД</h3><p>Загрузите файл в формате PDF</p>{stage === 'uploading' || stage === 'rework-uploading' ? <UploadingDocument name={scheme?.name ?? copy.documents.scheme} percent={55} onRemove={isRework ? () => updateScheme(undefined) : undefined}/> : readOnly ? scheme && <DocumentRow document={scheme}/> : <DocumentUpload value={scheme} onChange={updateScheme} accept=".pdf" error={attempted && !scheme ? 'Добавьте документ!' : undefined}/>}</div>
        {!readOnly && check && <div className={`skud-executor-work__check is-${check}`}>{check === 'checking' ? <LoadingOutlined spin/> : check === 'success' ? <CheckCircleFilled/> : <CloseCircleFilled/>}<span>{check === 'checking' ? copy.checking : check === 'success' ? copy.valid : copy.invalid}</span></div>}
        {submittedError && <><Alert type="error" showIcon title={copy.faceIdTitle} description={copy.faceIdDescription} className="skud-executor-work__face-error"/><p className="skud-executor-work__fix-error">Исправьте ошибки</p></>}
        {!readOnly && <div className="skud-request__actions"><Button type="primary" onClick={submit} disabled={check === 'checking' || (uploading && !isRework)}>Отправить результат</Button></div>}
      </section>{additionalWorks ?? <section className="skud-request__panel skud-install__additional"><h2>Дополнительные работы</h2><p>{copy.additionalDescription}</p><div className="skud-request__actions"><Button disabled>Дополнительное соглашение</Button></div></section>}</>}
      <section className="skud-request__panel skud-install__commercial"><h2>Коммерческое предложение</h2><div className="skud-install__commercial-meta"><span>Исполнитель: {pendingOfferSummary.contractor}</span><span>Отправлено {pendingOfferSummary.sentAt}<Button size="small" disabled icon={<DownloadOutlined/>} aria-label="Скачать коммерческое предложение"/></span></div><div className="skud-install__commercial-summary"><div><h3>Общая сводка</h3><dl><div><dt>Покупка оборудования</dt><dd>{pendingOfferSummary.equipmentPurchase}</dd></div><div><dt>Монтаж</dt><dd>{pendingOfferSummary.installation}</dd></div><div><dt>ТО</dt><dd>{pendingOfferSummary.maintenanceMonthly}</dd></div></dl><dl className="skud-install__dates"><div><dt>Начало работ</dt><dd>{pendingOfferSummary.startDate}</dd></div><div><dt>Окончание работ</dt><dd>{pendingOfferSummary.endDate}</dd></div></dl></div><div><h3>Итого</h3><dl><div><dt>Разовые расходы</dt><dd>{pendingOfferSummary.oneTimeTotal}</dd></div><div><dt>Регулярные расходы</dt><dd>{pendingOfferSummary.recurringTotal}</dd></div></dl><p>Расчёт стоимости с НДС, 22%</p></div></div>
        {expanded && <div className="skud-install__tables">{installOfferTables.map(table => <section className="skud-install__table-section" key={table.title}><h3>{table.title}</h3><table className="skud-install__table"><thead><tr><th>{table.firstColumn}</th><th>Кол-во</th><th>Цена за шт., ₽</th><th>{table.totalColumn}</th></tr></thead><tbody>{table.rows.map(row => <tr key={row[0]}>{row.map((cell, index) => <td key={index}>{cell}</td>)}</tr>)}</tbody><tfoot><tr className="skud-install__table-total"><td colSpan={3}>Итого</td><td>{table.total}</td></tr><tr><td colSpan={3}>В том числе НДС</td><td>{table.vat}</td></tr></tfoot></table></section>)}</div>}
        <div className="skud-install__details"><Button type="text" onClick={() => setExpanded(value => !value)}>{expanded ? 'Скрыть подробную таблицу' : 'Показать подробную таблицу'} {expanded ? <UpOutlined/> : <DownOutlined/>}</Button></div>
      </section>
    </div><aside className="skud-request__aside"><ol className="skud-request__steps">{steps.map((label, index) => <li key={label} className={index < currentStep ? 'is-done' : index === currentStep ? 'is-current' : ''}><span className="skud-request__step-number">{index < currentStep ? <CheckOutlined/> : index + 1}</span><div>{label}{index === currentStep && <p>{stepStatus}</p>}</div></li>)}</ol><Collapse className="skud-request__documents" expandIconPlacement="end" items={[{key: 'documents', label: 'Документы по заявке', children: <RequestDocuments documents={documents} localDocuments={[composition,scheme]} signedDocuments={signedDocuments}/>}]} /></aside></div>
    <Modal open={overlay === 'sign'} title="Подписать документ" centered width={820} onCancel={() => setOverlay(undefined)} footer={<><Button onClick={() => setOverlay(undefined)}>Отменить</Button><Button type="primary" onClick={sign}>Подписать</Button></>}>
      <div className={`skud-install__viewer skud-executor-work__viewer ${signKind === 'finish' ? 'is-finish' : ''}`}><div className="skud-install__paper" style={{zoom: scale}}><ReferencePaper kind={signKind}/></div><div className="skud-install__viewer-controls"><Button shape="circle" size="small" icon={<PlusOutlined/>} aria-label="Увеличить документ" onClick={() => setScale(value => Math.min(2, value + .1))}/><Button shape="circle" size="small" icon={<MinusOutlined/>} aria-label="Уменьшить документ" onClick={() => setScale(value => Math.max(.5, value - .1))}/><Button shape="circle" size="small" icon={<DownloadOutlined/>} aria-label={`Скачать ${signDocument}`} disabled/></div></div>
    </Modal>
    <Modal open={overlay === 'signing'} centered width={520} footer={null} closable={false} mask={{closable: false}}><div className="skud-request__loading"><Spin/><strong>Подписание документов</strong></div></Modal>
    <Modal open={overlay === 'error'} centered width={448} onCancel={() => setOverlay(undefined)} footer={<><Button onClick={() => setOverlay('sign')}>Назад</Button><Button type="primary" onClick={sign}>Повторить</Button></>}><div className="skud-install__notice"><CloseCircleFilled className="is-error"/><div><strong>{copy.errorTitle}</strong><p>{copy.errorDescription}</p></div></div></Modal>
    <Modal open={overlay === 'success'} centered width={448} onCancel={closeSuccess} footer={<Button type="primary" onClick={closeSuccess}>Хорошо</Button>}><div className="skud-install__notice"><CheckCircleFilled className="is-success"/><div><strong>{copy.signedTitle}</strong><p>{signKind === 'finish' ? <>Сумма в размере <strong>753 120,00 ₽</strong> зачислена на ваш баланс</> : copy.signedDescription}</p></div></div></Modal>
  </div>;
}
function UploadingDocument({ name, percent, onRemove }: { name: string; percent: number; onRemove?: () => void }) {
  return <><div className="skud-executor-work__uploading"><LoadingOutlined spin/><div><strong>{name}</strong><Progress percent={percent} showInfo={false} size="small"/></div><Button danger size="small" disabled={!onRemove} onClick={onRemove} icon={<DeleteOutlined/>}/></div><DocumentUpload accept={name.endsWith('.pdf') ? '.pdf' : '.xlsx'} onChange={() => undefined}/></>;
}
function ReferencePaper({ kind }: { kind: SignKind }) {
  if (kind === 'finish') return <><h2>ДОГОВОР ВОЗМЕЗДНОГО ОКАЗАНИЯ УСЛУГ № ___</h2><div className="skud-install__paper-place">г. _______________<span>«__» __________ 20__ г.</span></div><p>Общество ________________________, далее именуемое «Заказчик» в лице генерального директора ________________________, действующего на основании ________________________, с одной стороны, и гражданин РФ ________________________, именуемый «Исполнитель», с другой стороны, далее совместно именуемые «Стороны», заключили настоящий договор о нижеследующем:</p><h3 className="skud-executor-work__paper-center">1. Предмет Договора</h3><p>1.1. В соответствии с Договором Исполнитель обязуется по заданию Заказчика оказать следующие услуги:</p><p className="skud-executor-work__paper-line">__________________________________________________________</p><p className="skud-executor-work__paper-caption">(наименование услуги)</p><p>(далее — услуги), а Заказчик обязуется оплатить эти услуги.</p><p>В рамках оказания услуг Исполнитель обязуется совершить следующие действия:</p><p className="skud-executor-work__paper-line">__________________________________________________________</p><p className="skud-executor-work__paper-caption">(наименование действий)　　　　(количество, объем, иные характеристики)</p></>;
  return <><div className="skud-install__appendix">Приложение № {kind === 'readiness' ? '6' : '2'}<br/>к Договору на оснащение объекта капитального строительства системой контроля управления доступом (СКУД) с функцией биометрической идентификации по лицу (Face ID) и её интеграции с государственными информационными системами города Москвы<br/>№ ___ от «___» __________ 20___ г.</div><p className="skud-install__form-label">ФОРМА</p><h2>АКТ № ___</h2><h3 className="skud-install__act-subtitle">{kind === 'readiness' ? 'готовности строительной площадки к монтажу оборудования СКУД с Face ID' : 'приёма-сдачи выполненных работ (услуг)'}</h3><div className="skud-install__paper-place">г. Москва<span>«__» __________ 20__ г.</span></div><p><b>Подрядчик:</b> ________________________, в лице ________________________, действующего на основании ________________________, с одной стороны, и<br/><b>Заказчик:</b> ________________________, в лице ________________________, действующего на основании ________________________, с другой стороны совместно именуемые «Стороны», составили настоящий Акт о нижеследующем:</p>
    {kind === 'readiness' ? <><h3>1. ОБЪЕКТ И МЕСТО ПРОВЕДЕНИЯ РАБОТ</h3><p className="skud-executor-work__paper-fields">1.1. Объект: __________________________________ (наименование и адрес).<br/>1.2. УИН ОКС: __________________________________.<br/>1.3. УИН ПС: ___________________________________.<br/>1.4. Номер (идентификатор) строительной площадки: __________________.<br/>1.5. Место установки оборудования (помещение/зона/проходная): ______________.</p><h3>2. ПРОВЕРКА УСЛОВИЙ ГОТОВНОСТИ</h3><table><thead><tr><th>№ п/п</th><th>Наименование параметра готовности</th><th>Соответствие (Да/Нет)</th><th>Примечание / Документ</th></tr></thead><tbody><tr><td>1</td><td>Наличие подключения к электрической сети</td><td/><td/></tr></tbody></table></> : <><h3>1. ОСНОВАНИЕ СОСТАВЛЕНИЯ АКТА</h3><p className="skud-executor-work__paper-fields">1.1. Настоящий Акт составлен во исполнение условий Договора № ____ от «__» ______ 20__ г. и Спецификации № ____ от «__» ______ 20__ г. (далее — Спецификация) и подтверждает факт выполнения Подрядчиком работ (услуг) по указанной Спецификации.</p><h3>2. ПЕРЕЧЕНЬ ВЫПОЛНЕННЫХ РАБОТ (УСЛУГ)</h3><table><thead><tr><th>№ п/п</th><th>Наименование работ (услуг)</th><th>Ед. изм.</th><th>Объём (количество)</th><th>Соответствие Спецификации (да/нет)</th><th>Примечание</th></tr></thead><tbody><tr><td>1</td><td>Поставка оборудования (по позициям…)</td><td>компл.</td><td/><td/><td/></tr><tr><td>2</td><td>Монтажные работы</td><td/><td/><td/><td/></tr></tbody></table></>}
  </>;
}
export default ExecutorWork;
