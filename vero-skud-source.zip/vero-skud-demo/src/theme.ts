import type { ThemeConfig } from 'antd';

// Baseline values explicitly supplied in skud-handoff.md.
// Screen-specific values belong to the module after measuring its Figma frames.
export const veroTheme: ThemeConfig = {
  token: {
    fontFamily: '"Noto Sans", sans-serif',
    fontSize: 14,
    fontSizeSM: 12,
    fontSizeLG: 16,
    lineHeight: 22 / 14,
    lineHeightSM: 20 / 12,
    lineHeightLG: 24 / 16,
    fontWeightStrong: 600,
    fontSizeHeading1: 38,
    fontSizeHeading2: 30,
    fontSizeHeading3: 24,
    fontSizeHeading4: 20,
    fontSizeHeading5: 16,
    lineHeightHeading1: 46 / 38,
    lineHeightHeading2: 38 / 30,
    lineHeightHeading3: 32 / 24,
    lineHeightHeading4: 28 / 20,
    lineHeightHeading5: 24 / 16,
    colorPrimary: '#1677FF',
    colorSuccess: '#52C41A',
    colorWarning: '#FAAD14',
    colorError: '#FF4D4F',
    colorBgContainer: '#FFFFFF',
    colorBgLayout: '#F5F5F5',
  },
};

export const veroSpacing = [4, 8, 12, 16, 20, 24, 32] as const;
export const veroRadii = [4, 6, 8] as const;
