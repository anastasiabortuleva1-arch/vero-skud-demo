import { MyResponses } from './modules/skud/components/MyResponses';
import { executorResponseFixtures,responseWorkStatus } from './modules/skud/data/executorResponses';
import type { ExecutorResponse } from './modules/skud/data/executorResponses';
import { incomingRequestFixtures } from './modules/skud/data/incomingRequests';
import type { MonitoringTerminationState } from './modules/skud/components/MonitoringTermination';
import { useCallback, useState } from 'react';
import { Breadcrumb, Result, Button } from 'antd';
import { Link, Navigate, useLocation, useNavigate, useSearchParams } from 'react-router-dom';
import { SkudShell } from './modules/skud/components/SkudShell';
import { MyRequests } from './modules/skud/components/MyRequests';
import { IncomingRequests } from './modules/skud/components/IncomingRequests';
import { ExecutorOffer } from './modules/skud/components/ExecutorOffer';
import { ExecutorAdditionalAgreement, ExecutorAdditionalAgreementNotice } from './modules/skud/components/ExecutorAdditionalAgreement';
import { executorAdditionalAgreementFixtures } from './modules/skud/data/executorAdditionalAgreement';
import type { ExecutorAdditionalAgreementState, ExecutorAdditionalAgreementData } from './modules/skud/data/executorAdditionalAgreement';
import { ExecutorWork } from './modules/skud/components/ExecutorWork';
import { Monitoring } from './modules/skud/components/Monitoring';
import { RegistrationForm } from './modules/skud/components/RegistrationForm';
import { InstallForm } from './modules/skud/components/InstallForm';
import { RegistrationRequest } from './modules/skud/components/RegistrationRequest';
import { InstallRequest } from './modules/skud/components/InstallRequest';
import { AdditionalAgreement, AdditionalAgreementNotice } from './modules/skud/components/AdditionalAgreement';
import { ContractTermination } from './modules/skud/components/ContractTermination';
import { additionalAgreementStates } from './modules/skud/data/additionalAgreement';
import type { AdditionalAgreementState } from './modules/skud/data/additionalAgreement';
import type { ContractTerminationData } from './modules/skud/data/contractTermination';
import { installStages } from './modules/skud/data/installRequest';
import type { InstallStage, InstallObject } from './modules/skud/data/installRequest';
import { executorWorkStages } from './modules/skud/data/executorWork';
import type { ExecutorWorkStage } from './modules/skud/data/executorWork';
import type { ExecutorOfferData, ExecutorOfferStage } from './modules/skud/data/executorOffer';
import { archivedRequestExample, requestCards } from './modules/skud/data/requestCards';
import type { RequestCardData, RequestTab } from './modules/skud/data/requestCards';
import type { RegistrationFormData, RegistrationFormState } from './modules/skud/data/registrationForm';
import type { InstallFormData } from './modules/skud/data/installForm';
import { registrationStages } from './modules/skud/data/registrationRequest';
import type { RegistrationStage, RegistrationSnapshot } from './modules/skud/data/registrationRequest';
import { monitoringObjects } from './modules/skud/data/monitoring';
import { DemoControls } from './modules/skud/components/DemoControls';
import type { DemoFamily } from './modules/skud/components/DemoControls';
import type { LocalDocument } from './modules/skud/components/DocumentUpload';
import { mergeRequestDocuments, signedRequestDocument, requestContractName, requestReadinessName } from './modules/skud/data/requestDocuments';
import './app.css';

interface LocalRequest {
  kind: 'install' | 'registration';
  card: RequestCardData;
  data?: RegistrationFormData | InstallFormData;
  registrationStage: RegistrationStage;
  installStage: InstallStage;
  registrationStarted?: boolean;
  snapshot?: RegistrationSnapshot;
  installObject?: InstallObject;
  agreement?: AdditionalAgreementState;
  terminationRequest?: ContractTerminationData;
}
const makeRecord = (card: RequestCardData, index = 0): LocalRequest => ({
  kind: 'install', card, registrationStage: 'initial', installStage: index === 0 ? 'acceptance' : 'offers',
});
const offerStages: readonly ExecutorOfferStage[] = ['form', 'filled', 'validation', 'contract', 'signing', 'sign-error', 'signed', 'pending'];

export default function App() {
  const navigate = useNavigate();
  const location = useLocation();
  const [query] = useSearchParams();
  const role = query.get('role') === 'executor' || /^\/skud\/(incoming|responses|offer|work)/.test(location.pathname) ? 'executor' : 'customer';
  const [demoFill, setDemoFill] = useState({ key: '', token: 0 });
  const demoFillToken = demoFill.key === location.key ? demoFill.token : 0;
  const [observedStage, setObservedStage] = useState({ key: '', stage: '' });
  const observeStage = (stage: string) => setObservedStage(current => current.key === location.key && current.stage === stage ? current : { key: location.key, stage });
  const [roleLocations, setRoleLocations] = useState<Partial<Record<'customer'|'executor', string>>>({});
  const [records, setRecords] = useState<Record<string, LocalRequest>>(() => Object.fromEntries(requestCards.map((card, index) => [card.key, makeRecord(card, index)])));
  const [documentBank, setDocumentBank] = useState<Record<string, LocalDocument[]>>(() => ({[requestCards[0].key]: [requestContractName,requestReadinessName].map(signedRequestDocument)}));
  const [savedDraftKeys, setSavedDraftKeys] = useState<Record<string,string>>({});
  const [deletedKeys, setDeletedKeys] = useState<string[]>([]);
  const [selectedOffers,setSelectedOffers]=useState<Record<string,string>>({});
  const [workStages,setWorkStages]=useState<Record<string,ExecutorWorkStage>>({});
  const [deletedResponses,setDeletedResponses]=useState<string[]>([]);
  const [offers, setOffers] = useState<Record<string, ExecutorOfferData>>({});
  const [executorAgreements, setExecutorAgreements] = useState<Record<string, ExecutorAdditionalAgreementState>>({});
  const [executorEstimates, setExecutorEstimates] = useState<Record<string, ExecutorAdditionalAgreementData>>({});
  const [monitoringTerminations,setMonitoringTerminations]=useState<Record<string,MonitoringTerminationState>>({});
  const [termination, setTermination] = useState<ContractTerminationData>({ stage: 'closed', comment: '' });
  const [exampleAgreements, setExampleAgreements] = useState<Record<string, AdditionalAgreementState>>({});
  const active = location.pathname.includes('/monitoring') ? 'monitoring' : role === 'executor' ? (location.pathname.includes('/incoming') || location.pathname.includes('/offer') ? 'incoming' : 'responses') : 'requests';
  const isNew = location.pathname.includes('/new/');
  const key = decodeURIComponent(location.pathname.split('/')[3] ?? '');
  const monitoringContractKey=monitoringObjects[key]?.requestId ?? '';
  const monitoringTermination=monitoringTerminations[monitoringContractKey];
  const updateMonitoringTermination=(value:MonitoringTerminationState)=>{
    setMonitoringTerminations(current=>({...current,[monitoringContractKey]:value}));
    if(value.status==='terminated'){
      const document=signedRequestDocument('Дополнительное соглашение о расторжении договора.pdf');
      setDocumentBank(current=>({...current,'installation-example':mergeRequestDocuments(current['installation-example']??[],[document]),[requestCards[0].key]:mergeRequestDocuments(current[requestCards[0].key]??[],[document])}));
    }
  };
  const responseRecords:ExecutorResponse[]=[...executorResponseFixtures,...Object.keys(offers).filter(id=>!executorResponseFixtures.some(item=>item.key===id)).map((id,index):ExecutorResponse=>{
    const incoming=incomingRequestFixtures.find(item=>item.key===id);
    return {key:id,id:`СКУД-2026-${String(20+index).padStart(4,'0')}`,title:'Установка и регистрация СКУД',name:incoming?.organization??'ЖК «Коломенское»',address:incoming?.address??'г. Москва, Огородный проезд, земельный участок 6/1',workFormat:incoming?.workFormat??'Монтаж и ТО',tab:'active',status:'Отклик на рассмотрении',color:'processing',group:'work',deadline:offers[id].endDate||'—'};
  })].filter(item=>!deletedResponses.includes(item.key)).map(item=>workStages[item.key]?{...item,stage:workStages[item.key],...responseWorkStatus(workStages[item.key]),tab:item.tab}:item);
  const responseRecord=responseRecords.find(item=>item.key===key);
  const record = records[key];
  const data = record?.data;
  const documentKey = key === 'installation-registration-example' ? 'installation-example' : key;
  const onDocumentSigned = useCallback((document: LocalDocument) => {
    setDocumentBank(current => ({...current,[documentKey]:mergeRequestDocuments(current[documentKey] ?? [],[document])}));
  }, [documentKey]);
  const requestDocuments = record || documentBank[documentKey] ? mergeRequestDocuments(
    data ? ['sitePlan' in data ? data.sitePlan : undefined, 'placementPlan' in data ? data.placementPlan : undefined, 'technicalDevices' in data ? data.technicalDevices : undefined] : [],
    [record?.snapshot?.scheme,record?.snapshot?.composition,record?.snapshot?.testFile], documentBank[documentKey] ?? [],
  ) : undefined;
  const object = record?.installObject ?? (data ? {
    uin: data.uin, name: data.objectName, address: data.address, financing: data.fundingSource,
    scheme: 'placementPlan' in data ? data.placementPlan : undefined,
    composition: 'technicalDevices' in data ? data.technicalDevices : undefined,
    workFormat: 'workFormat' in data ? data.workFormat : '',
    schemePreparedBy: 'schemePreparation' in data ? data.schemePreparation : '',
  } : undefined);
  const baseTitle = active === 'monitoring' ? 'Мониторинг' : active === 'incoming' ? 'Входящие заявки' : active === 'responses' ? 'Мои отклики' : 'Мои заявки';
  const roleQuery = role === 'executor' ? '?role=executor' : '';
  const queryAgreement = query.get('agreement') as AdditionalAgreementState;
  const agreement = record?.agreement ?? exampleAgreements[location.key] ?? (additionalAgreementStates.includes(queryAgreement) ? queryAgreement : 'idle');
  const signOutcome = query.get('sign') === 'error' ? 'error' : 'success';

  function list(tab: RequestTab = 'active') {
    navigate(`/skud/requests${tab === 'active' ? '' : `?tab=${tab}`}`);
  }
  function patch(requestKey: string, update: Partial<LocalRequest>) {
    setRecords(current => current[requestKey] ? { ...current, [requestKey]: { ...current[requestKey], ...update } } : current);
  }
  function updateRequestStage(next: InstallStage | RegistrationStage, registration: boolean) {
    observeStage(next);
    if (!record) return;
    const statuses: Record<string,string> = registration
      ? {initial:'Ожидает отправки',ready:'Ожидает отправки',review:'В Правительстве','government-correction':'Требуется исправление','test-empty':'Ожидает отправки','test-ready':'Ожидает отправки',testing:'На тестировании','test-error':'Требуется исправление','test-correction':'Требуется исправление','test-correction-ready':'Ожидает отправки','finish-ready':'Требуется подпись','finish-sign':'Требуется подпись',completed:'Услуга оказана'}
      : {'empty-offers':'Получаем предложения',offers:'Получаем предложения',offer:'Получаем предложения','contract-sign':'Требуется подпись',preparation:'Подготовка к монтажу',working:'В работе',acceptance:'Ожидает приёмки','accept-sign':'Требуется подпись',rework:'Отправлено на доработку'};
    setRecords(current => {
      const previous=current[key]; if (!previous) return current;
      const field=registration?'registrationStage':'installStage';
      if(previous[field]===next && previous.card.status===statuses[next]) return current;
      return {...current,[key]:{...previous,[field]:next,card:{...previous.card,status:statuses[next],statusColor:next==='completed'?'success':['working','review','testing','offers','empty-offers','offer'].includes(next)?'processing':'warning'}}};
    });
  }
  function changeAgreement(next: AdditionalAgreementState) {
    if (next === 'signed' || next === 'confirmed') onDocumentSigned(signedRequestDocument('Дополнительное соглашение к Договору №2026-СВ-018/КУ.pdf'));
    if (record) patch(key, { agreement: next });
    else setExampleAgreements(current => ({ ...current, [location.key]: next }));
  }
  function openTermination() { setTermination({ stage: 'reason', comment: '' }); }
  function save(kind: 'install' | 'registration', formData: RegistrationFormData | InstallFormData, tab: 'drafts' | 'active', existingKey?: string) {
    const requestKey = existingKey ?? savedDraftKeys[location.key] ?? `${kind}-${Date.now()}`;
    const card: RequestCardData = {
      key: requestKey, id: 'СКУД-2026-0009', tab, name: formData.objectName,
      service: kind === 'registration' ? 'Регистрация СКУД в реестре' : 'Установка и регистрация СКУД',
      address: formData.address, status: tab === 'drafts' ? 'Черновик' : kind === 'registration' ? 'Ожидает отправки' : 'Получаем предложения',
      statusColor: tab === 'drafts' ? 'default' : 'processing', date: 'сегодня',
      workFormat: 'workFormat' in formData ? formData.workFormat : '',
    };
    setRecords(current => ({ ...current, [requestKey]: { kind, data: formData, card, registrationStage: 'initial', installStage: 'empty-offers' } }));
    if (tab === 'drafts') setSavedDraftKeys(current => ({...current,[location.key]:requestKey}));
    else navigate(`/skud/requests/${requestKey}`);
  }
  function withdraw(stage: RegistrationStage | InstallStage, isRegistration: boolean) {
    if (!record) return;
    patch(key, {
      ...(isRegistration ? { registrationStage: stage as RegistrationStage } : { installStage: stage as InstallStage }),
      card: { ...record.card, tab: 'archive', status: 'Заявка отозвана', statusColor: 'default', messages: undefined },
    });
    list('archive');
  }
  function republish(requestKey: string) {
    const previous = records[requestKey] ?? (requestKey === archivedRequestExample.key ? makeRecord(archivedRequestExample) : undefined);
    if (!previous) return;
    const status = previous.kind === 'registration' || previous.registrationStarted ? 'Ожидает отправки' : previous.installStage === 'acceptance' ? 'Ожидает приёмки' : 'Получаем предложения';
    setRecords(current => ({ ...current, [requestKey]: { ...previous, card: { ...previous.card, tab: 'active', status, statusColor: status === 'Получаем предложения' ? 'processing' : 'warning' } } }));
    navigate(`/skud/requests/${requestKey}`);
  }
  const archiveExample = query.get('example') === 'archive' && !records[archivedRequestExample.key] && !deletedKeys.includes(archivedRequestExample.key);
  const requestedStage = query.get('stage');
  let content;
  if (location.pathname === '/') content = <Navigate to="/skud/requests" replace />;
  else if (location.pathname === '/skud/responses') content = <MyResponses initialTab={query.get('tab')==='archive'?'archive':'active'} requests={responseRecords} onDelete={id=>setDeletedResponses(current=>[...current,id])} onOpen={item=>navigate(item.stage?`/skud/work/${item.key}?role=executor`:`/skud/responses/${item.key}?role=executor`)} />;
  else if (location.pathname === '/skud/incoming') content = <IncomingRequests requests={incomingRequestFixtures.map(item=>offers[item.key]?{...item,hasResponded:true,badge:'Вы откликнулись' as const,responseButton:'Откликнуться ещё' as const}:item)} onRespond={requestKey => navigate(`/skud/offer/${requestKey}?role=executor`)} />;
  else if (location.pathname.startsWith('/skud/offer/') || location.pathname.startsWith('/skud/responses/')) {
    const stage = requestedStage as ExecutorOfferStage;
    content = <ExecutorOffer identity={responseRecord} documents={requestDocuments} onDocumentSigned={onDocumentSigned} onStageChange={observeStage} demoFillToken={demoFillToken} key={location.key} initialStage={offerStages.includes(stage) ? stage : offers[key] || location.pathname.includes('/responses/') ? 'pending' : 'form'} initialData={offers[key]}
      onBack={() => navigate(location.pathname.includes('/responses/')?'/skud/responses?role=executor':'/skud/incoming?role=executor')}
      onWithdraw={() => { setOffers(current => { const next = { ...current }; delete next[key]; return next; }); navigate('/skud/incoming?role=executor'); }}
      onSubmitted={values => { setOffers(current => ({ ...current, [key]: values })); navigate(`/skud/responses/${key}?role=executor`); }} />;
  } else if (location.pathname.startsWith('/skud/work/')) {
    const stage = requestedStage as ExecutorWorkStage;
    const origin = query.get('origin') === 'customer' ? 'customer' : 'executor';
    const allowedAgreements: readonly ExecutorAdditionalAgreementState[] = ['idle', 'incoming', 'select', 'estimate', 'sign', 'signing', 'sign-error', 'signed', 'sent', 'confirmed'];
    const requestedAgreement = query.get('agreement') as ExecutorAdditionalAgreementState;
    const executorAgreement = executorAgreements[location.key] ?? (allowedAgreements.includes(requestedAgreement) ? requestedAgreement : origin === 'customer' ? 'incoming' : 'idle');
    const updateAgreement = (next: ExecutorAdditionalAgreementState) => { setExecutorAgreements(current => ({ ...current, [location.key]: next })); if (['signed','sent','confirmed'].includes(next)) onDocumentSigned(signedRequestDocument('Дополнительное соглашение к Договору №2026-СВ-018/КУ.pdf')); };
    const fixtureName = query.get('estimate');
    const fixture = fixtureName === 'filledDeadline' ? executorAdditionalAgreementFixtures.filledDeadline : fixtureName === 'filledUnchanged' ? executorAdditionalAgreementFixtures.filledUnchanged : undefined;
    content = <ExecutorWork identity={responseRecord} documents={requestDocuments} onDocumentSigned={onDocumentSigned} key={location.key} onStageChange={next=>{observeStage(next);setWorkStages(current=>current[key]===next?current:{...current,[key]:next});}} initialStage={executorWorkStages.includes(stage) ? stage : workStages[key]??responseRecord?.stage??'working'} onBack={() => navigate('/skud/responses?role=executor')} onMonitoring={() => navigate('/skud/monitoring/kolomenskoye?role=executor')} signatureOutcome={signOutcome} validationOutcome={query.get('validation') === 'error' ? 'error' : 'success'}
      additionalNotice={origin === 'customer' ? <ExecutorAdditionalAgreementNotice state={executorAgreement} onEstimate={() => updateAgreement('estimate')} /> : undefined}
      additionalWorks={<ExecutorAdditionalAgreement key={location.key} state={executorAgreement} onStateChange={updateAgreement} origin={origin} initialData={fixture?.data} data={executorEstimates[location.key]} onDataChange={next => setExecutorEstimates(current => ({ ...current, [location.key]: next }))} showNotice={false} totals={fixture?.totals} signatureOutcome={signOutcome} />} />;
  } else if (active === 'monitoring') {
    content = <Monitoring termination={monitoringTermination} onTerminationChange={updateMonitoringTermination} onRegistration={()=>navigate('/skud/new/install')} key={`${role}:${key}:${location.search}`} role={role} objectId={key || undefined} empty={query.get('empty') === '1'} onBack={() => navigate(`/skud/monitoring${roleQuery}`)} onRequests={() => role === 'executor' ? navigate('/skud/incoming?role=executor') : list()}
      onOpenObject={id => { if (monitoringObjects[id]) navigate(`/skud/monitoring/${id}${roleQuery}`); }} />;
  } else if (location.pathname === '/skud/requests') {
    const tab = query.get('tab');
    content = <MyRequests key={location.search} initialTab={archiveExample ? 'archive' : tab === 'drafts' || tab === 'archive' ? tab : 'active'} requests={[...Object.values(records).map(item => item.card), ...(archiveExample ? [archivedRequestExample] : [])]}
      onCreate={kind => navigate(`/skud/new/${kind}`)} onOpenRequest={requestKey => navigate(`/skud/requests/${requestKey}`)} onRepublish={republish} onDelete={requestKey => {
        if (records[requestKey]?.card.tab === 'active') return;
        setRecords(current => { const next={...current}; delete next[requestKey]; return next; });
        setDeletedKeys(current=>[...current,requestKey]);
        setDocumentBank(current=>{const next={...current};delete next[requestKey];return next;});
        setSavedDraftKeys(current=>Object.fromEntries(Object.entries(current).filter(([,value])=>value!==requestKey)));
      }} />;
  } else if (location.pathname === '/skud/new/registration' || record?.card.tab === 'drafts' && record.kind === 'registration') {
    content = <RegistrationForm demoFillToken={demoFillToken} key={location.key} initialState={(query.get('state') as RegistrationFormState) || 'empty'} initialData={data as RegistrationFormData | undefined} onBack={() => list()} onDraft={values => save('registration', values, 'drafts', record ? key : undefined)} onPublish={values => save('registration', values, 'active', record ? key : undefined)} />;
  } else if (location.pathname === '/skud/new/install' || record?.card.tab === 'drafts' && record.kind === 'install') {
    content = <InstallForm demoFillToken={demoFillToken} key={location.key} initialStep={query.get('step') === '2' ? 2 : 1} initialData={data as InstallFormData | undefined} publicationOutcome={query.get('outcome') === 'error' ? 'error' : undefined} onBack={() => list()} onDraft={values => save('install', values, 'drafts', record ? key : undefined)} onPublish={values => save('install', values, 'active', record ? key : undefined)} />;
  } else if (record?.kind === 'registration' || record?.registrationStarted || key === 'registration-example' || key === 'installation-registration-example') {
    const stage = requestedStage as RegistrationStage;
    const installation = record?.kind === 'install' || key === 'installation-registration-example';
    content = <RegistrationRequest documents={requestDocuments} onDocumentSigned={onDocumentSigned} key={`${key}:${location.key}`} variant={installation ? 'installation' : 'registration-only'} initialStage={registrationStages.includes(stage) ? stage : record?.registrationStage} object={object} initialSnapshot={record?.snapshot} initialOverlay={record?.registrationStarted && !record.snapshot ? 'sign-success' : undefined} onTerminate={openTermination}
      onDataChange={snapshot => { if (record) patch(key, { snapshot, card: { ...record.card, name: snapshot.info.name, address: snapshot.info.address } }); }}
      outcome={(query.get('outcome') as 'success' | 'government-correction' | 'test-error' | 'test-correction') || 'success'}
      onStageChange={next => updateRequestStage(next,true)}
      onWithdraw={next => withdraw(next, true)} onMonitoring={() => navigate('/skud/monitoring/kolomenskoye-healthy')}
      additionalWorks={<AdditionalAgreement state={agreement} onStateChange={changeAgreement} showNotice={false} signatureOutcome={signOutcome} />}
      additionalNotice={<AdditionalAgreementNotice state={agreement} onSign={() => changeAgreement('sign')} />} />;
  } else if (record || key === 'installation-example') {
    const stage = requestedStage as InstallStage;
    content = <InstallRequest requestId={record?.card.id} selectedOfferKey={selectedOffers[key]} onOfferChange={offerKey=>setSelectedOffers(current=>({...current,[key]:offerKey}))} documents={requestDocuments} onDocumentSigned={onDocumentSigned} key={`${key}:${location.key}`} initialStage={installStages.includes(stage) ? stage : record?.installStage ?? 'offers'} object={object}
      onStageChange={next => updateRequestStage(next,false)}
      onRegistration={() => record ? patch(key, { registrationStarted: true }) : navigate('/skud/requests/installation-registration-example')}
      onObjectChange={next => { if (record) patch(key, { installObject: next, card: { ...record.card, name: next.name, address: next.address } }); }} onWithdraw={next => withdraw(next, false)} onWallet={() => navigate('/wallet')} onTerminate={openTermination}
      additionalState={agreement} onAdditionalStateChange={changeAgreement} signOutcome={signOutcome} insufficientFunds={query.get('funds') === 'insufficient'} reworkOutcome={query.get('rework') === 'error' ? 'error' : 'success'} resultVersion={query.get('version') === '2' ? 2 : 1} />;
  } else content = <Result title="Раздел не входит в локальный модуль СКУД" extra={<Button onClick={() => list()}>Мои заявки</Button>} />;

  const isForm = isNew || record?.card.tab === 'drafts';
  const isRegistration = !isForm && (record?.kind === 'registration' || record?.registrationStarted || key === 'registration-example' || key === 'installation-registration-example');
  const family: DemoFamily = isForm ? 'form' : active === 'monitoring' ? 'monitoring' : location.pathname.startsWith('/skud/work/') ? 'work' : /\/skud\/(offer|responses)\//.test(location.pathname) ? 'offer' : isRegistration ? 'registration' : record || key === 'installation-example' ? 'install' : 'list';
  const demoStage = observedStage.key === location.key ? observedStage.stage : requestedStage ?? (family === 'install' ? record?.installStage ?? 'offers' : family === 'registration' ? record?.registrationStage ?? 'initial' : family === 'work' ? 'working' : location.pathname.includes('/responses/') ? 'pending' : 'form');
  function demoNavigate(path: string) {
    setTermination({ stage: 'closed', comment: '' });
    navigate(path);
  }
  function demoVariant(values: Record<string,string>) {
    const params = new URLSearchParams(location.search);
    for (const name of ['sign','funds','version','rework','outcome','validation','agreement','origin','estimate']) params.delete(name);
    Object.entries(values).forEach(([name,value]) => params.set(name,value));
    if (record && values.agreement) patch(key, { agreement: values.agreement as AdditionalAgreementState });
    demoNavigate(`${location.pathname}?${params}`);
  }
  function demoStageChange(stage: string) {
    if (family === 'registration' && record?.kind !== 'install' && key !== 'installation-registration-example' && ['finish-ready','finish-sign'].includes(stage)) stage = 'completed';
    if (stage === '@monitoring') { demoNavigate(`/skud/monitoring/${role === 'executor' ? 'kolomenskoye?role=executor' : 'kolomenskoye-healthy'}`); return; }
    if (stage === '@work') { setWorkStages(current=>({...current,[key]:'preparation'})); demoNavigate(`/skud/work/${key || 'example'}?stage=preparation`); return; }
    if (stage === '@registration') {
      if (record) { patch(key, { registrationStarted: true, registrationStage: 'initial' }); demoNavigate(`${location.pathname}?stage=initial`); }
      else demoNavigate('/skud/requests/installation-registration-example?stage=initial');
      return;
    }
    if(family==='work'&&executorWorkStages.includes(stage as ExecutorWorkStage))setWorkStages(current=>({...current,[key]:stage as ExecutorWorkStage}));
    if (record && family === 'registration' && record.snapshot && ['test-ready','testing','test-correction-ready'].includes(stage)) {
      patch(key, { snapshot: { ...record.snapshot, testFile: { name: 'Демо-пакет.json', size: 32, file: new File(['{"demo":true}'], 'Демо-пакет.json', {type:'application/json'}) } } });
    }
    if (record && family === 'install') {
      const labels: Record<string,string> = { 'empty-offers':'Получаем предложения', offers:'Получаем предложения', offer:'Получаем предложения', 'contract-sign':'Требуется подпись', preparation:'Подготовка к монтажу', working:'В работе', acceptance:'Ожидает приёмки', 'accept-sign':'Требуется подпись', rework:'Отправлено на доработку' };
      patch(key, {installStage:stage as InstallStage,card:{...record.card,status:labels[stage] ?? record.card.status,offers:stage==='offers'?6:undefined}});
    }
    demoVariant({ stage, ...(family === 'install' && demoStage === 'rework' && stage === 'acceptance' ? {version:'2'} : {}) });
  }
  function switchRole(next: 'customer'|'executor') {
    if (next === role) return;
    setRoleLocations(current => ({ ...current, [role]: location.pathname + location.search }));
    if (active === 'monitoring') {
      const params = new URLSearchParams(location.search); params.set('role', next);
      const target = next === 'executor' && key && key !== 'kolomenskoye' ? '/skud/monitoring/kolomenskoye' : location.pathname;
      demoNavigate(`${target}?${params}`);
    } else demoNavigate(roleLocations[next] ?? (next === 'executor' ? '/skud/incoming?role=executor' : '/skud/requests'));
  }
  function resetDemoScreen() {
    if (family === 'form') { if (record) patch(key, { data: undefined }); demoNavigate(location.pathname); return; }
    if (family === 'install') { if (record) patch(key, { agreement: 'idle' }); demoStageChange('empty-offers'); return; }
    if (family === 'registration') { if (record) patch(key, { snapshot: undefined, agreement: 'idle' }); demoStageChange('initial'); return; }
    if (family === 'work') { demoStageChange('preparation'); return; }
    if (family === 'offer') { setOffers(current => { const next = {...current}; delete next[key]; return next; }); demoStageChange('form'); return; }
    if(active==='monitoring')setMonitoringTerminations({});
    demoNavigate(active === 'monitoring' ? `/skud/monitoring?role=${role}` : role === 'executor' ? '/skud/incoming' : '/skud/requests');
  }
  const demoFooter = <DemoControls onCompleteTermination={family==='monitoring'&&monitoringTermination?.status==='pending'?()=>updateMonitoringTermination({...monitoringTermination,status:'terminated'}):undefined} family={family} stage={demoStage} role={role} onStage={demoStageChange} onNavigate={demoNavigate} onVariant={demoVariant} onReset={resetDemoScreen} onTerminate={family === 'install' || family === 'registration' ? openTermination : undefined} onFill={isForm || family === 'offer' && ['form','filled','validation'].includes(demoStage) ? () => setDemoFill(current => ({key:location.key,token:current.token+1})) : undefined} />;

  return <SkudShell onRoleChange={switchRole} footer={demoFooter} active={active} role={role} onNavigate={navigate} breadcrumb={<Breadcrumb items={[
    { title: 'Главная' }, { title: 'СКУД' }, { title: <Link to={`/skud/${active}${roleQuery}`}>{baseTitle}</Link> },
    ...(isNew ? [{ title: 'Новая заявка' }] : key ? [{ title: record?.card.id ?? responseRecord?.id ?? monitoringObjects[key]?.requestId ?? 'СКУД-2026-0009' }] : []),
  ]} />}>
    {content}
    <ContractTermination value={termination} onStateChange={setTermination} onRequested={request => { if (record) patch(key, { terminationRequest: request, card: { ...record.card, status: 'На расторжении', statusColor: 'error' } }); }} />
  </SkudShell>;
}
